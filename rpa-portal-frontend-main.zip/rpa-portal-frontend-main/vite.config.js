import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { generateRoutes, startRouteWatcher } from './src/routes/index.js';

export default defineConfig(({ mode }) => {
  // 현재 실행 모드별 .env 파일 로드
  const env = loadEnv(mode, process.cwd(), '');

  return {
    plugins: [
      react(),
      {
        name: 'auto-route-generator',
        apply: 'serve', // 개발 서버(dev 모드)에서만
        configureServer(server) {
          generateRoutes();
          // watcher 등록 및 인스턴스 저장
          const watchers = startRouteWatcher();

          server.httpServer?.once('close', () => {
            watchers.forEach((w) => w.close());
            console.log('[generate-routes] Watchers closed (server restart)');
          });
        },
      },
    ],
    resolve: {
      alias: {
        '@api': path.resolve(__dirname, 'src/api'),
        '@assets': path.resolve(__dirname, 'src/assets'),
        '@components': path.resolve(__dirname, 'src/components'),
        '@data': path.resolve(__dirname, 'src/data'),
        '@constants': path.resolve(__dirname, 'src/constants'),
        '@features': path.resolve(__dirname, 'src/features'),
        '@pages': path.resolve(__dirname, 'src/pages'),
        '@hooks': path.resolve(__dirname, 'src/hooks'),
        '@routes': path.resolve(__dirname, 'src/routes'),
        '@utils': path.resolve(__dirname, 'src/utils'),
        '@store': path.resolve(__dirname, 'src/store'),
      },
    },

    base: '/', // 필요 시 배포 경로에 맞게 수정 가능

    define: {
      __APP_ENV__: JSON.stringify(env.VITE_RUN_ENV),
    },

    server: {
      host: true, // 0.0.0.0 바인딩 가능
      port: 3000,
      strictPort: true,
      cors: true,
      proxy: {
        // 프론트 요청을 backend로 전달
        '/rpa/portal': {
          target: 'http://61.109.146.170:28301', // backend 실제 IP
          changeOrigin: true, // target Host로 전달
          secure: false,
          cookieDomainRewrite: '', // 쿠키 host-only 유지
        },
      },
    },
    build: {
      sourcemap: env.VITE_GENERATE_SOURCEMAP === 'true',
      outDir: `dist/${mode}`, // 모드별 빌드 폴더 구분 가능
    },
  };
});
