import js from '@eslint/js';
import ts from '@typescript-eslint/eslint-plugin';
import tsParser from '@typescript-eslint/parser';
import importPlugin from 'eslint-plugin-import';
import prettier from 'eslint-plugin-prettier';
import react from 'eslint-plugin-react';
import reactHooks from 'eslint-plugin-react-hooks';

export default [
  {
    ignores: ['eslint.config.js'], // ✅ eslint 설정 파일은 검사하지 않음
  },
  js.configs.recommended,
  {
    files: ['**/*.{js,jsx,ts,tsx}'],
    languageOptions: {
      parser: tsParser,
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: {
        // 브라우저 전역
        window: 'readonly',
        document: 'readonly',
        localStorage: 'readonly',
        sessionStorage: 'readonly',
        fetch: 'readonly',
        console: 'readonly',
        setTimeout: 'readonly',
        clearTimeout: 'readonly',
        setInterval: 'readonly',
        clearInterval: 'readonly',
        navigator: 'readonly',
        location: 'readonly',
        process: 'readonly', // Node 전역
        global: 'readonly',
      },
      parserOptions: {
        ecmaFeatures: { jsx: true },
        project: './tsconfig.json',
      },
    },
    plugins: {
      react,
      'react-hooks': reactHooks,
      '@typescript-eslint': ts,
      prettier,
      import: importPlugin,
    },
    settings: {
      react: { version: 'detect' },
      import: {
        resolver: {
          alias: {
            map: [
              ['@api', './src/api'],
              ['@assets', './src/assets'],
              ['@components', './src/components'],
              ['@data', './src/data'],
              ['@constants', './src/constants'],
              ['@features', './src/features'],
              ['@pages', './src/pages'],
              ['@hooks', './src/hooks'],
              ['@routes', './src/routes'],
              ['@utils', './src/utils'],
              ['@store', './src/store'],
            ],
            extensions: ['.ts', '.tsx', '.js', '.jsx', '.json'],
          },
        },
      },
    },
    rules: {
      // 코드 스타일
      quotes: 'off',
      '@typescript-eslint/quotes': 'off',
      'no-undef': 'error',

      //미사용 값들
      'no-unused-vars': 'off',
      '@typescript-eslint/no-unused-vars': ['off', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],

      // React
      'react/jsx-uses-react': 'error',
      'react/jsx-uses-vars': 'error',
      'react/react-in-jsx-scope': 'off',
      'react/prop-types': 'off',
      'react/display-name': 'off',

      // import 관련
      'import/no-unresolved': 'off',
      'import/no-extraneous-dependencies': 'off',
      'import/extensions': 'off',

      // 기타
      'no-console': 'off',
    },
  },
];
