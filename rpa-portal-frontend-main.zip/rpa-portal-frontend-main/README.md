# React + Vite

CRA → Vite

- 기존 Q서비스 ODS 프로젝트에서는 모바일 환경이 열악한 경우, 초기 로드 문제가 제기됨
  > **속도가 중요하며, SEO와 SSR이 불필요하여 Vite로 선정**

## 📂 추천 폴더 구조

```
src/
  ├── api/               # 백엔드 연동 (API 모듈, axios 등)
  ├── assets/            # 이미지, 아이콘, 폰트 등 정적 자원
  ├── components/        # 공통 UI 컴포넌트
  │   ├── common/        # 최소 단위 (Button, Modal, Input 등)
  │   ├── form/          # 최소 단위 (Input, Select, Checkbox 등)
  │   ├── layout/        # Header, Sidebar, Footer, Breadcrumb 등
  │   └── ui/            # 카드, 테이블, 차트 등 UI 패턴
  │
  ├── constants/         # 상수 선언들
  │   ├── paths/         # URL Paths
  │   └── permissions/   # 권한 관련
  │
  ├── features/          # 도메인별 기능 단위
  │   ├── auth/          # 로그인, 회원가입, 권한 처리
  │   ├── calendar/      # FullCalendar 관련 컴포넌트
  │   ├── tasks/         # 업무 관리 (TaskList, TaskCard 등)
  │   └── dashboard/     # 대시보드 위젯, 요약 카드
  │
  ├── pages/             # 라우트 단위 페이지
  │   ├── Dashboard/
  │   ├── Login/
  │   ├── Settings/
  │   └── NotFound/
  │
  ├── hooks/             # 커스텀 훅 (useFetch 등)
  ├── utils/             # 헬퍼 함수 (dateUtils, formatters 등)
  ├── constants/         # 상수 정의 (API_ENDPOINTS, ROLES 등)
  ├── routes/            # 라우팅 관련 설정 (menuData, routePath 등)
  ├── store/             # Zustand 상태관리
  ├── App.jsx
  ├── main.jsx
  └── index.css

```

# 실행

- git pull
- npm i
- npm start

package.json > script 목록에 실행 가능한 명령어들이 존재함.

> npm run ~~ (ex. npm start, npm run build:test ...)

# 설계방향

## 1. 컴포넌트 재사용성

- 동일한 패턴의 코드가 2회 이상 반복되면 공통 컴포넌트로 분리
- 단순 재사용 목적이 아닌 **유연한 확장성** 고려
  - props는 최소화하고, 상태가 필요하면 훅으로 분리
- 컴포넌트는 독립적이어야 하며, 불필요한 props 전달로 **props drilling**을 유발하지 않음

## 2. 로직 플로우

- 컴포넌트 및 함수 내부 로직은 **위에서 아래로 자연스럽게 흐르도록** 작성
  - 상단: props / 상수 / 상태 선언
  - 중단: effect, 데이터 처리, 훅 호출
  - 하단: 렌더링(JSX) 및 이벤트 핸들러
- 함수는 **입력 → 처리 → 출력** 순서로 설계
- 전역 상태(`zustand`)활용으로 props 전달 최소화

## 3. 가독성

- 함수(또는 컴포넌트)는 한 가지 역할만 수행
- 한 파일 ≤ 200줄, 한 함수 ≤ 50줄 권장
- 의미 없는 축약 지양, **의도를 드러내는 변수명** 사용
- 불필요한 컴포넌트 분리 피함

  > ex) DOM 구조만 나눈 컴포넌트는 유지보수를 어렵게 함

## 4. 중복 선언 방지

- 단일 진실 공급원(영어: single source of truth, SSOT) 으로,
- 동일한 상수, enum, 타입 등은 **정해진 위치**에 정의 후 재사용

```src/constants/
   src/types/
```

- 중복 로직은 hooks 또는 utils로 이동
  - hooks: React 관련 상태/비즈니스 로직
  - utils: 순수 함수 / 재사용 가능한 계산 로직

## 5. 상태 관리

- **로컬 상태**: zustand
- **서버 데이터**: React Query
- 상태 변경은 단방향 흐름 유지
- 전역 vs 로컬 상태 경계 명확히
- selector/derived state 사용으로 불필요한 리렌더링 최소화

## 6. API 설계

- 모든 API는 `commonApi` 또는 모듈별 API wrapper를 통해 접근
- API 호출은 React Query 기반 hook(`useFetch` / `useMutate`)만 사용
- API naming: path 및 CRUD 에 따라 일관성 있게 작성
- 에러 처리 및 로딩 상태는 공통으로 관리
- hook 내부 query key, cache 정책 통일

  `const { data, isLoading, error } = useFetch('list', { pageNo: 1 });
`

## 7. 명명 규칙

| 구분          | 규칙              | 예시                      |
| ------------- | ----------------- | ------------------------- |
| 컴포넌트      | PascalCase        | `UserCard`, `MainHeader`  |
| 컴포넌트 파일 | PascalCase.tsx    | `UserCard.tsx`            |
| 훅            | useCamelCase      | `useFetchData`            |
| 훅 파일       | useCamelCase.ts   | `useFetchData.ts`         |
| 상수          | UPPER_SNAKE_CASE  | `DEFAULT_PAGE_SIZE`       |
| 유틸 파일     | camelCase.ts      | `formatDate.ts`           |
| API           | 동사 + 명사       | `fetchList`, `updateItem` |
| 상태/boolean  | is/has/can 접두사 | `isOpen`, `hasError`      |
| 이벤트 핸들러 | onEvent           | `onClickSubmit`           |

- 변수명, props, 함수명은 **의도를 드러내도록 작성**

## 8. 확장성과 유지보수성

- 기능 추가 시 기존 코드 수정 최소화
- 공통 로직은 훅 또는 유틸로 추상화
- React Query key, routing path, error boundary 등 **시스템 레벨 통일**

# 개발방법

## 주요 사항은 이곳에 작성 필수.

## 1. 메뉴 정보

- routes/index 에서 pages 구조를 기반으로 routes/routes.generated.ts에 ROUTES를 생성
- 계층 구조대로 navMenu, breadcrumb, tabs를 자동으로 구성
- 페이지 이동시 위에 생성된 ROUTES를 사용하여 이동 ex) navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);

## 2. 페이지 구현시, pages 안에 ROUTES 구조에 맞게 페이지를 생성

- meta data(order, title 등)만 메뉴 구성에 맞게 추가.
- 그 외 해당 페이지에만 필요한 요소는 features 하위에 폴더로 구분하여 생성.
- 다른 페이지에도 필요한 요소는 components 하위 폴더에 생성.

## 3.통신 관련.

- 기본적으로 react-query & axios 사용.
- GET: useFetch(useQuery), POST: useMutate(useMutation)

  > {data, refetch} = useFetch(fn, vars, options), {m(동기), mAsync(비동기)} = useMutate(fn, options)

- 모든 API의 param은 최대 1개로 권장.
  > response는 {status, data:{} }형태로, 유효한 데이터는 구조분해하여 사용.

## 4.Form

- components/form/하위의 컴포넌트와 formHandler를 적극 사용
  > props를 묶어서 선언하고 사용하면 편리.(기존 페이지 참고.)
- 별도로 eventHandler와 validation 로직을 만들 필요 없음.
- ※ 특이사항. Checkbox > 전체 제어 버튼의 경우, placeholder = 'All', value를 전체값[]로 할당하고 사용

## 5.ErrorBoundary

- ErrorBoundary 내부에서 모든 Error Handling
  > API status 관련 처리는 axios > interceptor로 처리

## 6.Modal

- GlobalModal에서 전역 에러 팝업까지 모두 통합 관리
