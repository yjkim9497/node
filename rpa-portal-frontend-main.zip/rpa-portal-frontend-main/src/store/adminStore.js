// src/store/adminStore.js
import { create } from 'zustand';
import {
  getRobotInfo,
  getRobotList,
  getServerStatus,
  getWorkKpi,
  getExecutionTrends,
  getSchedules,
} from '@api/adminApi';

export const useAdminStore = create((set) => ({
  // State for each piece of admin data
  robotInfo: null,
  robotList: [],
  serverStatus: null,
  workKpi: [],
  executionTrends: [],
  schedules: { running: [], scheduled: [] },

  // State for loading and error handling
  loading: false,
  error: null,

  // Action to fetch all admin data
  fetchAdminData: async () => {
    set({ loading: true, error: null });
    try {
      // Using Promise.all to fetch all data concurrently
      const [robotInfo, robotList, serverStatus, workKpi, executionTrends, schedules] =
        await Promise.all([
          getRobotInfo(),
          getRobotList(),
          getServerStatus(),
          getWorkKpi(),
          getExecutionTrends(),
          getSchedules(),
        ]);

      set({ robotInfo, robotList, serverStatus, workKpi, executionTrends, schedules, loading: false });
    } catch (error) {
      console.error('Failed to fetch admin dashboard data:', error);
      set({ error, loading: false });
    }
  },
}));
