// src/store/communityStore.js
import { create } from "zustand";
import { persist } from "zustand/middleware";

// Valid types: 'incident' | 'notice' | 'faq' | 'board' | 'doc'
const initialListParams = {
  page: 0,
  size: 10,
  keyword: "",
  sort: "createdAt,desc",
  // add filters: status, category, dateRange, etc.
};

export const useCommunityStore = create(
  persist(
    (set, get) => ({
      // ---- state ----
      type: "board",
      listParams: { ...initialListParams },
      selectedId: null,

      // ---- actions ----
      setType: (nextType) => set({ type: nextType, selectedId: null }),
      setSelectedId: (id) => set({ selectedId: id }),
      clearSelected: () => set({ selectedId: null }),

      setListParams: (patch) =>
        set((state) => ({
          listParams: { ...state.listParams, ...(patch || {}) },
        })),

      resetListParams: () => set({ listParams: { ...initialListParams } }),

    }),
    {
      name: "community-store", // localStorage key
      partialize: (state) => ({
        type: state.type,
        listParams: state.listParams,
      }), // keep selection ephemeral
      version: 1,
    }
  )
);
