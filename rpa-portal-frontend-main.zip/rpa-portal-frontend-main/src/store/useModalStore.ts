import { create } from 'zustand';
import { nanoid } from 'nanoid';
import React from 'react';
import { ModalSize } from '@components/modal/Modal';

export interface ModalPayload {
  /** 내부에서 자동 생성되는 고유 ID (close 시 사용) */
  id?: string;
  /** 모달 제목 */
  title?: string;
  /** 모달 타입 error 구분용 */
  type?: 'error' | 'normal';
  /** 모달 내용 (JSX 가능) */
  content: string | React.ReactNode;
  /** 모달 크기 */
  size?: ModalSize;
  autoCloseDuration?: number;
  showProgress?: boolean;
  confirmText?: string;
  cancelText?: string;
  onConfirm?: () => Promise<void> | void;
  onCancel?: () => Promise<void> | void;
  onClose?: () => Promise<void> | void;
}

interface ModalState {
  /** 현재 열린 모달 스택 (맨 뒤가 최상단) */
  stack: ModalPayload[];
  /**
   * 모달 열기
   * @param modal 모달 데이터 (id 제외)
   * @returns 생성된 모달의 고유 ID
   */
  open: (modal: ModalPayload) => string;
  /**
   * 모달 닫기
   * @param id 닫을 모달의 ID (생략 시 최상단 모달을 닫음)
   */
  close: (id?: string) => void;
  /**
   * 모두 닫기
   */
  clear: () => void;
}

export const useModalStore = create<ModalState>((set) => ({
  stack: [],
  open: (modal) => {
    const id = nanoid();
    const size = modal.size || 'xs';
    const title = modal.title || '';
    const type = modal.type || 'normal';
    set((s) => ({ stack: [...(s.stack?.filter((el) => el.type !== type) || []), { ...modal, id, size, type }] }));
    return id;
  },
  close: (id) =>
    set((s) => ({
      stack: id
        ? s.stack.filter((m) => m.id !== id) // 특정 모달 닫기
        : s.stack.slice(0, -1), // id 없으면 최상단 모달 닫기
    })),
  clear: () => set({ stack: [] }),
}));
