//src/store/authStore.js
import { logout, refresh } from '@api/commonAuthApi';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const init = {
  username: null,
  dptname: null,
  userid: null,
  token: null,
  superAuthYn: null, // true 관리자
  roles: [],
};

export const useAuthStore = create(
  persist(
    (set, get) => ({
      ...init,

      setAuth: (data) => {
        if (data) set(data);
        else {
          const { token } = get();
          if (token) logout(token);
          set(init);
        }
      },

      refreshToken: async () => {
        const res = await refresh();
        if (res.token) set({ token: res.token });
        return res.token;
      },
    }),
    {
      name: 'auth-storage', // localStorage key
      partialize: (state) => ({ ...state }),
    }
  )
);
