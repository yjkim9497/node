// src/pages/assignment/application/Reg.jsx
import React, { useState } from 'react';
import Button from '@components/ui/Button';
import VariableSelect from '@features/popup/VariableSelect';

export default function Reg({ paths }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedVariable, setSelectedVariable] = useState(null);

  const handleOpenVariablePu = () => {
    console.log('handleOpenVariablePu', modalOpen);
    setModalOpen(true);
  };

  const handleVariablePu = () => {
    console.log('handleVariablePu', modalOpen);
    setModalOpen(!modalOpen);
  };

  const handleSelectVariable = (variable) => {
    // variable: VariableSelect 에서 선택한 row
    setSelectedVariable(variable);

    // 필요하면 form 에도 바로 반영
    // setForm(prev => ({
    //   ...prev,
    //   variableName: variable.variableName,
    //   variableValue: variable.variableValue,
    // }));

    setModalOpen(false);
  };

  return (
    <>
      <div className="p-4 space-y-2">
        <Button onClick={handleOpenVariablePu}>공용 변수 선택</Button>

        {selectedVariable && (
          <div className="text-sm">
            선택된 변수: {selectedVariable.variableName} ({selectedVariable.variableValue})
          </div>
        )}
      </div>

      <VariableSelect
        paths={{ paths: ['pblresource', 'variable', 'List'] }}
        modalOpen={modalOpen}
        setModalOpen={handleVariablePu}
        onSelect={handleSelectVariable}
      />
    </>
  );
}
