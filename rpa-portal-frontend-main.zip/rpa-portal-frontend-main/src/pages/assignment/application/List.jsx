// src/pages/assignment/application/List.jsx
import WorkListPU from '@features/popup/WorkListPU';
import Button from '@components/ui/Button';
import { useEffect, useMemo, useState } from 'react';
import Toggle from '@components/ui/Toggle';
import { useMutate } from '@hooks/useApi';
import { navigate } from '@routes/NavigationProvider';
import ROUTES from '@routes/routes.generated';

export default function List({ paths }) {
  const [form, setForm] = useState({});
  const [workListOpen, setWorkListOpen] = useState(false);

  const [toggleForm, setToggleForm] = useState({});
  const [toggleResetKey, setToggleResetKey] = useState(0);

  const handleSelectWork = (work) => {
    if (!work) return; // 취소 누른 경우 등

    setForm((prev) => ({
      ...prev,
      assignmentName: work.assignmentName ?? '',
      assignmentCode: work.assignmentCode ?? '',
    }));
  };

  const handleRegButton = () => {
    navigate(ROUTES.ASSIGNMENT_APPLICATION_REG.url);
  };

  return (
    <div>
      과제관리_업무신청
      <div>{form.assignmentCode}</div>
      <Button onClick={() => setWorkListOpen(true)}>업무 선택</Button>
      <WorkListPU
        open={workListOpen}
        onClose={() => setWorkListOpen(false)}
        onSelect={handleSelectWork}
        paths={paths}
      />
      <div>토글테스트</div>
      <Toggle size="md" title="사용">
        <input
          type="checkbox"
          name="useYn"
          id="useYn"
          // form={toggleForm}
          // setForm={setToggleForm}
          defaultValue={true}
          // resetKey={toggleResetKey}
          className="sr-only peer"
        />
      </Toggle>
      <div>MY 진행상황 - Filter 1</div>
      <div>Filter2</div>
      <div>목록</div>
      <Button onClick={handleRegButton}>등록</Button>
    </div>
  );
}
