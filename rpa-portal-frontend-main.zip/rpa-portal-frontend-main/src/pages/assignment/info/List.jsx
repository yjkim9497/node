export default function List({ paths }) {
  return <div>과제관리_수행업무정보</div>;
}
