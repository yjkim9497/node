// src/pages/Login.jsx
import Input from '@components/form/Input';
import { useMutate } from '@hooks/useApi';
import { createProps, validateForm } from '@utils/formHandlers';
import { useEffect, useState } from 'react';
import ROUTES from '@routes/routes.generated';
import { useAuthStore } from '@store/authStore';
import { login } from '@api/commonAuthApi';
import { navigate } from '@routes/NavigationProvider';

export default function SignIn() {
  const { token, setAuth } = useAuthStore();
  const [form, setForm] = useState({
    username: 'testauth1',
    password: 'A1234567!',
  });
  const { mAsync: signIn } = useMutate(login);

  const submit = async () => {
    if (!validateForm()) return;
    const data = await signIn(form);
    console.log(data);
    setAuth(data);
  };

  useEffect(() => {
    if (token) navigate(ROUTES.DASHBOARD.url);
  }, [token]);

  const inputProps = (name, label) =>
    createProps({ name, label, form, setForm, required: true, className: 'w-full border p-2 rounded' });

  if (token) return null;

  return (
    <div className="h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-6 rounded shadow-md w-80" onKeyDown={(e) => e.key === 'Enter' && submit()}>
        <h1 className="text-xl font-bold mb-4">로그인</h1>
        <div className="space-y-4 relative">
          <Input {...inputProps('username', '아이디')} />
          <Input {...inputProps('password', '비밀번호')} type="password" />
          <button className="w-full bg-blue-500 text-white py-2 rounded" onClick={submit}>
            로그인
          </button>
        </div>
      </div>
    </div>
  );
}
