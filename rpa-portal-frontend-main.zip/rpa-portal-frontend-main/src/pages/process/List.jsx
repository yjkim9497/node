import Button from '@components/ui/Button';
import ROUTES from '@routes/routes.generated';
import FilterBar from '@components/common/FilterBar';
import { useAuthStore } from '@store/authStore';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import Table from '@components/ui/table/Table';
import { statusReverseMap } from '@utils/communityMapper';
import Select from '@components/form/Select';
import Input from '@components/form/Input';
import { useModalStore } from '@store/useModalStore';
import { LabeledField } from '@components/common/LabeledField';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';
import DetailPU from '@features/community/incident/DetailPU';

export default function List({ paths }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState({});
  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  const modal = useModalStore();

  const pageRowCount = 15;

  const filterData = {
    processName: form.processName || '',
    title: form.title || '',
    status: form.status || '',
    occurStartDate: form.occurStartDate || '',
    occurEndDate: form.occurEndDate || '',
    sortKey: form.sortKey || 'occurAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const [filter, setFilter] = useState(filterData);
  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);

  const columns = [
    { key: 'checkbox', label: '', width: 'w-8' },
    { key: 'processName', label: '프로세스명 ', width: 'w-32', render: '' },
    { key: 'processVersion', label: '최종 버전 ', width: 'w-16' },
    { key: 'D4', label: '형상 관리 ', width: 'w-16' },
    { key: 'registerId', label: '최종 수정자 ', width: 'w-16' },
    { key: 'F4', label: '최종 수정 일자', width: 'w-16' },
    { key: 'packageRegistorYnName', label: '패키지 상태', width: 'w-16' },
    { key: 'downNmenu', label: '', width: 'w-12' },
  ];

  async function handleRowClick(row) {
    //navigate(`${ROUTES.COMMUNITY_INCIDENT_DETAIL.url}/${row.id}`);
    //setSelected(row);
    //setModalOpen(true);
  }
  async function handleDelete(id) {
    await deleteBoard({ paths, ids: [id] });
    setModalOpen(false);
  }

  const handleCreate = () => {
    //  navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);
  };

  const onDeleteLists = async () => {
    let content = '삭제할 항목을 선택해주세요';
    let onConfirm;
    if (form.ids?.length) {
      content = `${form.ids.length}개 항목을\n삭제하시겠습니까?`;
      onConfirm = async () => {
        await deleteBoard({ paths, ids: form.ids });
      };
    }
    modal.open({ content, onConfirm });
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        onKeyDown={(e) => e.key === 'Enter' && setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            <LabeledField
              props={{
                ...inputProps('processName', '검색어'),
                placeholder: '서식명',
              }}
              component={Input}
              compClassName={'col-span-3'}
            />
          </div>
        }
        bottom={
          <div className="grid grid-cols-9 gap-4 items-center">
            <LabeledField
              props={{
                ...inputProps('a1', '형상 관리'),
                options: [
                  { label: '전체', value: '' },
                  { label: '조치대기', value: 'WAIT' },
                  { label: '조치중', value: 'ING' },
                  { label: '완료', value: 'COMPLETE' },
                ],
              }}
              component={Select}
            />
            <LabeledField
              props={{
                ...inputProps('a2', '패키지 등록'),
                options: [
                  { label: '전체', value: '' },
                  { label: '조치대기', value: 'WAIT' },
                  { label: '조치중', value: 'ING' },
                  { label: '완료', value: 'COMPLETE' },
                ],
              }}
              className="col-span-2"
              component={Select}
            />
            <LabeledField
              props={{
                ...inputProps('a3', '작업 그룹'),
                options: [
                  { label: '전체', value: '' },
                  { label: '조치대기', value: 'WAIT' },
                  { label: '조치중', value: 'ING' },
                  { label: '완료', value: 'COMPLETE' },
                ],
              }}
              className="col-span-2"
              component={Select}
            />
          </div>
        }
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          {superAuthYn && (
            <div className="flex gap-2">
              <Button onClick={handleCreate}>프로세스 서버 이동</Button>
              <Button onClick={handleCreate}>다운로드</Button>
              <Button variant="ghost" onClick={onDeleteLists}>
                삭제
              </Button>
            </div>
          )}
        </div>
        <Table
          {...{
            columns,
            data,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
          }}
        />
      </div>
      {modalOpen && <DetailPU {...{ paths, selected, setSelected, handleDelete, setModalOpen }} />}
    </div>
  );
}
