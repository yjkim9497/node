// src/pages/Dashboard.jsx
import EmployeeDashboard from '@features/dashboard/employee/index';
import AdminDashboard from '@features/dashboard/admin/index';
import { useAuthStore } from '@store/authStore';

export default function Dashboard({ READ_USER, READ_ADMIN, ...rest }) {
  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  return <>{superAuthYn ? <AdminDashboard {...rest} /> : <EmployeeDashboard {...rest} />}</>;
}
