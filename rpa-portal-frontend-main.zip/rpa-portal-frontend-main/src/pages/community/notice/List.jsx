// src/pages/community/notice/List.jsx
import Button from '@components/ui/Button';
import FilterBar from '@components/common/FilterBar';
import { useAuthStore } from '@store/authStore';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import Table from '@components/ui/table/Table';
import { statusReverseMap } from '@utils/communityMapper';
import Select from '@components/form/Select';
import DatePicker from '@components/form/DatePicker';
import Input from '@components/form/Input';
import { useModalStore } from '@store/useModalStore';
import { LabeledField } from '@components/common/LabeledField';
import { clsx } from 'clsx';
import { filters, list, modify, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';

export default function List({ paths, ADD, DEL_ALL, MOD_ALL }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState({});
  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = {
    systemName: form.systemName || '',
    title: form.title || '',
    status: form.status || '',
    occurStartDate: form.occurStartDate || '',
    occurEndDate: form.occurEndDate || '',
    sortKey: form.sortKey || 'createdAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);
  const { mAsync: modifyBoard } = useMutate(modify);
  //const { data: filterList } = useFetch(filters, { paths });
  //console.log(filterList);
  const columns = [
    ...(DEL_ALL ? [{ key: 'checkbox', label: '', width: 'w-2' }] : []),
    {
      key: 'no',
      label: 'No',
      width: 'w-2',
      render: (row, idx) =>
        row.publishType === 'NORMAL'
          ? Math.min(filter.pageNo * filter.pageRowCount, data.totalCount) - idx
          : row.publishTypeName,
    },
    { key: 'title', label: '제목', width: 'w-80' },
    { key: 'createdAt', label: '발생일자', width: 'w-16', sortKey: 'createdAt', sortOrder: filter.sortOrder },
    { key: 'authorName', label: '작성자', width: 'w-16' },
    { key: 'viewCnt', label: '조회수', width: 'w-10' },
  ];

  async function handleRowClick(row) {
    navigate(`/detail/${row.id}`);
  }
  async function handleDelete(id) {
    await deleteBoard({ paths, ids: [id] });
    setModalOpen(false);
  }

  async function handleUpdate(noticeYn) {
    // const params = { ...(details || {}), noticeYn };
    // await modifyBoard({ paths, params });
    // setModalOpen(false);
  }

  const handleCreate = () => {
    navigate('reg');
  };

  const onDeleteLists = async () => {
    let content = '삭제할 항목을 선택해주세요';
    let onConfirm;
    if (form.ids?.length) {
      content = `${form.ids.length}개 항목을\n삭제하시겠습니까?`;
      onConfirm = async () => {
        await deleteBoard({ paths, ids: form.ids });
      };
    }
    modal.open({ content, onConfirm });
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            {/* <LabeledField
              props={{
                ...inputProps('systemName', '시스템명'),
                options: (items ?? []).reduce(
                  (acc, el) => {
                    if (!acc.some((item) => item.value === el.systemName)) {
                      acc.push({ label: el.systemName, value: el.systemName });
                    }
                    return acc;
                  },
                  [{ label: '전체', value: '' }]
                ),
              }}
              className="col-span-2"
              component={Select}
            /> */}
            <LabeledField
              props={inputProps('title', '제목')}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
            <LabeledField
              props={inputProps('occurStartDate', '기간')}
              children={
                <div className="col-span-2 flex items-center gap-1">
                  <DatePicker
                    {...inputProps('occurStartDate', '시작일자')}
                    className={clsx(inputProps().className, 'flex-1 min-w-0')}
                  />
                  <span className="select-none">~</span>
                  <DatePicker
                    {...inputProps('occurEndDate', '종료일자')}
                    className={clsx(inputProps().className, 'flex-1 min-w-0')}
                  />
                </div>
              }
            />
          </div>
        }
        bottom={
          <div className="grid grid-cols-9 gap-4 items-center">
            <LabeledField
              props={{
                ...inputProps('status', '유형'),
                options: [
                  { label: '전체', value: '' },
                  { label: '조치대기', value: 'WAIT' },
                  { label: '조치중', value: 'ING' },
                  { label: '완료', value: 'COMPLETE' },
                ],
              }}
              className="col-span-2"
              component={Select}
            />
          </div>
        }
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          <div className="flex gap-2">
            {MOD_ALL && (
              <>
                <Button variant="ghost" onClick={() => selected && handleUpdate('Y')}>
                  공개
                </Button>
                <Button variant="ghost" onClick={() => selected && handleUpdate('N')}>
                  비공개
                </Button>
              </>
            )}
            {DEL_ALL && (
              <Button variant="ghost" onClick={onDeleteLists}>
                삭제
              </Button>
            )}
            {ADD && <Button onClick={handleCreate}>새 글 작성</Button>}
          </div>
        </div>
        <Table
          {...{
            columns,
            data,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
          }}
        />
      </div>
    </div>
  );
}
