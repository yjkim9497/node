// src/pages/Reg.jsx
import { useEffect, useRef, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import DatePicker from '@components/form/DatePicker';
import TimePicker from '@components/form/TimePicker';
import Select from '@components/form/Select';
import Textarea from '@components/form/Textarea';
import Input from '@components/form/Input';
import Checkbox from '@components/form/Checkbox';
import { validateForm } from '@utils/formHandlers';
import ROUTES from '@routes/routes.generated';
import FileManager from '@components/form/FileManager';
import { LabeledField } from '@components/common/LabeledField';
import { useFetch, useMutate } from '@hooks/useApi';
import { add, detail, modify } from '@api/commonApi';
import NoticePU from '@features/community/incident/NoticePU';
import { useAuthStore } from '@store/authStore';
import selectiveForm from '@utils/selectiveForm';
import { navigate } from '@routes/NavigationProvider';

let today;

export default function Reg({ paths }) {
  const { id } = useParams();
  const [fileInfo, setFileInfo] = useState();
  const [modalOpen, setModalOpen] = useState(false);
  const { username, userid } = useAuthStore();

  const { data } = useFetch(detail, { paths, id });
  const btnText = id ? '수정' : '등록';
  const fileRef = useRef(null);
  const [form, setForm] = useState({ authorName: username, authorId: userid });
  const { mAsync: createBoard, isLoading } = useMutate(add);
  const { mAsync: editBoard } = useMutate(modify);

  const isReserved = form.reserveYn;
  console.log(form);
  const validation = async () => {
    if (!validateForm()) return;
    handleSubmit();
  };

  const handleSubmit = async (file) => {
    const payload = file ? file : await fileRef.current?.fileUpload();
    const temp = selectiveForm(form, [{ include: isReserved, keys: [/^reserved/] }]);

    const params = {
      ...temp,
      ...payload,
    };

    const mutate = data ? editBoard : createBoard;
    await mutate({ paths, params });

    navigate('list');
  };

  useEffect(() => {
    data && setForm(data);
    today = new Date();
  }, [data]);

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    label,
    required: true,
    className: 'border rounded px-3 py-2 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div className="pr-6 py-6 max-w-7xl space-y-4 mx-auto bg-white shadow rounded">
      {/* 제목  */}
      <div className="grid grid-cols-12 gap-4 items-center">
        <LabeledField
          props={inputProps('title', '제목')}
          className="col-span-2"
          component={Input}
          compClassName={'col-span-10'}
        />
      </div>
      {/* 작성자 */}
      <div className="grid grid-cols-12 gap-4 items-center">
        <LabeledField
          props={{ ...inputProps('authorName', '작성자'), disabled: true }}
          className="col-span-2"
          component={Input}
          compClassName={'col-span-6'}
        />
      </div>

      {/* 공지 설정 */}
      <div className="grid grid-cols-12 items-center gap-2">
        <LabeledField props={{ ...inputProps('privateYn', '공지 설정'), required: false }} className="col-span-2" />
        <div className="flex col-span-4 gap-2 justify-around ml-0 flex-row-reverse">
          <div className="flex flex-row-reverse gap-2">
            <LabeledField
              props={{ ...inputProps('reserveYn', '예약 설정'), required: false }}
              className=" ml-0"
              component={Checkbox}
            />
          </div>
          <div className="flex flex-row-reverse gap-2">
            <LabeledField
              props={{ ...inputProps('importantYn', '중요 공지'), required: false }}
              className=" ml-0"
              component={Checkbox}
            />
          </div>
          <div className="flex flex-row-reverse gap-2">
            <LabeledField
              props={{ ...inputProps('privateYn', '비공개'), required: false }}
              className=" ml-0"
              component={Checkbox}
            />
          </div>
        </div>
        {isReserved && (
          <>
            <DatePicker
              {...inputProps('reservedDate', '예약일자')}
              className={`${inputProps().className} col-span-2`}
              defaultValue={today.toISOString().split('T')[0]}
              min={today.toISOString().split('T')[0]}
            />
            <TimePicker
              {...inputProps('reservedTime', '예약일자')}
              form={{ ...form, content: '현재 시간 이전입니다.' }}
              className={`${inputProps().className} col-span-2`}
              defaultValue={today.toTimeString().split(' ')[0]?.slice(0, 5)}
              min={today.toTimeString().split(' ')[0]?.slice(0, 5)}
            />
          </>
        )}
      </div>

      {/* 내용 */}
      <div className="grid grid-cols-12 gap-4">
        <LabeledField
          props={{ ...inputProps('content', '내용'), placeholder: '내용을 입력하세요' }}
          className="col-span-2"
          component={Textarea}
          compClassName={'col-span-10 h-[38vh] resize-y'}
        />
      </div>

      {/* 첨부파일 (선택) */}
      <div className="grid grid-cols-12 gap-4 items-center">
        <LabeledField
          props={{
            ...inputProps('fileGroupSequence', '첨부파일'),
            className: 'col-span-10',
            required: false,
            ref: fileRef,
            init: fileInfo,
            mode: 'All',
          }}
          className="col-span-2"
          component={FileManager}
        />
      </div>

      {/* 버튼 */}
      <div className="flex justify-end gap-3 mt-4">
        <button
          onClick={validation}
          disabled={isLoading}
          className="bg-blue-500 hover:bg-blue-600 text-white px-5 py-2 rounded shadow"
        >
          {isLoading ? `${btnText} 중...` : btnText}
        </button>
        <button onClick={() => navigate('list')} className="bg-gray-300 hover:bg-gray-400 px-5 py-2 rounded shadow">
          목록
        </button>
      </div>
      {modalOpen ? <NoticePU {...{ paths, fileInfo, setModalOpen, handleSubmit }} data={form} /> : <></>}
    </div>
  );
}
