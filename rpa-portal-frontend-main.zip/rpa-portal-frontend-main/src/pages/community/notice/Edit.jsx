import Reg from './Reg';

export default function Edit(params) {
  return <Reg {...params} />;
}
