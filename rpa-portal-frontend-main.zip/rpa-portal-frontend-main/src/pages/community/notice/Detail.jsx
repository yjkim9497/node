import { detail, remove } from '@api/commonApi';
import Button from '@components/ui/Button';
import FileManager from '@components/form/FileManager';
import GridTable from '@components/ui/GridTable';
import { useFetch, useMutate } from '@hooks/useApi';
import { useAuthStore } from '@store/authStore';
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { navigate } from '@routes/NavigationProvider';

const Detail = ({ paths, DEL_ALL, DEL_ME, MOD_ALL, MOD_ME }) => {
  const { username, userid } = useAuthStore();
  const [form, setForm] = useState({ authorName: username, authorId: userid });

  const [modalOpen, setModalOpen] = useState(false);
  const { id } = useParams();
  const { data } = useFetch(detail, { paths, id });
  const { mAsync: deleteBoard } = useMutate(remove);

  const canDel = DEL_ALL || (DEL_ME && data?.authorId === userid);
  const canMod = MOD_ALL || (MOD_ME && data?.authorId === userid);

  async function handleDelete() {
    await deleteBoard({ paths, ids: [id] });
  }

  return (
    <div className="border px-6 py-6 max-w-7xl space-y-4 mx-auto bg-white shadow rounded">
      <GridTable
        data={data}
        rows={[
          { key: 'title', label: '제목' },
          { key: 'authorName', label: '작성자', colNum: 2 },
          {
            key: 'createdAt',
            label: '작성일자',
            colNum: 2,
          },
          {
            key: 'publishTypeName',
            label: '공지 설정',
            value: (
              <span className="inline-block px-2 py-0.5 bg-green-100 text-green-700 rounded text-sm">
                {data?.publishTypeName}
              </span>
            ),
            colNum: data?.reservedAt ? 2 : 1,
          },
          {
            key: 'reservedAt',
            label: '예약 설정',
            invisible: true,
            colNum: 2,
          },
          { key: 'content', label: '내용', class: 'p-2 whitespace-pre-line h-[25vh]' },
          {
            key: 'fileGroupSequence',
            label: '첨부',
            value: <FileManager form={data} setForm={() => {}} />,
            invisible: true,
          },
        ]}
        total={6}
        lSpan={1}
      />
      <h3>참조 장애</h3>
      <GridTable
        data={data}
        rows={[
          {
            key: 'reservedAt',
            label: '장애 ID',
            colNum: 2,
          },
          { key: 'irChangedYn', label: '변동 내역', class: 'p-2 whitespace-pre-line' },
        ]}
        total={6}
        lSpan={1}
      />
      <div className="w-full flex justify-end mb-2 gap-2">
        <div className="flex space-x-2">
          {canDel && <Button children={'삭제'} variant="secondary" onClick={() => handleDelete()} />}
          {canMod && (
            <Button
              children={'수정'}
              onClick={() => {
                navigate(`edit/${id}`);
              }}
            />
          )}
          <Button children={'목록'} variant="secondary" onClick={() => navigate('list')} />
        </div>
      </div>
    </div>
  );
};

export default Detail;
