// src/pages/List.jsx
export default function List({ paths }) {
  return <div>FAQLIST123</div>;
}
