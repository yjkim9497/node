export default function Edit({ paths }) {
  return <div>커뮤니티_FAQ_수정</div>;
}
