export default function Reg({ paths }) {
  return <div>{paths}</div>;
}
