// src/pages/List.jsx
export default function List({ paths }) {
  return <div>게시판2</div>;
}
