// src/pages/List.jsx
export default function List({ paths }) {
  return <div>DOC12</div>;
}
