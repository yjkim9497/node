import Button from '@components/ui/Button';
import FilterBar from '@components/common/FilterBar';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import Table from '@components/ui/table/Table';
import Select from '@components/form/Select';
import DatePicker from '@components/form/DatePicker';
import Input from '@components/form/Input';
import { useModalStore } from '@store/useModalStore';
import { LabeledField } from '@components/common/LabeledField';
import { clsx } from 'clsx';
import { filters, list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';

export default function List({ paths, DEL_ALL }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const modal = useModalStore();

  const pageRowCount = 15;

  const filterData = {
    packageNameOrUserId: form.packageNameOrUserId || '',
    logTypeCode: form.logTypeCode || '',
    logStatusCode: form.logStatusCode || '',
    startDate: form.startDate || '',
    endDate: form.endDate || '',
    sortKey: form.sortKey || 'registerAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);
  //const { data: filterList } = useFetch(filters, { paths });
  // console.log(filterList);

  const columns = [
    { key: 'registerAt', label: '날짜', width: 'w-16', sortKey: 'registerAt', sortOrder: filter.sortOrder },
    { key: 'processName', label: '패키지명 ', width: 'w-24' },
    { key: 'logTypeCodeName', label: '내용 ', width: 'w-32' },
    { key: 'registerId', label: '사용자 ', width: 'w-12' },
    { key: 'logStatusCodeName', label: '결과 ', width: 'w-12' },
    { key: 'logFileGroupSequence', label: '로그 ', width: 'w-8' },
  ];

  async function handleRowClick(row) {
    // navigate(`/detail/${row.id}`);
  }

  const handleCreate = () => {
    //navigate('reg');
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        onKeyDown={(e) => e.key === 'Enter' && setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            <LabeledField
              props={{
                ...inputProps('packageNameOrUserId', '검색어'),
                placeholder: '패키지/사용자',
              }}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
            <LabeledField
              props={{
                ...inputProps('groupSequence', '작업그룹'),
                options: [{ label: '전체', value: 1 }], //...(filterList?.logStatusCode ?? [])
              }}
              className="col-span-2"
              component={Select}
            />
          </div>
        }
        bottom={
          <div className="grid grid-cols-9 gap-4 items-center">
            <LabeledField
              props={{
                ...inputProps('logTypeCode', '내용'),
                options: [{ label: '전체', value: '' }], //...(filterList?.logStatusCode ?? [])
              }}
              className="col-span-2"
              component={Select}
            />
          </div>
        }
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          <div className="flex gap-2">
            <Button onClick={handleCreate}>다운로드</Button>
          </div>
        </div>
        <Table
          {...{
            columns,
            data,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
          }}
        />
      </div>
    </div>
  );
}
