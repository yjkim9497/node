export default function List({ paths }) {
  return <div>임시 목록</div>;
}
