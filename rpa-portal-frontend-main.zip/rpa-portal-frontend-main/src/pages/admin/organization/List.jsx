import OrgTree from '@components/common/OrgTree';

export default function List({ paths }) {
  return (
    <div>
      <OrgTree />
    </div>
  );
}
