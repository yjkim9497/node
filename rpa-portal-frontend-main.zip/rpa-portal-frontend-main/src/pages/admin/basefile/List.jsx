import Button from '@components/ui/Button';
import Table from '@components/ui/table/Table';
import { useFetch, useMutate } from '@hooks/useApi';
import { useAuthStore } from '@store/authStore';
import { useModalStore } from '@store/useModalStore';
import { useEffect, useMemo, useState } from 'react';
import { list, add, modify, remove } from '@api/commonApi';
import { attributeApi } from '@api/admin/attributeApi';
import { LabeledField } from '@components/common/LabeledField';
import Select from '@components/form/Select';
import Input from '@components/form/Input';
import FilterBar from '@components/common/FilterBar';
import DatePicker from '@components/form/DatePicker';
import { clsx } from 'clsx';
import ModifyPU from '@features/admin/attribute/basefile/ModifyPU';
import Toggle from '@components/ui/Toggle';
import Checkbox from '@components/form/Checkbox';

export default function List({ paths }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [menuFor, setMenuFor] = useState(null);

  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = { pageRowCount };
  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);
  const { mAsync: addBoard } = useMutate(add);
  const { mAsync: updateBoard } = useMutate(modify);
  // TODO basefileApi로 수정필요
  const { mAsync: updateToggle } = useMutate(attributeApi.basefile.setUseYn);

  useEffect(() => {
    if (menuFor == null) return;
    const onDocClick = () => setMenuFor(null);
    const onEsc = (e) => {
      if (e.key === 'Escape') setMenuFor(null);
    };
    document.addEventListener('click', onDocClick);
    document.addEventListener('keydown', onEsc);
    return () => {
      document.removeEventListener('click', onDocClick);
      document.removeEventListener('keydown', onEsc);
    };
  }, [menuFor]);

  const items = data?.content || [];

  const [toggleForm, setToggleForm] = useState({});
  const [toggleResetKey, setToggleResetKey] = useState(0);

  // 서버 데이터(useYn) 변동 시 토글 기본값 재적용
  const toggleSignature = useMemo(() => items.map((it) => `${it.id}:${it.useYn ? 1 : 0}`).join('|'), [items]);
  useEffect(() => {
    setToggleResetKey((k) => k + 1);
    setToggleForm({});
  }, [toggleSignature]);

  // ✅ 체크 변경 캐치 → API 호출
  const onToggleChangeCapture = (rowId) => (e) => {
    const t = e.target;
    if (!(t instanceof HTMLInputElement)) return;
    if (t.name !== `useYn-${rowId}`) return;
    const activationYn = t.checked ? 'Y' : 'N';
    updateToggle({ paths, activationYn, ids: [rowId] });
  };

  const handleBulkCapture = (e) => {
    console.log('handleBulkCapture;', e.target.value);
    if (e.target.name !== 'bulkUseYn') return;
    const yn = e.target.value;
    if (yn !== 'Y' && yn !== 'N') return;

    const ids = Array.isArray(form.ids) ? form.ids : [];
    if (!ids.length) {
      modal.open({ content: '변경할 항목을 선택해주세요.' });
      setForm((prev) => ({ ...prev, bulkUseYn: '' }));
      return;
    }
    console.log('ready for updateToggle', ids);
    updateToggle({ paths, activationYn: yn, ids });

    const nextChecked = yn === 'Y';

    setToggleForm((prev) => {
      const copy = { ...prev };
      ids.forEach((id) => {
        copy[`useYn-${id}`] = nextChecked;
      });
      return copy;
    });

    setForm((prev) => ({ ...prev, bulkUseYn: '' }));
  };

  const columns = [
    { key: 'checkbox', label: '', width: 'w-8' },
    { key: 'typeNm', label: '유형명', width: 'w-32' },
    { key: 'description', label: '설명', width: 'w-60' },
    { key: 'templateYn', label: '템플릿여부', width: 'w-24' },
    { key: 'approvalYn', label: '결제필요여부', width: 'w-24' },
    { key: 'modAt', label: '최종수정일자', width: 'w-32', sortKey: 'actionAt', sortOrder: filter.sortOrder },
    { key: 'modId', label: '최종 수정자', width: 'w-28' },
    {
      key: 'useYnCell',
      label: '사용',
      width: 'w-12',
      render: (row) => {
        const inputName = `useYn-${row.id}`;

        return (
          <div
            className="relative flex items-center justify-center gap-2"
            onClick={(e) => e.stopPropagation()} // 행 클릭과 분리
            onChangeCapture={onToggleChangeCapture(row.id)}
          >
            {/* 디자인 전용 Toggle: 내부에 peer 체크박스 삽입 */}
            <Toggle size="sm" title={row.useYn ? '사용' : '중지'}>
              <Checkbox
                id={inputName}
                name={inputName}
                form={toggleForm}
                setForm={setToggleForm}
                defaultValue={!!row.useYn} // 서버값 -> 초기 체크 상태
                resetKey={toggleResetKey} // 데이터 바뀔 때마다 초기화
                className="sr-only peer" // 디자인은 peer 상태로 결정
              />
            </Toggle>

            {/* 3dots (vertical) — SVG에 onClick */}
            <svg
              viewBox="0 0 20 20"
              className="w-5 h-5 cursor-pointer hover:opacity-80 shrink-0"
              role="button"
              aria-label="옵션 열기"
              onClick={(e) => {
                e.stopPropagation();
                setMenuFor((prev) => (prev === row.id ? null : row.id));
              }}
            >
              <circle cx="10" cy="3" r="2"></circle>
              <circle cx="10" cy="10" r="2"></circle>
              <circle cx="10" cy="17" r="2"></circle>
            </svg>
            {/* 작은 메뉴 */}
            {menuFor === row.id && (
              <div
                className="absolute top-6 right-0 z-30 w-28 rounded-md border border-gray-200 bg-white shadow-lg"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  className="w-full px-3 py-2 text-left text-sm hover:bg-gray-50"
                  onClick={() => {
                    setSelectedId(row.id);
                    setModalOpen(true);
                    setMenuFor(null);
                  }}
                >
                  수정
                </button>
                <button
                  className="w-full px-3 py-2 text-left text-sm text-red-600 hover:bg-red-50"
                  onClick={() => {
                    setMenuFor(null);
                    modal.open({
                      content: '이 항목을 삭제하시겠습니까?',
                      onConfirm: async () => {
                        await deleteBoard({ paths, ids: [row.id] });
                      },
                    });
                  }}
                >
                  삭제
                </button>
              </div>
            )}
          </div>
        );
      },
    },
  ];

  const selectedItem = items.find((it) => String(it.id) === String(selectedId)) || null;

  const openForCreate = () => {
    setSelectedId(null);
    setResetKey((k) => k + 1);
    setModalOpen(true);
  };

  function handleRowClick(row) {
    setSelectedId(row.id);
    setModalOpen(true);
  }

  async function handleSubmitFromModal(draft) {
    const id = draft.id ?? selectedId;
    const payload = {
      ...draft,
      useYn: !!draft.useYn,
      templateYn: !!draft.templateYn,
      approvalYn: !!draft.approvalYn,
      ...(id ? { id } : {}),
    };

    if (id) {
      await updateBoard({ paths, params: payload });
    } else {
      await addBoard({ paths, params: payload });
    }
    setModalOpen(false);
  }

  async function handleSubmit(payload) {
    console.log('payload;', payload);
    if (selectedId != null) {
      await updateBoard({ paths, params: { ...payload, id: selectedId } });
    } else {
      await addBoard({ paths, params: payload });
    }
    setModalOpen(false);
  }

  async function handleDelete(id) {
    await deleteBoard({ paths, id });
    setModalOpen(false);
  }

  const onDeleteLists = async () => {
    let content = '삭제할 항목을 선택해주세요';
    let onConfirm;
    console.log('form.ids;', form.ids);
    if (form.ids?.length) {
      content = `${form.ids.length}개 항목을\n삭제하시겠습니까?`;
      onConfirm = async () => {
        await deleteBoard({ paths, ids: form.ids });
      };
    }
    modal.open({ content, onConfirm });
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name] || '',
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });
  console.log('data;', data);

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            <LabeledField
              props={{
                ...inputProps('typeNm', '유형명'),
                options: (items ?? []).reduce(
                  (acc, el) => {
                    if (!acc.some((item) => item.value === el.typeNm)) {
                      acc.push({ label: el.typeNm, value: el.typeNm });
                    }
                    return acc;
                  },
                  [{ label: '전체', value: '' }]
                ),
              }}
              className="col-span-2"
              component={Select}
            />
            <LabeledField
              props={inputProps('description', '설명')}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
          </div>
        }
        bottom={
          <div className="grid grid-cols-9 gap-4 items-center">
            <LabeledField
              props={{
                ...inputProps('useYn', '사용여부'),
                options: [
                  { label: '전체', value: '' },
                  { label: '사용', value: true },
                  { label: '사용안함', value: false },
                ],
              }}
              className="col-span-2"
              component={Select}
            />
            <LabeledField
              props={inputProps('modAt', '수정일자')}
              className="col-span-2"
              children={
                <div className="col-span-2 flex items-center gap-1">
                  <DatePicker
                    {...inputProps('occurStartDate', '시작일자')}
                    className={clsx(inputProps().className, 'flex-1 min-w-0')}
                  />
                  <span className="select-none">~</span>
                  <DatePicker
                    {...inputProps('occurEndDate', '종료일자')}
                    className={clsx(inputProps().className, 'flex-1 min-w-0')}
                  />
                </div>
              }
            />
          </div>
        }
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          {true && ( // TODO admin 전용
            <div className="flex gap-2" onChangeCapture={handleBulkCapture}>
              <LabeledField
                props={{
                  ...inputProps('bulkUseYn', ''),
                  options: [
                    { label: '사용여부변경', value: '' },
                    { label: '사용', value: 'Y' },
                    { label: '사용안함', value: 'N' },
                  ],
                }}
                className="col-span-2"
                component={Select}
                compClassName={'col-span-4'}
              />
              <Button variant="ghost" onClick={onDeleteLists}>
                삭제
              </Button>
              <Button onClick={openForCreate}>속성 등록</Button>
            </div>
          )}
        </div>
        <Table
          {...{
            columns,
            data,
            // tableData,
            filter,
            inputProps,
            onPageChange,
            pageRowCount,
          }}
        />
      </div>
      {/* 등록/수정 팝업 */}
      <ModifyPU
        visible={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={handleSubmitFromModal}
        params={selectedItem}
      />
    </div>
  );
}
