import Button from '@components/ui/Button';
import ROUTES from '@routes/routes.generated';
import FilterBar from '@components/common/FilterBar';
import { useAuthStore } from '@store/authStore';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import Table from '@components/ui/table/Table';
import Select from '@components/form/Select';
import Input from '@components/form/Input';
import { useModalStore } from '@store/useModalStore';
import { LabeledField } from '@components/common/LabeledField';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';

export default function List({ paths }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState({});
  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = {
    keyword: form.keyword || '',
    useYn: form.useYn || '',
    sortKey: form.sortKey || 'modifyAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const rowKey = (row, i) => row.robotSequence ?? row.id ?? i;

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);

  const items = data?.content || [];
  const subMenuList = [
    { content: '로봇 정보 조회 ' },
    { content: '동작 중지 ' },
    { content: '강제 종료 ' },
    { content: '재시작 ' },
    { content: '업무 중지 ' },
    { content: '수정 ' },
    { content: '삭제 ' },
  ];

  const columns = [
    { key: 'variableName', label: '항목명', width: 'w-24' },
    { key: 'settingValue', label: '설정 값', width: 'w-2' },
    { key: 'remarksContent', label: '설명', width: 'w-48' },
    { key: 'modifyAt', label: '최종 수정 일자', width: 'w-4', sortKey: 'modifyAt', sortOrder: filter.sortOrder },
    { key: 'B41', label: '', width: 'w-4' },
  ];

  async function handleRowClick(row) {
    //navigate(`${ROUTES.ROBOT_DETAIL.url}/${row?.robotSequence}`);
    // setSelected(row);
    //setModalOpen(true);
  }
  async function handleDelete(id) {
    await deleteBoard({ paths, id });
    setModalOpen(false);
  }

  const handleCreate = () => {
    // navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);
  };

  const onDeleteLists = async () => {
    let content = '삭제할 항목을 선택해주세요';
    let onConfirm;
    if (form.ids?.length) {
      content = `${form.ids.length}개 항목을\n삭제하시겠습니까?`;
      onConfirm = async () => {
        await deleteBoard({ paths, ids: form.ids });
      };
    }
    modal.open({ content, onConfirm });
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            <LabeledField
              props={inputProps('keyword', '변수명')}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
            <LabeledField
              props={{
                ...inputProps('useYn', '사용'),
                options: [
                  { label: '전체', value: '' },
                  { label: 'Y', value: 'Y' },
                  { label: 'N', value: 'N' },
                ],
              }}
              component={Select}
            />
          </div>
        }
        bottom={<div className="grid grid-cols-9 gap-4 items-center"></div>}
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          {superAuthYn && (
            <div className="flex gap-2">
              {/* <Button variant="ghost" onClick={onDeleteLists}>
                삭제
              </Button> */}
              <Button onClick={handleCreate}>변수 추가</Button>
            </div>
          )}
        </div>
        <Table
          {...{
            columns,
            data,
            tableData: items,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
            rowKey,
          }}
        />
      </div>
    </div>
  );
}
