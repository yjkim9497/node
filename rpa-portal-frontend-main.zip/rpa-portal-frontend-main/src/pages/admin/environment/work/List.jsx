export default function List({ paths }) {
  return <div> {paths?.join('')}</div>;
}
