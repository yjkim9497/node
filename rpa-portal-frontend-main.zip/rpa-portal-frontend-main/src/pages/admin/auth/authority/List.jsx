import Button from '@components/ui/Button';
import FilterBar from '@components/common/FilterBar';
import { useMemo, useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import Table from '@components/ui/table/Table';
import Select from '@components/form/Select';
import Input from '@components/form/Input';
import { useModalStore } from '@store/useModalStore';
import { LabeledField } from '@components/common/LabeledField';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';
import ManagePU from '@features/admin/auth/ManagePU';
import { useAuthStore } from '@store/authStore';

export default function List({ paths, DEL_ALL, DEL_ME, MOD_ALL, MOD_ME, tree }) {
  const [form, setForm] = useState({});
  const [selected, setSelected] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const modal = useModalStore();
  const { username, userid } = useAuthStore();

  const canDel = DEL_ALL || (DEL_ME && data?.authorId === userid);
  const canMod = MOD_ALL || (MOD_ME && data?.authorId === userid);

  const pageRowCount = 15;

  const filterData = {
    authorityName: form.authorityName || '',
    useYn: form.useYn || '',
    sortKey: form.sortKey || 'registerAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const rowKey = (row, i) => row.authoritySequence ?? row.id ?? i;

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);
  //const { data: filterList } = useFetch(filters, { paths });
  // console.log(filterList);

  const columns = [
    ...(DEL_ALL ? [{ key: 'checkbox', label: '', width: 'w-8' }] : []),
    { key: 'authorityName', label: '권한명 ', width: 'w-60' },
    { key: 'userCount', label: '사용자 수 ', width: 'w-12' },
    {
      key: 'modifyAt',
      label: '최종 수정 일자 ',
      width: 'w-12',
      sortKey: 'registerAt',
      sortOrder: filter.sortOrder,
    },
    { key: 'logFileGroupSequence', label: '', width: 'w-8' },
  ];

  async function handleRowClick(row) {
    setSelected(row);
    setModalOpen(true);
  }

  const handleCreate = () => {
    //navigate('reg');
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        onKeyDown={(e) => e.key === 'Enter' && setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            <LabeledField
              props={{
                ...inputProps('authorityName', '검색어'),
                placeholder: '권한명',
              }}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
            <LabeledField
              props={{
                ...inputProps('useYn', '사용여부'),
                options: [
                  { label: '전체', value: '' },
                  { label: '사용', value: 'Y' },
                  { label: '사용 안함', value: 'N' },
                ], //...(filterList?.logStatusCode ?? [])
              }}
              className="col-span-2"
              component={Select}
            />
          </div>
        }
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          <div className="flex justify-end mb-2 gap-2">
            <LabeledField
              props={{
                ...inputProps('use', ''),
                options: [
                  { label: '사용여부변경', value: '' },
                  { label: '사용', value: 'Y' },
                  { label: '사용안함', value: 'N' },
                ],
              }}
              className="col-span-2"
              component={Select}
              compClassName={'col-span-4'}
            />
            <Button variant="ghost" onClick={() => {}}>
              삭제
            </Button>
            <Button onClick={handleCreate}>권한 정보 추가</Button>
          </div>
        </div>
        <Table
          {...{
            columns,
            data,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
            rowKey,
          }}
        />
      </div>
      {modalOpen && <ManagePU {...{ paths, tree, selected, setModalOpen, canDel, canMod }} />}
    </div>
  );
}
