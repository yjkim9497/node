// src/pages/Login.jsx
import Input from '@components/form/Input';
import { add } from '@api/commonApi';
import { useMutate } from '@hooks/useApi';
import { createProps, validateForm } from '@utils/formHandlers';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import ROUTES from '@routes/routes.generated';
import { useAuthStore } from '@store/authStore';
import GridTable from '@components/ui/GridTable';
import Button from '@components/ui/Button';

export default function Password() {
  const { setAuth } = useAuthStore();
  const [form, setForm] = useState({});
  const { mAsync: login } = useMutate(add);

  const validatePassword = (pw) => {
    const passwordRegex =
      /^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=[\]{};:'",.<>/?\\|`~])[A-Za-z\d!@#$%^&*()_\-+=[\]{};:'",.<>/?\\|`~]{8,15}$/;
    return passwordRegex.test(pw);
  };

  const submit = async () => {
    if (!validateForm()) return;
    const data = await login({ paths: ['/auth'], params: { ...form, suffix: 'login' } });
    setAuth(data);
    navigate(ROUTES.DASHBOARD.url);
  };

  const inputProps = (name, label) =>
    createProps({
      name,
      label,
      form,
      setForm,
      required: true,
      type: 'password',
      className: 'w-full border p-2 rounded',
    });

  const newPassConfirm = form.newPass2 && form.newPass2 !== form.newPass1;

  return (
    <div className="h-[85vh] flex items-center justify-center bg-gray-50">
      <div
        className="relative flex flex-col space-y-4 bg-white p-6 rounded shadow-md w-[40vw]"
        onKeyDown={(e) => e.key === 'Enter' && submit()}
      >
        <h1 className="text-xl font-bold mb-4">
          <span style={{ fontSize: '50px' }}>🔒</span>비밀번호 재설정
        </h1>
        <GridTable
          data={form}
          rows={[
            {
              key: 'prev',
              label: '현재 비밀번호',
              class: 'flex-col relative p-2',
              value: <Input {...inputProps('prev', '현재 비밀번호')} />,
            },
            {
              key: 'pass1',
              label: '새 비밀번호',
              class: 'flex-col relative p-2',
              value: (
                <>
                  <Input {...inputProps('newPass1', '새 비밀번호 ')} />
                  {!validatePassword(form.newPass1) && (
                    <span className="px-2 pt-2 text-red-600">
                      영문, 숫자, 특수문자를 포함하여 8~15자로 설정해주세요.
                    </span>
                  )}
                </>
              ),
            },
            {
              key: 'pass2',
              label: '새 비밀번호 확인',
              class: 'flex-col relative p-2',
              value: (
                <>
                  <Input {...inputProps('newPass2', '새 비밀번호 확인')} />
                  {newPassConfirm && <span className="px-2 pt-2 text-red-600">비밀번호가 일치하지 않습니다.</span>}
                </>
              ),
            },
          ]}
          total={8}
          lSpan={2}
        />
        <Button variant="primary" size="lg" shape="square" style={{ alignSelf: 'center' }} onClick={submit}>
          변경하기
        </Button>
      </div>
    </div>
  );
}
