import { useRef, useState, useEffect } from 'react';
import TaskFilter from '@features/calendar/TaskFilter';
import CalendarView from '@features/calendar/CalendarView';
import { useFetch } from '@hooks/useApi';
import { getTasks } from '@api/calendarApi';

export default function Calendar() {
  const [taskFilter, setTaskFilter] = useState({ search: '', team: '전체' });
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [isTodayInRange, setIsTodayInRange] = useState(false);
  const [view, setView] = useState('timeGridWeek');
  const [calendarTitle, setCalendarTitle] = useState('');
  const calendarRef = useRef(null);

  const [showWeekends, setShowWeekends] = useState(true);
  const [narrowWeekends, setNarrowWeekends] = useState(false);
  const [startMonday, setStartMonday] = useState(false);

  const toggleWeekends = () => setShowWeekends((prev) => !prev);
  const toggleNarrowWeekends = () => setNarrowWeekends((prev) => !prev);
  const toggleStartMonday = () => setStartMonday((prev) => !prev);

  const tasksQuery = useFetch(getTasks);

  // useEffect에서 tasksQuery.data가 존재할 때만 selectedTasks 초기화
  useEffect(() => {
    if (!tasksQuery.data) return;

    if (taskFilter.team === '전체') {
      setSelectedTasks(tasksQuery.data.map((t) => t.id));
    } else {
      const teamTasks = tasksQuery.data.filter((t) => t.team === taskFilter.team).map((t) => t.id);
      setSelectedTasks(teamTasks);
    }
  }, [tasksQuery.data, taskFilter.team]);

  // 필터 적용
  const filteredTasks = (tasksQuery.data || []).filter((t) => {
    const matchName = t.title.includes(taskFilter.search);
    const matchTeam = taskFilter.team === '전체' || t.team === taskFilter.team;
    return matchName && matchTeam;
  });

  const tasksForCalendar = filteredTasks.filter((t) => selectedTasks.includes(t.id));

  return (
    <div className="flex h-screen overflow-none">
      {/* 좌측 패널 */}
      <div className="w-1/5 border-r flex flex-col">
        <TaskFilter
          tasks={tasksQuery.data || []} // optional chaining + 빈 배열 기본값
          selectedTasks={selectedTasks}
          setSelectedTasks={setSelectedTasks}
          taskFilter={taskFilter}
          setTaskFilter={setTaskFilter}
        />
      </div>

      {/* 우측 캘린더 */}
      <div className="flex-1 flex flex-col">
        <div className="flex items-center gap-2 p-2 bg-white border-b shadow">
          <select className="p-1 border rounded bg-white" value={view} onChange={(e) => setView(e.target.value)}>
            <option value="dayGridMonth">월</option>
            <option value="timeGridWeek">주</option>
            <option value="timeGridDay">일</option>
          </select>

          <button
            onClick={() => calendarRef.current?.getApi().today()}
            className={`flex items-center gap-1 px-3 py-1 rounded font-medium text-sm border
              ${isTodayInRange ? 'bg-gray-500 text-white' : 'hover:bg-gray-400 hover:text-white'}`}
          >
            <span /> 오늘 {/* className="fc-icon fc-icon-calendar" */}
          </button>

          {view !== 'timeGridDay' && (
            <div className="flex gap-4 p-2">
              <label>
                <input type="checkbox" className="mr-1" checked={showWeekends} onChange={toggleWeekends} />
                주말 보기
              </label>

              <label>
                <input type="checkbox" className="mr-1" checked={narrowWeekends} onChange={toggleNarrowWeekends} />
                주말 좁게
              </label>

              <label>
                <input type="checkbox" className="mr-1" checked={startMonday} onChange={toggleStartMonday} />
                월요일부터 시작
              </label>
            </div>
          )}
        </div>
        <div className="flex flex-row flex-wrap items-center justify-center font-bold text-lg gap-4 p-2">
          <button
            className="p-2 border rounded flex items-center justify-center"
            onClick={() => calendarRef.current?.getApi().prev()}
          >
            <span className="fc-icon fc-icon-chevron-left"></span>
          </button>
          {calendarTitle}
          <button
            className="p-2 border rounded flex items-center justify-center"
            onClick={() => calendarRef.current?.getApi().next()}
          >
            <span className="fc-icon fc-icon-chevron-right"></span>
          </button>
        </div>

        <div className="flex-1">
          <CalendarView
            ref={calendarRef}
            events={tasksForCalendar}
            form={{ showWeekends, narrowWeekends, startMonday }}
            view={view}
            setView={setView}
            setCalendarTitle={setCalendarTitle}
            setIsTodayInRange={setIsTodayInRange}
          />
        </div>
      </div>
    </div>
  );
}
