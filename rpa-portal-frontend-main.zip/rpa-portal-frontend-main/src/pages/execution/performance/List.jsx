// src/pages/Performance.jsx
import { fetchErrorSummary, fetchExecutionData, fetchResultData, fetchSummaryKpi } from '@api/performanceApi';
import Tabs from '@components/layout/Tabs';
import ChartPanel from '@features/performance/ChartPanel';
import DonutChart from '@features/performance/DonutChart';
import Filters from '@features/performance/Filters';
import SummaryCards from '@features/performance/SummaryCards';
import { useFetch } from '@hooks/useApi';
import { downloadExcel } from '@utils/excel';
import { useState } from 'react';

export default function Performance() {
  const [period, setPeriod] = useState('당일');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [range, setRange] = useState({ start: '', end: '' });
  const [workName, setWorkName] = useState('전체');
  const [title, setTitle] = useState('내 업무');

  const { data: execution } = useFetch(fetchExecutionData, { date, workName, period, range });
  const { data: results } = useFetch(fetchResultData, { date, workName, period, range });
  const { data: summary } = useFetch(fetchErrorSummary, { date, workName, period, range });
  const { data: kpi } = useFetch(fetchSummaryKpi, { date, workName, period, range });

  const setTab = (tab) => {
    setTitle(tab.title);
  };

  const tabs = [
    { title: '내 업무', action: setTab },
    { title: '부서별', action: setTab },
    { title: '단위업무별', action: setTab },
    { title: '로봇별', action: setTab },
  ];

  const handleExcel = () =>
    downloadExcel({
      date,
      period,
      workName,
      execution,
      results,
      summary,
      kpi,
    });

  return (
    <>
      <Tabs items={tabs} title={title} />
      <div className="space-y-6">
        <Filters
          period={period}
          setPeriod={setPeriod}
          date={date}
          setDate={setDate}
          range={range}
          setRange={setRange}
          workName={workName}
          setWorkName={setWorkName}
          onDownloadExcel={handleExcel}
        />

        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 grid grid-cols-2 gap-6">
            {/* ChartPanel handles variable-length series */}
            <ChartPanel title="업무 실행 건수" leftMode execution={execution} />
            <ChartPanel title="정상/오류 건수" results={results} />
          </div>

          <div className="justify-items-start">
            <DonutChart summary={summary} />
          </div>
        </div>

        <SummaryCards summary={kpi} />
      </div>
    </>
  );
}
