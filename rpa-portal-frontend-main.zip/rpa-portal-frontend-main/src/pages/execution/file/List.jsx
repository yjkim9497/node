export default function List({ paths }) {
  return <div>수행관리_수행파일업로드</div>;
}
