// src/pages/List.tsx
import Table from '@components/ui/table/Table';
import { useState } from 'react';
import dayjs from 'dayjs';
import { statusUrgentMap } from '@utils/managerMapper';

const data = {
  content: [
    {
      robotSequence: 1,
      robotName: '로봇-A',
      status: '연결 됨',
      totalWorkTime: '00:12:40',
      waitinglistAddTime: '2025-09-21 09:30',
      currentWorkload: '문서 스캔',
      waitingWorkload: '보고서 업로드',
      children: [
        {
          workSequence: '1-1',
          workName: '문서 스캔',
          workExecuteInfo: '반복 실행',
          totalExecuteTimeMillis: '02:15:00',
          averageExecuteTimeMillis: '00:30:00',
          addWorkTime: '2025-09-21 09:30',
          waitingTimeHours: '5m',
          taskPriority: 'MED',
          deleteYn: 'N',
        },
        {
          workSequence: '1-2',
          workName: '보고서 업로드',
          workExecuteInfo: '수동 실행',
          totalExecuteTimeMillis: '00:00:00',
          averageExecuteTimeMillis: '00:20:00',
          addWorkTime: '2025-09-21 10:00',
          waitingTimeHours: '30m',
          taskPriority: 'HIGH',
          deleteYn: 'N',
        },
      ],
    },
    {
      robotSequence: 2,
      robotName: '로봇-B',
      status: '연결 됨',
      totalWorkTime: '08:20:00',
      waitinglistAddTime: '2025-09-21 11:15',
      currentWorkload: '데이터 백업',
      waitingWorkload: '배치 처리',
      children: [
        {
          workSequence: '2-1',
          workName: '데이터 백업',
          workExecuteInfo: '한 번만 실행',
          totalExecuteTimeMillis: '00:01:45',
          averageExecuteTimeMillis: '00:40:00',
          addWorkTime: '2025-09-21 11:15',
          waitingTimeHours: '00:12:25',
          taskPriority: 'MED',
          deleteYn: 'N',
        },
        {
          workSequence: '2-2',
          workName: '배치 처리',
          workExecuteInfo: '즉시 실행',
          totalExecuteTimeMillis: '01:12:25',
          averageExecuteTimeMillis: '00:25:00',
          addWorkTime: '2025-09-21 11:30',
          waitingTimeHours: '00:20:00',
          taskPriority: 'LOW',
          deleteYn: 'Y',
        },
        {
          workSequence: '2-3',
          workName: '배치 처리',
          workExecuteInfo: '연계 업무',
          totalExecuteTimeMillis: '01:12:25',
          averageExecuteTimeMillis: '02:25:00',
          addWorkTime: '2025-09-21 11:30',
          waitingTimeHours: '00:20:00',
          taskPriority: 'LOW',
          deleteYn: 'Y',
        },
      ],
    },
    {
      robotSequence: 3,
      robotName: '로봇-C',
      status: '연결 안됨',
      totalWorkTime: '00:08:20',
      waitinglistAddTime: '2025-09-21 11:15',
      currentWorkload: '데이터 백업',
      waitingWorkload: '배치 처리',
    },
  ],
};

export default function Queue() {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState({});
  const [page, setPage] = useState(1);
  const pageRowCount = 15;

  const items = data?.content || [];
  const totalPages = Math.max(1, Math.ceil(data.content.length / pageRowCount));
  const paginated = items.slice((page - 1) * pageRowCount, page * pageRowCount);

  const columns = [
    { key: 'expand', label: '', width: 'w-8' },
    { key: 'robotName', label: '로봇명', width: 'w-32' },
    { key: 'status', label: '상태', width: 'w-24' },
    { key: 'totalWorkTime', label: '누적업무시간', width: 'w-32' },
    { key: 'waitinglistAddTime', label: '대기열추가시간', width: 'w-32' },
    { key: 'currentWorkload', label: '실행중업무', width: 'w-32' },
    { key: 'waitingWorkload', label: '대기중업무', width: 'w-28' },
  ];

  const childColumns = [
    { key: 'marker', label: '', width: 'w-6' },
    { key: 'checkbox', label: '', width: 'w-8' },
    { key: 'workName', label: '업무명', width: 'w-32' },
    { key: 'workExecuteInfo', label: '업무실행정보', width: 'w-24' },
    {
      header: '업무시간',
      children: [
        { key: 'totalExecuteTimeMillis', label: '누적업무시간', width: 'w-24' },
        { key: 'averageExecuteTimeMillis', label: '평균업무시간', width: 'w-24' },
      ],
    },
    { key: 'addWorkTime', label: '대기열추가시간', width: 'w-24' },
    { key: 'waitingTimeHours', label: '업무대기시간', width: 'w-24' },
    { key: 'taskPriority', label: '우선순위', width: 'w-24' },
    { key: 'deleteYn', label: '삭제', width: 'w-10' },
  ];

  const tableData = paginated.map((item) => ({
    ...item,
    taskPriority: statusUrgentMap[item?.taskPriority],
    waitinglistAddTime: dayjs(item.waitinglistAddTime).format('YYYY-MM-DD HH:mm'),
    addWorkTime: item.children?.addWorkTime ? dayjs(item.children.addWorkTime).format('YYYY-MM-DD HH:mm') : '-',
  }));

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
  });

  return (
    <div>
      <Table
        columns={columns}
        childColumns={childColumns}
        data={{
          content: tableData,
          page,
          totalPages,
          totalCount: items.length,
        }}
        pageRowCount={pageRowCount}
        onPageChange={setPage}
        inputProps={inputProps}
        rowKey={(row, i) => row.workSequence ?? row.id ?? i}
        aligns="left"
      />
    </div>
  );
}
