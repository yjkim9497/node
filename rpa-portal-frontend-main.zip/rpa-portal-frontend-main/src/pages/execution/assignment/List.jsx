import Button from '@components/ui/Button';
import FilterBar from '@components/common/FilterBar';
import { useAuthStore } from '@store/authStore';
import { useEffect, useMemo, useState } from 'react';
import Table from '@components/ui/table/Table';
import Select from '@components/form/Select';
import Input from '@components/form/Input';
import { useModalStore } from '@store/useModalStore';
import { LabeledField } from '@components/common/LabeledField';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';
import DetailPU from '@features/community/incident/DetailPU';
import DotDotDot from '@components/common/DotDotDot';
import Toggle from '@components/ui/Toggle';

export default function List({ paths }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState({});
  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  const modal = useModalStore();

  const pageRowCount = 15;

  const filterData = {
    workName: form.workName || '',
    robotName: form.robotName || '',
    useYn: form.useYn || '',
    groupSequence: form.groupSequence || 1,
    sortKey: form.sortKey || 'workName',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const rowKey = (row, i) => row.workSequence ?? row.id ?? i;

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);

  const items = data?.content || [];

  const [toggleResetKey, setToggleResetKey] = useState(0);

  // 서버 데이터(useYn) 변동 시 토글 기본값 재적용
  const toggleSignature = useMemo(
    () => items.map((it) => `${it.workSequence}:${it.activationYn ? 1 : 0}`).join('|'),
    [items]
  );
  useEffect(() => {
    setToggleResetKey((k) => k + 1);
  }, [toggleSignature]);

  // 체크 변경 캐치 → API 호출
  const onToggleChangeCapture = (rowId) => (e) => {
    // const t = e.target;
    // if (!(t instanceof HTMLInputElement)) return;
    // if (t.name !== `activationYn-${row.workSequence}`) return;
    // const activationYn = t.checked ? 'Y' : 'N';
    // updateToggle({ paths, activationYn, ids: [rowId] });
  };

  const subMenuList = [
    { content: '업무 정보 조회 ', onClick: () => {} },
    { content: '즉시 실행 ', onClick: () => {} },
    { content: '즉시 실행 업무 강제 종료 ', onClick: () => {} },
    { content: '업무 내보내기 ', onClick: () => {} },
    { content: '수정 ', onClick: () => {} },
    { content: '삭제 ', onClick: () => {} },
  ];

  const columns = [
    { key: 'checkbox', label: '', width: 'w-2' },
    {
      label: '업무명',
      key: 'workName',
      children: [
        { key: 'robotNameList', label: '로봇', width: 'w-12' },
        { key: 'executeInfo', label: '업무 실행 정보', width: 'w-24' },
        { key: 'nextExecuteDate', label: '다음 실행 일자', width: 'w-12' },
      ],
    },
    {
      label: '작업 우선 순위',
      key: 'workPriority',
      children: [{ key: 'workDurationMinutes', label: '최근 소요 시간', width: 'w-8' }],
    },
    { key: 'processVersionSequence', label: '수행 난이도', width: 'w-8' },
    { label: '최종 수정자', key: 'modifyId', children: [{ key: 'modifyAt', label: '최종 수정 일자', width: 'w-16' }] },

    {
      key: 'activationYn',
      label: '사용',
      width: 'w-6',
      render: (row) => {
        const inputName = `activationYn-${row.workSequence}`;

        return (
          <div
            className="relative flex items-center justify-center gap-2"
            onClick={(e) => e.stopPropagation()} // 행 클릭과 분리
            onChangeCapture={onToggleChangeCapture(row.id)}
          >
            {/* 디자인 전용 Toggle: 내부에 peer 체크박스 삽입 */}
            <Toggle size="sm" title={row.activationYn ? '사용' : '중지'}>
              <input
                type="checkbox"
                id={inputName}
                name={inputName}
                defaultValue={row.activationYn} // 서버값 -> 초기 체크 상태
                className="sr-only peer" // 디자인은 peer 상태로 결정
                // onClick={(e) => {
                //   e.preventDefault();
                //   row.activationYn = !row.activationYn;
                // }}
              />
            </Toggle>
            <DotDotDot list={subMenuList} />
          </div>
        );
      },
    },
  ];

  async function handleRowClick(row) {
    //navigate(`${ROUTES.COMMUNITY_INCIDENT_DETAIL.url}/${row.id}`);
    //setSelected(row);
    //setModalOpen(true);
  }
  async function handleDelete(id) {
    await deleteBoard({ paths, ids: [id] });
    setModalOpen(false);
  }

  const handleCreate = () => {
    //  navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);
  };

  const onDeleteLists = async () => {
    let content = '삭제할 항목을 선택해주세요';
    let onConfirm;
    if (form.ids?.length) {
      content = `${form.ids.length}개 항목을\n삭제하시겠습니까?`;
      onConfirm = async () => {
        await deleteBoard({ paths, ids: form.ids });
      };
    }
    modal.open({ content, onConfirm });
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        onKeyDown={(e) => e.key === 'Enter' && setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            <LabeledField
              props={{
                ...inputProps('robotName', '로봇명'),
                placeholder: '로봇명',
              }}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
            <LabeledField
              props={{
                ...inputProps('useYn', '사용여부'),
                options: [
                  { label: '전체', value: '' },
                  { label: 'Y', value: 'Y' },
                  { label: 'N', value: 'N' },
                ],
              }}
              component={Select}
            />
            <LabeledField
              props={{
                ...inputProps('groupSequence', '작업 그룹'),
                options: [{ label: '전체', value: '' }],
                defaultValue: 1,
              }}
              component={Select}
            />
          </div>
        }
        bottom={
          <div className="grid grid-cols-9 gap-4 items-center">
            <LabeledField
              props={{
                ...inputProps('workName', '검색어'),
                placeholder: '업무명',
              }}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
          </div>
        }
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          {superAuthYn && (
            <div className="flex gap-2">
              <Button variant="ghost" onClick={onDeleteLists}>
                삭제
              </Button>
              <Button onClick={handleCreate}>작업 추가</Button>
            </div>
          )}
        </div>
        <Table
          {...{
            columns,
            data,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
            rowKey,
            aligns: 'left',
          }}
        />
      </div>
      {modalOpen && <DetailPU {...{ paths, selected, setSelected, handleDelete, setModalOpen }} />}
    </div>
  );
}
