import { detail, remove } from '@api/commonApi';
import Button from '@components/ui/Button';
import FileManager from '@components/form/FileManager';
import GridTable from '@components/ui/GridTable';
import Table from '@components/ui/table/Table';
import NoticePU from '@features/community/incident/NoticePU';
import { useFetch, useMutate } from '@hooks/useApi';
import { navigate } from '@routes/NavigationProvider';
import ROUTES from '@routes/routes.generated';
import { useAuthStore } from '@store/authStore';
import { useState } from 'react';
import { useParams } from 'react-router-dom';

const Detail = ({ paths }) => {
  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  const [form, setForm] = useState({});

  const [modalOpen, setModalOpen] = useState(false);
  const [noticeInfo, setNoticeInfo] = useState(false);
  const { id } = useParams();

  const pageRowCount = 15;

  const filterData = {
    keyword: form.keyword || '',
    title: form.title || '',
    status: form.status || '',
    occurStartDate: form.occurStartDate || '',
    occurEndDate: form.occurEndDate || '',
    sortKey: form.sortKey || 'occurAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const [filter, setFilter] = useState(filterData);
  const { data } = useFetch(detail, { paths, id });
  const { mAsync: deleteBoard } = useMutate(remove);

  const columns = [
    { key: 'B4', label: '업무명 ', width: 'w-16' },
    { key: 'C4', label: '업무 실행 정보 ', width: 'w-16' },
    { key: 'D4', label: '최근 실행 일자 ', width: 'w-16' },
    { key: 'E4', label: '다음 실행 일자 ', width: 'w-16' },
    { key: 'F4', label: '작업 우선 순위', width: 'w-16' },
  ];

  async function handleRowClick(row) {
    //navigate(`${ROUTES.COMMUNITY_INCIDENT_DETAIL.url}/${row.id}`);
    //setSelected(row);
    //setModalOpen(true);
  }

  async function handleDelete() {
    await deleteBoard({ paths, ids: [id] });
  }

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div className="pr-6 py-6 max-w-7xl space-y-4 mx-auto bg-white shadow rounded">
      <div className="w-full flex justify-between gap-2">
        <h3>■ {data?.robot?.[0]?.robotName}</h3>
        <Button children={'새로고침'} variant="ghost" onClick={() => {}} />
      </div>
      <GridTable
        data={data?.robot?.[0]}
        rows={[
          {
            key: 'robotInfo',
            label: '로봇 정보',
            lAlign: 'center',
            children: [
              { key: 'groupSequence', label: '작업 그룹' },
              { key: 'a2', label: '행번' },
              { key: 'pcIpAddress', label: '연결 PC IP' },
              { key: 'pcName', label: '연결 PC명' },
            ],
            rowSpan: 4,
            colNum: 2,
          },
          { key: 'statusLable', label: '로봇 상태', valueSpan: 0, colNum: 2 },
          { key: 'robotStatusCodeName', labelSpan: 0, rowSpan: 4, colNum: 2 },
          {
            key: 'vncServerIpAddress/vncServerPort',
            label: '로봇 모니터링 정보 (접속 IP / 접속 포트)',
            delimiter: '/',
          },
          { key: 'backgroundExecuteYn', label: '로봇 백그라운드 기본 실행', colNum: 2 },
          { key: 'b2', label: 'CPU/메모리/HDD', valueSpan: 0, colNum: 2 },
          { key: 'unlockExecuteYn', label: '로봇 PC 윈도우 잠금 해제', colNum: 2 },
          { key: 'cpuUseRate/memUseRate/hddUsgInfo', labelSpan: 0, rowSpan: 5, colNum: 2, delimiter: '/' },
          {
            label: '로봇 PC 윈도우 로그인 계정 정보',
            lAilgn: 'center',
            children: [
              { key: 'pcWindowId', label: '아이디' },
              { key: 'pcWindowPw', label: '비밀번호' },
            ],
            rowSpan: 2,
            colNum: 2,
          },
          { key: 'useScopeCodeName', label: '사용범위', colNum: 2 },
          { key: 'robotVersion', label: '설치 버전', colNum: 2 },
          {
            key: 'b8',
            label: '알람 설정 정보',
            class: 'p-0',
            value: (
              <div className="flex flex-col w-full gap-2">
                <Button
                  style={{ width: 'max-content', margin: '0.5rem' }}
                  onClick={() => setNoticeInfo((prev) => !prev)}
                >
                  {noticeInfo ? '닫기' : '보기'}
                </Button>
                {noticeInfo && (
                  <Table
                    columns={[
                      { key: 'staffName', label: '이름 ', width: 'w-16' },
                      { key: 'staffEmail', label: '이메일 ', width: 'w-16' },
                      { key: 'staffMobile', label: '휴대폰', width: 'w-16' },
                      { key: 'staffMessengerId', label: '메신저', width: 'w-16' },
                      {
                        label: '알림 대상',
                        children: [
                          { key: 'connectRobotYn', label: '로봇 연결', width: 'w-16' },
                          { key: 'disconnectRobotYn', label: '로봇 연결 해제', width: 'w-16' },
                        ],
                        width: 'w-16',
                      },
                    ]}
                    data={{ ...data, content: data?.robotStaffList }}
                    aligns="left"
                  />
                )}
              </div>
            ),
          },
        ]}
        total={24}
        lSpan={6}
        lAlign="center"
      />
      <div className="w-full flex justify-start gap-2">
        <h3>■ 할당 업무 정보</h3>
        <Button children={'업무 실행 이력 보기'} variant="ghost" onClick={() => setModalOpen(true)} />
        <Button children={'대기 중 업무 보기: 4'} variant="ghost" onClick={() => setModalOpen(true)} />
      </div>
      <Table
        {...{
          columns,
          data,
          filter,
          inputProps,
          onRowClick: handleRowClick,
          onPageChange,
          pageRowCount,
        }}
      />
      <div className="w-full flex justify-end mb-2 gap-2">
        <div className="flex space-x-2">
          {superAuthYn && (
            <>
              <Button children={'삭제'} variant="secondary" onClick={() => handleDelete()} />
              <Button
                children={'수정'}
                onClick={() => {
                  navigate(`edit/${id}`);
                }}
              />
            </>
          )}

          <Button children={'목록'} variant="secondary" onClick={() => navigate('list')} />
        </div>
      </div>

      {/* {modalOpen ? <NoticePU {...{ paths, setModalOpen }} data={form} /> : <></>} */}
    </div>
  );
};

export default Detail;
