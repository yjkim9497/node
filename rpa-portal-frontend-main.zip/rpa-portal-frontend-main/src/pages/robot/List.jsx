import Button from '@components/ui/Button';
import ROUTES from '@routes/routes.generated';
import FilterBar from '@components/common/FilterBar';
import { useAuthStore } from '@store/authStore';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import Table from '@components/ui/table/Table';
import Select from '@components/form/Select';
import Input from '@components/form/Input';
import { useModalStore } from '@store/useModalStore';
import { LabeledField } from '@components/common/LabeledField';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';
import DotDotDot from '@components/common/DotDotDot';

export default function List({ paths }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState({});
  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = {
    keyword: form.keyword || '',
    robotName: form.robotName || '',
    robotStatusCode: '',
    groupSequence: 1,
    groupSequenceList: [],
    sortKey: form.sortKey || 'registerAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { mAsync: deleteBoard } = useMutate(remove);

  const items = data?.content || [];
  const subMenuList = [
    { content: '로봇 정보 조회 ', onClick: () => {} },
    { content: '동작 중지 ', onClick: () => {} },
    { content: '강제 종료 ', onClick: () => {} },
    { content: '재시작 ', onClick: () => {} },
    { content: '업무 중지 ', onClick: () => {} },
    { content: '수정 ', onClick: () => {} },
    { content: '삭제 ', onClick: () => {} },
  ];

  const columns = [
    { key: 'checkbox', label: '', width: 'w-8' },
    { key: 'robotName', label: '로봇명', width: 'w-32' },
    { key: 'robotVersion', label: '버전', width: 'w-24' },
    {
      key: 'lastActionAt',
      label: '최종 동작 일자',
      width: 'w-32',
      sortKey: 'occurAt',
      sortOrder: filter.sortOrder,
    },
    {
      key: 'lastExecuteWorkSequence',
      label: '최종 실행 업무',
      width: 'w-32',
      sortKey: 'actionAt',
      sortOrder: filter.sortOrder,
    },
    { key: 'robotStatusCode', label: '상태', width: 'w-24' },
    { key: 'cpuUseRate/memUseRate/hddUsgInfo', label: 'CPU/메모리/HDD', width: 'w-28', delimiter: '/' },
    { key: 'robotss', label: '', content: <DotDotDot list={subMenuList} />, width: 'w-12' },
  ];

  async function handleRowClick(row) {
    setSelected(row);
    setModalOpen(true);
  }
  async function handleDelete(id) {
    await deleteBoard({ paths, id });
    setModalOpen(false);
  }

  const handleCreate = () => {
    // navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);
  };

  const onDeleteLists = async () => {
    let content = '삭제할 항목을 선택해주세요';
    let onConfirm;
    if (form.ids?.length) {
      content = `${form.ids.length}개 항목을\n삭제하시겠습니까?`;
      onConfirm = async () => {
        await deleteBoard({ paths, ids: form.ids });
      };
    }
    modal.open({ content, onConfirm });
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <div>
      <FilterBar
        onReset={() => setResetKey((k) => k + 1)}
        onSearch={() => setFilter(filterData)}
        top={
          <div className="grid grid-cols-9 gap-4 items-center mb-4">
            <LabeledField
              props={inputProps('keyword', '검색어')}
              className="col-span-2"
              component={Input}
              compClassName={'col-span-2'}
            />
          </div>
        }
        bottom={
          <div className="grid grid-cols-9 gap-4 items-center">
            <LabeledField
              props={{
                ...inputProps('status', '상태'),
                options: [
                  { label: '전체', value: '' },
                  { label: '조치대기', value: 'WAIT' },
                  { label: '조치중', value: 'ING' },
                  { label: '완료', value: 'COMPLETE' },
                ],
              }}
              className="col-span-2"
              component={Select}
            />
            <LabeledField
              props={{
                ...inputProps('groupSequence', '작업 그룹'),
                options: (items ?? []).reduce(
                  (acc, el) => {
                    if (!acc.some((item) => item.value === el.systemName)) {
                      acc.push({ label: el.systemName, value: el.systemName });
                    }
                    return acc;
                  },
                  [{ label: '전체', value: '' }]
                ),
              }}
              className="col-span-2"
              component={Select}
            />
          </div>
        }
      />
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          {superAuthYn && (
            <div className="flex gap-2">
              <Button onClick={handleCreate}>로봇 모니터링</Button>
              <Button onClick={handleCreate}>로봇 제어</Button>
              <Button variant="ghost" onClick={onDeleteLists}>
                삭제
              </Button>
              <Button onClick={handleCreate}>로봇 추가</Button>
              <DotDotDot
                list={[{ content: '프로필 내보내기' }, { content: '프로필 가져오기' }, { content: '버전 업데이트' }]}
              />
            </div>
          )}
        </div>
        <Table
          {...{
            columns,
            data,
            tableData: items,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
          }}
        />
      </div>
    </div>
  );
}
