// src/pages/admin/pblresource/variable/List.jsx
import Button from '@components/ui/Button';
import Table from '@components/ui/table/Table';
import { useFetch, useMutate } from '@hooks/useApi';
import { useAuthStore } from '@store/authStore';
import { useModalStore } from '@store/useModalStore';
import { useEffect, useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import { list, detail, add, modify, remove } from '@api/commonApi';
import Modal from '@components/modal/Modal';
import Radio from '@components/form/Radio';
import { LabeledField } from '@components/common/LabeledField';
import Select from '@components/form/Select';
import dayjs from 'dayjs';
import Textarea from '@components/form/Textarea';
import Input from '@components/form/Input';
import UnifiedInput from '@components/form/UnifiedInput';

export default function List({ paths }) {
  const [form, setForm] = useState({});
  const [resetKey, setResetKey] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState({});
  const [pageNo, setPage] = useState(1);

  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = { pageRowCount };

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });
  const { data: details } = useFetch(detail, { paths, id: selected?.id });
  const { mAsync: deleteBoard } = useMutate(remove);
  const { mAsync: addBoard } = useMutate(add);
  const { mAsync: updateBoard } = useMutate(modify);

  const isEdit = Boolean(details?.id);

  const items = data?.content || [];
  const paginated = items.slice((pageNo - 1) * pageRowCount, pageNo * pageRowCount);

  const columns = [
    { key: 'checkbox', label: '', width: 'w-8' },
    { key: 'variableName', label: '변수명', width: 'w-32' },
    { key: 'variableValue', label: '값', width: 'w-48' },
    {
      header: '만료 알림',
      children: [
        { key: 'templateYn', label: '만료일자', width: 'w-24' },
        { key: 'approvalYn', label: '알림 설정', width: 'w-24' },
      ],
    },
    { key: 'modAt', label: '최종수정일자', width: 'w-32', sortKey: 'actionAt', sortOrder: filter.sortOrder },
    { key: 'modifyId', label: '최종 수정자', width: 'w-24' },
    {
      header: '잠금',
      children: [
        { key: 'lockYn', label: '잠금여부', width: 'w-16' },
        { key: 'variableScope', label: '사용자', width: 'w-16' },
      ],
    },
    { key: 'useYn', label: '사용', width: 'w-16' },
  ];

  const tableData = paginated.map(
    (item) => (
      {
        ...item,
        modAt: item.modAt ? dayjs(item.modAt).format('YYYY-MM-DD HH:mm') : item.regAt,
        modifyId: item.modifyId || item.registerId,
      },
      console.log('item;', item.modAt)
    )
  );
  // console.log('tabledata ', tableData);

  async function handleRowClick(row) {
    // setSelected(row);
    // setModalOpen(true);
  }
  async function handleDelete(id) {
    await deleteBoard({ paths, ids: [id] });
    setModalOpen(false);
  }

  async function handleSubmit() {
    // Normalize payload
    const payload = {
      ...form,
      useYn: typeof form.useYn === 'boolean' ? (form.useYn ? 'Y' : 'N') : form.useYn || 'N',
      templateYn: form.templateYn ?? 'N',
      approvalYn: form.approvalYn ?? 'N',
    };

    const isEdit = Boolean(selected?.id || details?.id || form?.id);
    if (isEdit) {
      payload.id = payload.id ?? selected?.id ?? details?.id;
      await updateBoard({ paths, params: payload });
    } else {
      await addBoard({ paths, params: payload });
    }
    setModalOpen(false);
  }

  const handleCreate = () => {
    setModalOpen(true);
  };

  const onDeleteLists = async () => {
    let content = '삭제할 항목을 선택해주세요';
    let onConfirm;
    if (form.ids?.length) {
      content = `${form.ids.length}개 항목을\n삭제하시겠습니까?`;
      onConfirm = async () => {
        await deleteBoard({ paths, ids: form.ids });
      };
    }
    modal.open({ content, onConfirm });
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    resetKey,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });
  console.log('data;', data);

  const ynOptions = [
    { label: 'Y', value: 'Y' },
    { label: 'N', value: 'N' },
  ];

  useEffect(() => {
    if (modalOpen && details?.id) {
      setForm((prev) => ({
        ...prev,
        ...details,
        useYn: details.useYn === 'Y',
      }));
      setResetKey(details.id);
    }
  }, [modalOpen, details]);
  return (
    <div>
      {/* 테이블 상단 버튼 */}
      <div className="bg-white p-2 rounded-lg shadow">
        <div className="flex justify-end mb-2 gap-2">
          {superAuthYn && (
            <div className="flex gap-2">
              <LabeledField
                props={{
                  ...inputProps('useYn', ''),
                  options: [
                    { label: '사용여부변경', value: '' },
                    { label: '사용', value: 'Y' },
                    { label: '사용안함', value: 'N' },
                  ],
                }}
                className="col-span-2"
                component={Select}
                compClassName={'col-span-4'}
              />
              <Button variant="ghost" onClick={onDeleteLists}>
                삭제
              </Button>
              <Button onClick={handleCreate}>공용 변수 추가</Button>
            </div>
          )}
        </div>
        <Table
          {...{
            columns,
            data,
            tableData,
            filter,
            inputProps,
            onRowClick: handleRowClick,
            onPageChange,
            pageRowCount,
          }}
        />
      </div>
      <Modal
        visible={modalOpen}
        size="md"
        onClose={() => setModalOpen(false)}
        header={isEdit ? `공용 변수 수정` : `공용 변수 추가`}
        body={
          <div className="space-y-4 overflow-y-auto max-h-[50vh] overflow-hidden">
            <div className="grid grid-cols-12 border-t border-gray-200">
              <LabeledField
                props={inputProps('typeNm', '작업그룹')}
                className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center"
                component={Select}
                compClassName="col-span-9 px-4 py-3 border-b"
              />

              <LabeledField
                props={inputProps('typeNm', '변수명')}
                className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center"
                component={Input}
                compClassName="col-span-9 px-4 py-3 border-b"
              />

              <LabeledField
                props={{ ...inputProps('description', '설명'), placeholder: '내용을 입력하세요', required: false }}
                className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center"
                component={Textarea}
                compClassName="col-span-9 px-4 py-3 border-b h-[20vh]"
                // compProps={{ className: 'h-full w-full resize-y' }}
              />

              <div className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center">
                템플릿
              </div>
              <div className="col-span-9 px-4 py-3 border-b flex items-center gap-6">
                {ynOptions.map((opt, i) => (
                  <label
                    key={`templateYn-${opt.value}`}
                    htmlFor={`templateYn-${opt.value}`}
                    className="inline-flex items-center gap-2 cursor-pointer"
                  >
                    <Radio
                      id={`templateYn-${opt.value}`}
                      name="templateYn" // ★ same name for the group
                      value={opt.value} // ★ unique value per option
                      form={form}
                      setForm={setForm}
                      required={i === 0} // group required -> apply to one input
                    />
                    <span>{opt.label}</span>
                  </label>
                ))}
              </div>

              {/* 결제필요여부 */}
              <div className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center">
                결제필요여부
              </div>
              <div className="col-span-9 px-4 py-3 border-b flex items-center gap-6">
                {ynOptions.map((opt, i) => (
                  <label
                    key={`approvalYn-${opt.value}`}
                    htmlFor={`approvalYn-${opt.value}`}
                    className="inline-flex items-center gap-2 cursor-pointer"
                  >
                    <Radio
                      id={`approvalYn-${opt.value}`}
                      name="approvalYn"
                      value={opt.value}
                      form={form}
                      setForm={setForm}
                      required={i === 0}
                    />
                    <span>{opt.label}</span>
                  </label>
                ))}
              </div>

              <div className="col-span-1 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center">
                사용 여부
              </div>
              <div className="col-span-5 px-4 py-3 border-b flex items-center">
                <label htmlFor="useYn-toggle" className="inline-flex items-center gap-3 cursor-pointer select-none">
                  {/* hidden checkbox that drives the toggle */}
                  <UnifiedInput
                    id="useYn-toggle"
                    name="useYn"
                    type="checkbox"
                    form={form}
                    setForm={setForm}
                    className="sr-only peer"
                  />
                  <span className="relative inline-block w-11 h-6 rounded-full bg-gray-300 transition-colors peer-checked:bg-emerald-500">
                    <span className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-all peer-checked:left-5" />
                  </span>
                  <span className="text-sm text-gray-700">{form.useYn ? '사용' : '중지'}</span>
                </label>
              </div>

              <div className="col-span-1 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center">
                만료 알림 설정
              </div>
              <div className="col-span-5 px-4 py-3 border-b flex items-center">
                <label htmlFor="useYn-toggle" className="inline-flex items-center gap-3 cursor-pointer select-none">
                  {/* hidden checkbox that drives the toggle */}
                  <UnifiedInput
                    id="useYn-toggle"
                    name="useYn"
                    type="checkbox"
                    form={form}
                    setForm={setForm}
                    className="sr-only peer"
                  />
                  <span className="relative inline-block w-11 h-6 rounded-full bg-gray-300 transition-colors peer-checked:bg-emerald-500">
                    <span className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-all peer-checked:left-5" />
                  </span>
                  <span className="text-sm text-gray-700">{form.useYn ? '사용' : '중지'}</span>
                </label>
              </div>
            </div>
          </div>
        }
        footer={
          <>
            <Button onClick={handleSubmit}>확인</Button>
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              취소
            </Button>
          </>
        }
      />
    </div>
  );
}
