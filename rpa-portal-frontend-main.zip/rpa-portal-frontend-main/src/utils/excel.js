// src/utils/excel.js
import * as XLSX from 'xlsx';

/**
 * downloadExcel:
 * Accepts an object with fields:
 * { date, period, workName, execution, results, summary, kpi }
 *
 * execution: { today: [{time,count}], yesterday: [...] }
 * results: { success: [...], fail: [...] }
 * summary: { totalRuns, normalCount, errors: [{label,count,color}] }
 * kpi: { totalExec, normal, totalHours, saved }
 */
export function downloadExcel({ date, period, workName, execution = {}, results = {}, summary = {}, kpi = {} }) {
  // Execution sheet: header hours/dates then rows
  const execHours = (execution.today || []).map((d) => d.time);
  const sheetExec = [
    ['시간', ...execHours],
    ['당일 실행', ...(execution.today || []).map((d) => d.count)],
    ['전일 실행', ...(execution.yesterday || []).map((d) => d.count)],
  ];

  // Results sheet
  const resHours = (results.success || []).map((d) => d.time);
  const sheetResult = [
    ['시간', ...resHours],
    ['정상', ...(results.success || []).map((d) => d.count)],
    ['실패', ...(results.fail || []).map((d) => d.count)],
  ];

  // Error summary
  const sheetErrors = [['오류 사유', '건수', '비율(%)']];
  const totalRuns = summary.totalRuns || 0;
  (summary.errors || []).forEach((e) => {
    const pct = totalRuns ? ((e.count / totalRuns) * 100).toFixed(3) : '0.000';
    sheetErrors.push([e.label, e.count, pct]);
  });
  sheetErrors.push([
    '정상',
    summary.normalCount || 0,
    totalRuns ? (((summary.normalCount || 0) / totalRuns) * 100).toFixed(3) : '0.000',
  ]);

  // KPI sheet
  const sheetKpi = [
    ['지표', '값'],
    ['총 실행 건수', kpi.totalExec ?? ''],
    ['정상 건수', kpi.normal ?? ''],
    ['총 사용 시간', kpi.totalHours ?? ''],
    ['절감 시간', kpi.saved ?? ''],
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sheetExec), '실행건수');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sheetResult), '정상_실패');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sheetErrors), '오류_분포');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sheetKpi), '요약');

  const filename = `stats_${workName}_${date}_${period}.xlsx`;
  XLSX.writeFile(wb, filename);
}
