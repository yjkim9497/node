export const statusUrgentMap: Record<string, string> = {
  HIGH: '높음',
  MED: '보통',
  LOW: '낮음',
};
export const statusUrgentColorMap: Record<string, string> = {
  HIGH: '#dc2626', // red-600
  LOW: '#3305ffff', // blue-600
};
export const getUrgentStatus = (level: string) => ({
  label: statusUrgentMap[level] ?? level,
  color: statusUrgentColorMap[level] ?? '#000000',
});