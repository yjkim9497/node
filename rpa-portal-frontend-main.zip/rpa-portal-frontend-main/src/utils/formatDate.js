import dayjs from 'dayjs';
import 'dayjs/locale/ko';
dayjs.locale('ko');

export function formatDateTime(d) {
  return dayjs(d).format('YYYY-MM-DD HH:mm:ss');
}
export default dayjs;
