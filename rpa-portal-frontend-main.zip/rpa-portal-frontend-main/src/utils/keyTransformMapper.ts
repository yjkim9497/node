type TransformFn = (value: any) => string;
type KeyTransformMapper = Record<string, TransformFn>;

const keyTransformMap: KeyTransformMapper = {
  Rate$: (value) => (value != null ? `${Math.round(value)}%` : ''),
  UsgInfo$: (value) => {
    const temp = JSON.parse(value);
    if (!Array.isArray(temp)) return '';
    let totalFree = 0,
      totalTotal = 0;

    temp.forEach((item) => {
      const totalKey = Object.keys(item).find((k) => /^total/i.test(k));
      const freeKey = Object.keys(item).find((k) => /^free/i.test(k));
      if (!totalKey || !freeKey) return;

      const total = item[totalKey];
      const free = item[freeKey];
      if (typeof total !== 'number' || typeof free !== 'number') return;

      totalTotal += total;
      totalFree += free;
    });

    if (totalTotal === 0) return '0%';
    const usedPercent = Math.round((1 - totalFree / totalTotal) * 100);
    return `${usedPercent}%`;
  },
};

// 정규식 기반 key 매칭 및 변환
export default function keyTransformMapper(key: string, value: any): string {
  for (const pattern in keyTransformMap) {
    const regex = new RegExp(pattern);
    if (regex.test(key)) {
      return keyTransformMap[pattern](value);
    }
  }
  return value != null ? String(value) : '';
}
