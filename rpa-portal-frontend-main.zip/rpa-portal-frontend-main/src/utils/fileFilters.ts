/** ---------------- Minimal File validation (blacklist + size + name) ---------------- */

export interface BlacklistOptions {
  /** Maximum number of files allowed */
  maxFiles?: number;
  /** Per-file max bytes; default: 10MB */
  maxBytes?: number;
  /** Extra deny extension list (lowercase, with dot) to merge with defaults */
  denyExt?: string[];
  /** Extra deny MIME list to merge with defaults (be conservative) */
  denyMime?: string[];
  /** Override filename special-char regex */
  denyNamePattern?: RegExp;
}

export interface InvalidFileEntry {
  file: File;
  reason: string;
  code: 'SIZE' | 'NAME_CHARS' | 'DENY_EXT' | 'DENY_MIME' | 'FILE_COUNT';
  details?: string;
}

const DEFAULT_MAX_BYTES = 10 * 1024 * 1024; // 10MB
const DEFAULT_MAX_FILES = 10;
const DEFAULT_DENY_NAME_PATTERN = /[\{\}\[\]\/?,;:|*`!^\+<>@\#$%\\\=\'\"]/gi;

/** Block high-risk “source/exec/script/archive-ish” extensions (lowercase, with dot). */
export const DEFAULT_DENY_EXT = new Set<string>([
  // server-side script
  '.asp','.aspx','.asa',
  '.php','.php3','.php4','.php5','.phtml','.inc',
  '.jsp','.jspx','.jsw','.jsv','.jspf',
  '.pl','.pm','.cgi','.lib',
  '.cfm','.cfml','.cfc',

  // client/script/html
  '.htm','.html',
  '.js','.mjs',
  '.svg','.svgz',

  // executable / package
  '.jar','.class',
  '.exe','.dll','.bat','.cmd','.com','.scr','.reg','.msi',
  '.ps1','.sh',

]);

/** Be conservative. Do NOT add common containers like 'application/zip' or 'octet-stream'. */
export const DEFAULT_DENY_MIME = new Set<string>([
  'text/html',
  'image/svg+xml',
  'text/javascript',
  'application/javascript',
  'application/x-msdownload',
  'application/x-msdos-program',
  'application/x-dosexec',
  'application/x-sh',
  'application/x-bat',
  'application/java-archive',
]);

/** Helpers */
function getFileExt(name: string): string {
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i).toLowerCase() : '';
}

function formatBytes(n: number): string {
  if (!n || n <= 0) return '0 B';
  const k = 1024, units = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(n) / Math.log(k));
  const v = (n / Math.pow(k, i)).toFixed(i === 0 ? 0 : 1);
  return `${v} ${units[i]}`;
}

/**
 * Blacklist-only validator:
 * 1) size limit
 * 2) filename restricted chars
 * 3) deny by extension (e.g., .jsp, .php, .html, .js, .sh, .exe, .jar...)
 * 4) deny by MIME for obvious script/exec types (when browser provides it)
 */
export function validateFilesBlacklist(
  files: File[],
  opts: BlacklistOptions = {}
): { valid: File[]; invalid: InvalidFileEntry[] } {
  const maxFiles = opts.maxFiles ?? DEFAULT_MAX_FILES;
  const maxBytes = opts.maxBytes ?? DEFAULT_MAX_BYTES;

  const denyExt = new Set<string>(DEFAULT_DENY_EXT);
  (opts.denyExt ?? []).forEach(e => denyExt.add(e.toLowerCase()));

  const denyMime = new Set<string>(DEFAULT_DENY_MIME);
  (opts.denyMime ?? []).forEach(m => denyMime.add(m));

  const namePattern = opts.denyNamePattern ?? DEFAULT_DENY_NAME_PATTERN;

  const valid: File[] = [];
  const invalid: InvalidFileEntry[] = [];

  for (const [index, f] of files.entries()) {
    // 0) file count limit
    if (maxFiles !== undefined && index >= maxFiles) {
      invalid.push({
        file: f,
        code: 'FILE_COUNT',
        reason: `파일 개수 제한 초과(${maxFiles}개 까지 등록 가능)`,
        details: `파일을 추가할 수 없습니다.`,
      });
      continue;
    }

    // 1) size
    if (f.size > maxBytes) {
      invalid.push({
        file: f,
        code: 'SIZE',
        reason: `용량 제한 초과(${formatBytes(maxBytes)} 초과)`,
        details: `현재 파일용량: ${formatBytes(f.size)}`
      });
      continue;
    }

    // 2) filename characters
    const matches = f.name.match(namePattern) || [];
    if (matches.length > 0) {
      const uniq = Array.from(new Set(matches));
      invalid.push({
        file: f,
        code: 'NAME_CHARS',
        reason: '등록할 수 없는 파일입니다.',
        details: `등록 불가 특수문자: ${uniq.join(' , ')}`
      });
      continue;
    }

    // 3) deny by extension
    const ext = getFileExt(f.name);
    if (denyExt.has(ext)) {
      invalid.push({
        file: f,
        code: 'DENY_EXT',
        reason: '등록할 수 없는 파일 형식입니다.',
        details: `차단된 확장자: ${ext}`
      });
      continue;
    }

    // 4) deny by MIME (if present)
    if (f.type && denyMime.has(f.type)) {
      invalid.push({
        file: f,
        code: 'DENY_MIME',
        reason: '등록할 수 없는 파일 형식입니다.',
        details: `차단된 MIME: ${f.type}`
      });
      continue;
    }

    // Passed all blacklist checks
    valid.push(f);
  }

  return { valid, invalid };
}
