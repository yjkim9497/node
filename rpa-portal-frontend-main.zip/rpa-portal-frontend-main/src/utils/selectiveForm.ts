export type ConditionalGroup<T> = {
  include: boolean;
  keys: (keyof T | RegExp)[];
};

/**
 * 조건과 패턴에 따라 특정 필드를 제거하거나 유지하는 유틸리티
 * - keys에 정규식 사용 가능
 * - keepKeys 옵션(true)이면 키는 유지하고 값만 null로 초기화
 */
export default function selectiveForm<T extends Record<string, any>>(
  form: T,
  groups: ConditionalGroup<T>[] = [],
  keepKeys = true
): Partial<T> {
  if (!form || typeof form !== 'object') return {};

  const includeKeys = new Set<keyof T>();

  groups
    .filter((g): g is ConditionalGroup<T> => !!g && Array.isArray(g.keys))
    .forEach(({ include, keys }) => {
      if (!include) return;
      keys.forEach((pattern) => {
        Object.keys(form).forEach((key) => {
          if ((pattern instanceof RegExp && pattern.test(key)) || pattern === key) {
            includeKeys.add(key as keyof T);
          }
        });
      });
    });

  const resultEntries: [string, any][] = Object.entries(form)
    .map(([key, value]) => {
      const matchedGroup = groups.find((g) =>
        g.keys.some((pattern) => (pattern instanceof RegExp ? pattern.test(key) : pattern === key))
      );

      if (!matchedGroup) return [key, value] as const;
      if (matchedGroup.include) return [key, value] as const;

      return keepKeys ? ([key, null] as const) : null;
    })
    .filter((entry): entry is [string, any] => Array.isArray(entry)); // <-- 여기 핵심!

  return Object.fromEntries(resultEntries) as Partial<T>;
}
