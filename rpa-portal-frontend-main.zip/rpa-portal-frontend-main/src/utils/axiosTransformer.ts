// utils/axiosTransformer.ts
type Records = Record<string, any>;

/** 공통 구조 */
interface TransformRule {
  match: (key: string, value: any, all: Records) => boolean;
  map: (key: string, value: any, all: Records) => Records | any;
}

/** API → Form */
const receiveRules: TransformRule[] = [
  {
    match: (k, v) => k.endsWith('Yn') && typeof v === 'string',
    map: (k, v) => ({ [k]: v === 'Y' }),
  },
  {
    match: (k, v) => k.endsWith('At') && typeof v === 'string' && v?.includes('T'),
    map: (k, v) => {
      const [date, temp] = v.split('T');
      const prefix = k.slice(0, -2);
      const time = normalizeTime(temp, false);
      return {
        [k]: `${date} ${time}`,
        [`${prefix}Date`]: date,
        [`${prefix}Time`]: time,
      };
    },
  },
  {
    match: (k, v) => k.endsWith('Time') && typeof v === 'string' && v?.includes(':'),
    map: (k, v) => ({ [k]: normalizeTime(v, false) }),
  },
];

/** Form → API */
const sendRules: TransformRule[] = [
  {
    match: (k, v) => k.endsWith('Yn') && typeof v === 'boolean',
    map: (k, v) => ({ [k]: v ? 'Y' : 'N' }),
  },
  {
    match: (k, v, all) => k.endsWith('Date') && v && all[`${k.slice(0, -4)}Time`],
    map: (k, v, all) => {
      const prefix = k.slice(0, -4);
      const time = normalizeTime(all[`${prefix}Time`]);
      return {
        [k]: v,
        [`${prefix}At`]: `${v}T${time}`,
        [`${prefix}Time`]: time,
      };
    },
  },
];

/** 공통 변환 로직 */
export function axiosTransformer(data: Records, receive = true): Records {
  if (data instanceof Blob || data instanceof FormData || data instanceof File || data instanceof ArrayBuffer) {
    return data;
  }
  const rules = receive ? receiveRules : sendRules;
  if (Array.isArray(data)) {
    // 배열이면 각 항목에 대해 재귀 적용
    return data.map((item) => axiosTransformer(item, receive));
  }
  if (data && typeof data === 'object') {
    let result: Records = { ...data };
    for (const [key, value] of Object.entries(data)) {
      let newValue = value;
      // 자식 객체/배열 재귀 적용
      if (Array.isArray(value) || (value && typeof value === 'object')) {
        newValue = axiosTransformer(value, receive);
      }
      const matchedRules = rules.filter((r) => r.match(key, newValue, data));
      for (const rule of matchedRules) {
        const mapped = rule.map(key, newValue, data);
        result = { ...result, ...mapped };
      }
      if (newValue !== value) {
        result[key] = newValue;
      }
    }
    return result;
  }
  return data;
}

/** HH:mm → HH:mm:00 (혹은 HH:mm) */
function normalizeTime(t?: any, seconds = true): string {
  const parts = String(t ?? '')
    .split(/\D+/)
    .filter(Boolean)
    .map((v) => v.padStart(2, '0'));

  const [h = '00', m = '00', s = '00'] = parts;
  const invalid = Number(h) > 23 || Number(m) > 59 || Number(s) > 59;

  return seconds ? (invalid ? '00:00:00' : `${h}:${m}:${s}`) : invalid ? '00:00' : `${h}:${m}`;
}
