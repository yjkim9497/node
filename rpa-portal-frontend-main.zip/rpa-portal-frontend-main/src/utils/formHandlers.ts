// src/utils/formHandlers.ts
import React from 'react';
import { appendParticle } from './formatter';

interface InputPropsOptions<FormType extends Record<string, any>> {
  name: keyof FormType;
  label: string;
  form: FormType;
  setForm: React.Dispatch<React.SetStateAction<FormType>>;
  resetKey?: string | number;
  className?: string;
  [key: string]: any; // 선택적 확장 허용
}

export function createProps<FormType extends Record<string, any>>(options: InputPropsOptions<FormType>) {
  const { name, label, form, setForm, ...rest } = options;

  return {
    id: String(name),
    name: String(name),
    value: form[name],
    form,
    setForm,
    placeholder: label,
    label,
    ...rest, // resetKey, className 등 추가 속성 전달
  };
}

/**
 * formatMobilePhone
 */
export function formatMobilePhone(value: string) {
  if (!value) return '';
  return value
    .replace(/[^0-9*]/g, '')
    .replace(/(^02|^050[2-7]|^013[0-2]|^1[0-9]{3}|^0[0-9]{2})([0-9]{3,4})?([0-9*]{4})$/, '$1-$2-$3')
    .replace('--', '-');
}

/**
 * normalizeValue: 입력을 일반화(blur trim, maxLength, phone format, boolean, number, select[multiple], files)
 * e: React.SyntheticEvent from input/select/textarea
 */
export function normalizeValue(e: any) {
  const target = e?.target as any;
  if (!target) return undefined;

  let { type, name, value, maxLength, multiple, files, checked } = target;
  const isBlur = e.type === 'blur';

  // File input
  if (type === 'file') {
    return files && files.length > 0 ? files[0] : null;
  }

  // Select multiple
  if (target.tagName === 'SELECT' && multiple) {
    return [...target.selectedOptions].map((o: any) => o.value);
  }

  let result: any = value;

  // Boolean-like string return Boolean
  if (result === 'true') return true;
  if (result === 'false') return false;

  // Phone number formatting (name에 phonenumber 포함)
  // const isPhoneField = name?.toLowerCase().includes('phonenumber');
  // if (isPhoneField && isBlur) {
  //   result = formatMobilePhone((result || '').trim());
  // }

  // maxLength 적용
  if (maxLength > 0 && typeof result === 'string') {
    result = result.slice(0, maxLength);
  }

  // 숫자 변환 (길이가 1자리이고 숫자일 경우)
  // if (typeof result === 'string' && result.length === 1 && !isNaN(parseInt(result))) {
  //   result = parseInt(result);
  // }

  // blur 시 trim 적용
  if (isBlur && typeof result === 'string') {
    result = result.trim();
  }

  return result;
}
/**
 * handleInputChange: 범용 input/select/textarea 핸들러
 * 사용법: onChange={e => handleInputChange(e, setForm, depth)}
 */
export function handleInputChange(e: any, setState: React.Dispatch<any>, depth: string | null = null) {
  const target = e?.target;
  if (!target) {
    // 안전장치
    throw new Error('handleInputChange: event.target is missing');
  }
  const name = target.name;
  if (!name) {
    throw new Error('handleInputChange: input missing name');
  }
  const val = normalizeValue(e);

  setState((prev: any) => {
    if (!depth) {
      return { ...prev, [name]: val };
    } else {
      return { ...prev, [depth]: { ...(prev[depth] || {}), [name]: val } };
    }
  });
}

/**
 * handleCheckRadio: checkbox / radio 범용 핸들러
 * checkbox 단일 -> boolean
 * checkbox 그룹 (same id, multiple in DOM) -> array of selected values
 * radio -> single selected value
 *
 * 사용법: onChange={e => handleCheckRadio(e, setForm, depth)}
 */
type FormValue = string | boolean | string[] | FormState;
type FormState = { [key: string]: FormValue };

export function handleCheckRadio(
  e: React.ChangeEvent<HTMLInputElement>,
  setForm: React.Dispatch<React.SetStateAction<any>>,
  depth: string | null = null,
  valueArray: any = null // 전체선택용 배열 전달
) {
  const target = e.currentTarget;
  const { id, name, type, placeholder, checked } = target;

  setForm((prev: any) => {
    const prevScope = depth ? prev[depth] || {} : prev;
    const prevValue = prevScope[name];

    let nextValue: any;
    // ---- checkbox ----
    if (type === 'checkbox') {
      // 단일 checkbox
      const boxes = document.querySelectorAll(`input[name="${name}"]`) as NodeListOf<HTMLInputElement>;
      if (boxes.length <= 1) {
        nextValue = checked;
      } else {
        // All 처리
        if (placeholder === 'All') {
          nextValue = checked ? valueArray : [];
        } else {
          // radio-like: placeholder 포함된 영역 제거
          const base = placeholder ? prevValue?.filter((e: any) => !e?.includes(placeholder)) ?? [] : prevValue;

          nextValue = checked ? [...base, id] : base.filter((v: any) => v !== id);
        }
      }
    }
    // ---- radio ----
    else {
      nextValue = normalizeValue(e);
    }

    const updated = { ...prevScope, [name]: nextValue };
    return depth ? { ...prev, [depth]: updated } : updated;
  });
}
/**async!!
 * validateForm: required속성 기반으로 필요한 필드가 비었는지 검사하고,
 * 비어있다면 첫번째 미응답 필드로 scrollIntoView + focus 후 Error throw
 */
export function validateForm(warningMsg = '입력해주세요.', except: string[] = []) {
  const requiredFields = document.querySelectorAll('input[required][id], select[required][id], textarea[required][id]');
  const uniqueNames = [...new Set(Array.from(requiredFields).map((el: any) => el.id))];

  const answered = uniqueNames.filter((id) => {
    if (except.includes(id)) return true;
    const nodes = Array.from(
      document.querySelectorAll(`input[id="${id}"], select[id="${id}"], textarea[id="${id}"]`)
    ) as any[];

    // checkbox/radio group
    if (nodes.some((n) => n.type === 'checkbox' || n.type === 'radio')) {
      return nodes.some((n) => n.checked);
    }

    return nodes.some((n) => (n.value ?? '').toString().trim() !== '');
  });

  const missing = uniqueNames.find((n) => !answered.includes(n));
  if (missing) {
    const target = document.querySelector(`[id="${missing}"]`) as HTMLElement | null;
    if (target) {
      target.parentElement?.scrollIntoView({ block: 'center' });
      (target as any).focus?.();
    }
    const label = target?.getAttribute('data-label') || '';
    throw new Error(`${appendParticle(`"${label}" `, '를', '을')} ${warningMsg}`);
  }
  return true;
}
