/**
 * appendParticle(word, noLast, withLast)
 * 주어진 단어의 마지막 글자가 완성형 한글일 경우,
 *   - 받침(종성)이 **없는 경우** → noLast 문자열을 붙임
 *   - 받침(종성)이 **있는 경우** → withLast 문자열을 붙임
 *
 * [매개변수]
 *  - word        : 조사(조사 붙일 대상 문자열)
 *  - noLast   : 받침이 없을 때 붙일 문자열 (예: '를')
 *  - withLast : 받침이 있을 때 붙일 문자열 (예: '을')
 *
 * [동작 원리]
 *  1) 마지막 글자의 유니코드를 구함
 *  2) '가'(U+AC00)~'힣'(U+D7A3) 범위인지 검사
 *  3) (code - 0xAC00) % 28 값을 통해 종성 번호 계산
 *     → 0이면 받침 없음, 1~27이면 받침 있음
 */
export function appendParticle(word: string, noLast: string, withLast: string): string {
  if (!word) return '';
  const temp = word.replace(/[^a-zA-Z가-힣]/g, '');
  const lastChar = temp[temp.length - 1];
  const code = lastChar.charCodeAt(0);

  // 한글 완성형 여부 확인
  if (code < 0xac00 || code > 0xd7a3) {
    return word; // 한글이 아니면 그대로 반환 (혹은 별도 처리)
  }

  const hasBatchim = (code - 0xac00) % 28 !== 0;
  return word + (hasBatchim ? withLast : noLast);
}

// 사용 예시
// console.log(appendParticle('기억', '를', '을')); // 기억을 (받침 있음 → '을')
// console.log(appendParticle('호수', '를', '을')); // 호수를 (받침 없음 → '를')
// console.log(appendParticle('사랑', '를', '을')); // 사랑을 (받침 있음 → '을')
// console.log(appendParticle('바다', '를', '을')); // 바다를 (받침 없음 → '를')
