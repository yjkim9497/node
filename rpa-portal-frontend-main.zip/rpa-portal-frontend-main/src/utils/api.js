// src/utils/api.js
export function delay(ms = 200) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
