export const statusReverseMap = { WAIT: '조치대기', ING: '조치중', COMPLETE: '완료' };
export const statusNoticeMap = { IMPORTANT: '중요', RESERVE: '예약', PRIVATE: '비공개', NORMAL: '일반' };