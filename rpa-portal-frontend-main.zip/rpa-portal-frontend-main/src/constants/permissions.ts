// 사용자 권한 코드 정의
export const PERMISSIONS = {
  READ: 'READ', // 조회
  ADD: 'ADD', // 추가
  MOD: 'MOD', // 수정
  DEL: 'DEL', // 삭제
  CFM: 'CFM', // 승인
  EXE: 'EXE', // 실행
  ALL: 'ALL', // 전체
  ME: 'ME', // 본인
  RE: 'RE', // 재실행
  USER: 'USER', // 사용자
  ADMIN: 'ADMIN', // 관리자
} as const;

export type Permission = keyof typeof PERMISSIONS;
