// URL Path 정의
export const PATHS = {
  LIST: 'list', // 목록
  REG: 'reg', // 작성
  EDIT: 'edit', // 수정
  DETAIL: 'detail', // 상세
} as const;

export type Paths = keyof typeof PATHS;
