import React from 'react';
import Card from '@components/ui/Card';
import { useFetch } from '@hooks/useApi';
import { getRobotInfo } from '@api/adminApi';

function RobotIcon({ color = '#60A5FA' }) {
  return (
    <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ background: color + '22' }}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="w-10 h-10 text-blue-900"
        viewBox="0 0 24 24"
        fill="currentColor"
      >
        <path d="M12 2a2 2 0 100 4 2 2 0 000-4zm8 6h-2V6a2 2 0 10-4 0v2H10V6a2 2 0 10-4 0v2H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V10a2 2 0 00-2-2zM8 18H6v-6h2v6zm4 0h-2v-6h2v6zm4 0h-2v-6h2v6zm4 0h-2v-6h2v6z" />
      </svg>
    </div>
  );
}

export default function RobotsOverview() {
  const { data: robots } = useFetch(getRobotInfo);

  const total = robots?.total ?? 0;
  const normal = robots?.normal ?? 0;
  const standby = robots?.standby ?? 0;
  const fail = robots?.fail ?? 0;

  return (
    <Card>
      <div className="flex flex-col justify-center items-center gap-4 h-full">
        <RobotIcon color="#06B6D4" />
        <div>
          <div className="text-lg font-semibold">총 로봇 수 {total}대</div>
          <div className="text-sm text-gray-500 mt-2 space-y-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-600" /> {/* 상태 아이콘 */}
                <span>정상</span>
              </div>
              <span className="text-green-600 font-bold">{normal}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-yellow-500" />
                <span>대기</span>
              </div>
              <span className="text-yellow-500 font-bold">{standby}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-600" />
                <span>장애</span>
              </div>
              <span className="text-red-600 font-bold">{fail}</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
