import React from 'react';
import RobotsOverview from './RobotsOverview';
import RobotStatus from './RobotStatus';
import ServerInfo from './ServerInfo';
import ExecutionResults from '../ExecutionResults';
import KPIEvaluation from './KPIEvaluation';
import RunningScheduledToggle from './RunningScheduledToggle';
import ExecutionChart from './ExecutionChart';

export default function AdminDashboard({ roles }) {
  return (
    <div className="bg-gray-50 space-y-6">
      {/* 상단: 좌(로봇정보), 중(로봇상태), 우(서버정보) */}
      <section className="grid grid-cols-4 gap-4">
        <RobotsOverview />
        <div className="col-span-2">
          <RobotStatus />
        </div>
        <ServerInfo />
      </section>

      {/* 중단: 좌 실행결과(관리자), 우 KPI 평가 */}
      <section className="grid grid-cols-2 gap-4">
        <ExecutionResults title="업무 실행 결과 (관리자)" />
        <KPIEvaluation />
      </section>

      {/* 하단: 좌 토글(실행중/예정), 우 실행현황 차트 */}
      <section className="grid grid-cols-2 gap-4">
        <RunningScheduledToggle />
        <ExecutionChart />
      </section>
    </div>
  );
}
