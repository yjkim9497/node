import React from 'react';
import Card from '@components/ui/Card';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';
import { useFetch } from '@hooks/useApi';
import { getExecutionTrends } from '@api/adminApi';

export default function ExecutionChart() {
  const { data } = useFetch(getExecutionTrends);

  return (
    <Card title="업무 실행 현황">
      <div style={{ height: 220 }}>
        <ResponsiveContainer>
          <LineChart data={data ?? []}>
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="count" stroke="#3182CE" dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
