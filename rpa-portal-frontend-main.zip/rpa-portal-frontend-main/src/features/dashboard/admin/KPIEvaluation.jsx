// src/features/dashboard/admin/KPIEvaluation.jsx
import React, { useMemo, useState } from 'react';
import Card from '@components/ui/Card';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, LabelList } from 'recharts';
import { useFetch } from '@hooks/useApi';
import { getWorkKpi } from '@api/adminApi';

export default function KPIEvaluation() {
  const { data: kpiData } = useFetch(getWorkKpi);
  const [selected, setSelected] = useState('전체');

  // 선택된 업무에 따른 KPI 데이터
  const currentKpi = useMemo(() => {
    if (!kpiData) return {};
    if (selected === '전체') {
      // 전체는 각 KPI 항목 합계나 평균을 생성
      return {
        automated: kpiData.reduce((sum, item) => sum + (item.automated ?? 0), 0),
        goal_automated: kpiData.reduce((sum, item) => sum + (item.goal ?? 0), 0),
        leadTime: kpiData.reduce((sum, item) => sum + (item.leadTime ?? 0), 0),
        goal_leadTime: kpiData.reduce((sum, item) => sum + (item.goal ?? 0), 0),
        successRate: kpiData.reduce((sum, item) => sum + (item.successRate ?? 0), 0) / kpiData.length,
        goal_successRate: 100, // 성공률은 % 기준
      };
    }
    const found = kpiData.find((item) => item.name === selected);
    return {
      automated: found?.automated ?? 0,
      goal_automated: found?.goal ?? 0,
      leadTime: found?.leadTime ?? 0,
      goal_leadTime: found?.goal ?? 0,
      successRate: found?.successRate ?? 0,
      goal_successRate: 100,
    };
  }, [kpiData, selected]);

  // 차트용 데이터
  const chartData = useMemo(() => {
    if (!currentKpi) return [];
    return [
      { name: '자동화 건수', value: currentKpi.automated, goal: currentKpi.goal_automated, unit: '건' },
      { name: '절감 시간', value: currentKpi.leadTime, goal: currentKpi.goal_leadTime, unit: '시간' },
      { name: '성공률', value: currentKpi.successRate, goal: currentKpi.goal_successRate, unit: '%' },
    ];
  }, [currentKpi]);

  const renderLabel = (props) => {
    const { x, y, width, height, value, payload } = props;
    const unit = payload?.unit ?? '';
    return (
      <text
        x={x + width + 4} // 막대 끝 오른쪽
        y={y + height / 2}
        dy={4}
        fill="#000"
        fontSize={12}
        textAnchor="start"
      >
        {value}
        {unit}
      </text>
    );
  };

  return (
    <Card
      title={
        <div className="flex justify-between items-center">
          <span>업무별 KPI 평가</span>
          <select
            value={selected}
            onChange={(e) => setSelected(e.target.value)}
            className="text-sm border rounded px-2 py-1"
          >
            <option value="전체">전체</option>
            {kpiData?.map((item) => (
              <option key={item.name} value={item.name}>
                {item.name}
              </option>
            ))}
          </select>
        </div>
      }
    >
      <div style={{ height: 220 }}>
        <ResponsiveContainer>
          <BarChart data={chartData} layout="vertical" margin={{ left: 20 }}>
            <XAxis type="number" hide />
            <YAxis dataKey="name" type="category" width={120} />
            <Tooltip />
            <Bar dataKey="goal" fill="#94A3B8" barSize={14}>
              <LabelList content={renderLabel} />
            </Bar>
            <Bar dataKey="value" fill="#3182CE" barSize={14}>
              <LabelList content={renderLabel} />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
