import { getSchedules } from '@api/adminApi';
import Card from '@components/ui/Card';
import { useFetch } from '@hooks/useApi';
import { useState } from 'react';

export default function RunningScheduledToggle() {
  const { data } = useFetch(getSchedules);
  const running = data?.running ?? [];
  const scheduled = data?.scheduled ?? [];

  const [tab, setTab] = useState('running');
  const list = tab === 'running' ? running : scheduled;

  return (
    <Card>
      <div className="flex gap-2 mb-3">
        <button
          onClick={() => setTab('running')}
          className={`px-3 py-1 rounded ${tab === 'running' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          실행중
        </button>
        <button
          onClick={() => setTab('scheduled')}
          className={`px-3 py-1 rounded ${tab === 'scheduled' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          예정
        </button>
      </div>

      <div style={{ maxHeight: 220 }}>
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr>
              <th className="px-2 py-2 border bg-gray-100">업무명</th>
              <th className="px-2 py-2 border bg-gray-100">시작시간</th>
              <th className="px-2 py-2 border bg-gray-100">경과시간</th>
              <th className="px-2 py-2 border bg-gray-100">로봇 수</th>
            </tr>
          </thead>
          <tbody>
            {list.slice(0, 6).map((it, idx) => (
              <tr key={idx} className="odd:bg-white even:bg-gray-50">
                <td className="px-2 py-2 border">{it?.name}</td>
                <td className="px-2 py-2 border">{it?.start}</td>
                <td className="px-2 py-2 border">{it?.elapsed ?? '-'}</td>
                <td className="px-2 py-2 border">{it?.robots ?? it?.robotCount ?? '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
