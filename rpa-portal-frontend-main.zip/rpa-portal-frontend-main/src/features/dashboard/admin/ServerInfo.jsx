import React from 'react';
import Card from '@components/ui/Card';
import { ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { useFetch } from '@hooks/useApi';
import { getServerStatus } from '@api/adminApi';

const COLORS = ['#06B6D4', '#E5E7EB'];

function DonutWithCenter({ value = 0, color = '#06B6D4' }) {
  const data = [
    { name: 'used', value },
    { name: 'rest', value: Math.max(0, 100 - value) },
  ];

  return (
    <div style={{ width: 110, height: 110, position: 'relative' }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie dataKey="value" data={data} innerRadius={30} outerRadius={44} startAngle={90} endAngle={-270}>
            {data.map((d, i) => (
              <Cell key={i} fill={i === 0 ? color : '#E5E7EB'} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div style={{ position: 'absolute', inset: 0 }} className="flex items-center justify-center">
        <div className="text-sm font-semibold">{value}%</div>
      </div>
    </div>
  );
}

export default function ServerInfo() {
  const { data: server } = useFetch(getServerStatus);

  return (
    <Card title={<div className="text-center">서버</div>}>
      <div className="flex items-center justify-evenly">
        <div className="text-sm text-gray-500">
          정상: <span className="text-green-600">{server?.statusCounts?.normal ?? 0}</span>
        </div>
        <div className="text-sm text-gray-500">
          점검: <span className="text-yellow-600">{server?.statusCounts?.warn ?? 0}</span>
        </div>
        <div className="text-sm text-gray-500">
          장애: <span className="text-red-600">{server?.statusCounts?.critical ?? 0}</span>
        </div>
      </div>
      <div className="flex items-center justify-center mt-2">
        <div className="flex gap-4 items-center">
          <div className="flex flex-col items-center">
            <DonutWithCenter value={server?.cpu ?? 0} color="#10B981" />
            <div className="text-xs text-gray-500">CPU 사용률</div>
          </div>
          <div className="flex flex-col items-center">
            <DonutWithCenter value={server?.memory ?? 0} color="#F59E0B" />
            <div className="text-xs text-gray-500">메모리 사용률</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
