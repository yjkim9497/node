import React from 'react';
import Card from '@components/ui/Card';
import { useFetch } from '@hooks/useApi';
import { getRobotList } from '@api/adminApi';

function StatusIcon({ color }) {
  return <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: color, minWidth: 12, minHeight: 12 }} />;
}

export default function RobotStatus() {
  const { data: list } = useFetch(getRobotList);

  return (
    <Card title={<div className="text-center">로봇 운영 상태</div>}>
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr>
            <th className="px-2 py-2 border bg-gray-100">로봇명</th>
            <th className="px-2 py-2 border bg-gray-100">실행 중 업무</th>
            <th className="px-2 py-2 border bg-gray-100">사용률</th>
          </tr>
        </thead>
        <tbody>
          {(list ?? []).map((r, idx) => (
            <tr key={idx} className="odd:bg-white even:bg-gray-50">
              <td className="px-2 py-2 border">
                {r?.name}
                <div className="text-xs text-gray-400">{r?.ip}</div>
              </td>
              <td className="px-2 py-2 border">{r?.task ?? '-'}</td>
              <td className="px-2 py-2 border">
                <div className="grid gap-1">
                  <div className="flex items-center gap-2">
                    <StatusIcon color="#10B981" />
                    <span className="text-xs text-gray-500">{`CPU: ${r?.cpu ?? 0}%`}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusIcon color="#F59E0B" />
                    <span className="text-xs text-gray-500">{`Memory: ${r?.memory ?? 0}%`}</span>
                  </div>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
}
