import React from 'react';
import Card from '@components/ui/Card';
import { formatDateTime } from '@utils/formatDate';

export default function UserInfo({ user }) {
  return (
    <Card>
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gray-200" />
        <div>
          <div className="text-lg font-semibold">{user?.name} 님, 반갑습니다.</div>
          <div className="text-sm text-gray-500">
            {user?.id} | {user?.dept}
          </div>
          <div className="mt-2 text-xs text-gray-400">최근 접속: {formatDateTime(new Date())}</div>
          <div className="mt-3 flex gap-2">
            <button className="px-3 py-1 border rounded text-sm">RPA 과제 신청</button>
            <button className="px-3 py-1 border rounded text-sm">수행결과 업로드</button>
          </div>
        </div>
      </div>
    </Card>
  );
}
