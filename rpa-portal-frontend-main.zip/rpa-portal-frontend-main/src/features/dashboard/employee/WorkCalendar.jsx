import React, { useRef, useState, useMemo, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import koLocale from '@fullcalendar/core/locales/ko';
import Card from '@components/ui/Card';
import { useFetch } from '@hooks/useApi';
import { getTasks } from '@api/calendarApi';

function format24WithAmPm(date) {
  if (!date) return '';
  const h = date.getHours();
  const m = date.getMinutes();
  const hh = String(h).padStart(2, '0');
  const mm = String(m).padStart(2, '0');
  const suffix = h < 12 ? 'am' : 'pm';
  return `${hh}:${mm} ${suffix}`;
}

export default function WorkCalendar() {
  const calendarRef = useRef(null);
  const [weekOffset, setWeekOffset] = useState(0);
  const { data: events } = useFetch(getTasks);

  const baseSunday = useMemo(() => {
    const today = new Date();
    const sunday = new Date(today);
    sunday.setDate(today.getDate() - today.getDay());
    sunday.setDate(sunday.getDate() + weekOffset * 14);
    return sunday;
  }, [weekOffset]);

  const formattedEvents = useMemo(
    () =>
      (events ?? []).map((e) => ({
        ...e,
        backgroundColor: e.color || '#60a5fa',
        borderColor: e.color || '#60a5fa',
      })),
    [events]
  );

  const handleEventMouseEnter = (info) => {
    const tooltipDiv = document.createElement('div');
    tooltipDiv.className = 'absolute z-[10000] p-2 bg-white border rounded shadow-lg text-sm';
    tooltipDiv.innerHTML = `
      <strong>${info.event?.title ?? ''}</strong><br/>
      그룹: ${info.event?.extendedProps?.group ?? ''}<br/>
      담당자: ${info.event?.extendedProps?.assignedTo ?? ''}<br/>
      상세: ${info.event?.extendedProps?.details ?? ''}<br/>
      시작: ${info.event?.start ? format24WithAmPm(info.event.start) : ''}<br/>
      종료: ${info.event?.end ? format24WithAmPm(info.event.end) : ''}
    `;
    document.body.appendChild(tooltipDiv);
    const rect = info.el.getBoundingClientRect();
    const tooltipWidth = 260;
    let left = rect.right + 8 + window.scrollX;
    let top = rect.top + window.scrollY;
    if (left + tooltipWidth > window.innerWidth + window.scrollX) {
      left = rect.left + window.scrollX - tooltipWidth - 8;
    }
    tooltipDiv.style.left = `${left}px`;
    tooltipDiv.style.top = `${top}px`;
    tooltipDiv.style.width = `${tooltipWidth}px`;
    info.el._tooltip = tooltipDiv;
  };

  const handleEventMouseLeave = (info) => {
    if (info.el?._tooltip) {
      info.el._tooltip.remove();
      info.el._tooltip = null;
    }
  };

  const handleMoreClick = (arg) => {
    const cell = arg.dayEl;
    if (!cell) return;
    const innerFrame = cell.querySelector('.fc-daygrid-day-frame');
    if (!innerFrame) return;
    innerFrame.style.maxHeight = 'none';
    innerFrame.style.overflow = 'visible';
    innerFrame.style.transition = 'all 0.3s';
    innerFrame.style.height = 'auto';
  };

  useEffect(() => {
    if (calendarRef.current) {
      calendarRef.current.getApi()?.gotoDate(baseSunday);
    }
  }, [baseSunday]);

  return (
    <Card
      title={
        <div className="flex justify-between items-center">
          <span>업무 캘린더</span>
          <div className="flex gap-2">
            <button
              onClick={() => setWeekOffset(0)}
              className={`px-2 py-1 rounded ${weekOffset === 0 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
            >
              이번 주간
            </button>
            <button
              onClick={() => setWeekOffset(1)}
              className={`px-2 py-1 rounded ${weekOffset === 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
            >
              다음 주간
            </button>
          </div>
        </div>
      }
    >
      <div style={{ height: 240 }}>
        <FullCalendar
          ref={calendarRef}
          plugins={[dayGridPlugin, interactionPlugin]}
          initialView="twoWeek"
          initialDate={baseSunday}
          locale={koLocale}
          headerToolbar={false}
          height="auto"
          contentHeight="auto"
          fixedWeekCount={false}
          dayMaxEventRows={4}
          moreLinkContent={(arg) => `${arg.num} more`}
          moreLinkClick={handleMoreClick}
          events={formattedEvents}
          eventMouseEnter={handleEventMouseEnter}
          eventMouseLeave={handleEventMouseLeave}
          views={{
            twoWeek: { type: 'dayGrid', duration: { weeks: 2 }, buttonText: '2주' },
          }}
          validRange={() => {
            const start = new Date(baseSunday);
            const end = new Date(start);
            end.setDate(end.getDate() + 13);
            return { start, end };
          }}
          dayHeaderContent={(arg) => {
            const day = arg.date.getDay();
            let color = day === 0 ? '#ff4d4d' : day === 6 ? '#4d79ff' : '#333';
            return { html: `<div style="color:${color}; text-align:center;">${arg.text}</div>` };
          }}
          dayCellContent={(arg) => {
            const day = arg.date.getDay();
            const color = day === 0 ? '#ff4d4d' : day === 6 ? '#4d79ff' : '#333';

            return {
              html: `<div style="color:${color}; font-weight:600; text-align:left;">
                     ${arg.dayNumberText} </div> `,
            };
          }}
        />
      </div>
    </Card>
  );
}
