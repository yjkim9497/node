import React from 'react';
import Card from '@components/ui/Card';
import { Link } from 'react-router-dom';
import { useFetch } from '@hooks/useApi';
import { getResources } from '@api/resourcesApi';
import ROUTES from '@routes/routes.generated';

const clamp2 = { display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' };

export default function Resources({ morePath = ROUTES.COMMUNITY_DOC_LIST.url }) {
  const { data: items } = useFetch(getResources);

  return (
    <Card
      title={
        <div className="flex justify-between items-center">
          <span>자료실</span>
          <Link to={morePath} className="text-sm text-blue-600">
            더보기
          </Link>
        </div>
      }
    >
      <div className="grid grid-cols-3 gap-3">
        {(items ?? []).map((it) => (
          <div key={it.id} className="p-2 border rounded bg-white flex flex-col h-52">
            <div className="flex-1 flex items-center justify-center border-b">
              <div style={{ width: 64, height: 64, background: '#f3f4f6' }} />
            </div>
            <div className="mt-2">
              <div className="text-sm font-medium truncate">{it?.title ?? '-'}</div>
              <div className="text-xs text-gray-500" style={clamp2}>
                {it?.desc ?? '-'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
