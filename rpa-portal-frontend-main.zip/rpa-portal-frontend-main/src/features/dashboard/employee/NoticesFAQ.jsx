// src/features/dashboard/employee/NoticesFAQ.jsx
import React from 'react';
import Card from '@components/ui/Card';
import { Link } from 'react-router-dom';
import { useFetch } from '@hooks/useApi';
import { getNotices, getFaqs } from '@api/employeeApi';
import ROUTES from '@routes/routes.generated';

export default function NoticesFAQ() {
  const { data: notices } = useFetch(getNotices);
  const { data: faqs } = useFetch(getFaqs);

  return (
    <div className="grid grid-cols-2 gap-4">
      <Card
        title={
          <div className="flex justify-between items-center">
            <span>공지사항</span>
            <Link to={ROUTES.COMMUNITY_INCIDENT_LIST.url} className="text-sm text-blue-600">
              더보기
            </Link>
          </div>
        }
      >
        <ul className="space-y-2" style={{ maxHeight: 220 }}>
          {notices?.map((n) => (
            <li key={n.id} className="p-2 border rounded bg-white flex justify-between items-center">
              <span className="text-sm">{n?.title}</span>
              <span className="text-xs text-gray-400">{n?.date}</span>
            </li>
          ))}
        </ul>
      </Card>

      <Card
        title={
          <div className="flex justify-between items-center">
            <span>FAQ</span>
            <Link to={ROUTES.COMMUNITY_FAQ_LIST.url} className="text-sm text-blue-600">
              더보기
            </Link>
          </div>
        }
      >
        <ul className="space-y-2" style={{ maxHeight: 220 }}>
          {faqs?.map((f) => (
            <li key={f.id} className="p-2 border rounded bg-white flex justify-between items-center">
              <span className="text-sm">{f?.q}</span>
              <span className="text-xs text-gray-400">{f?.date}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
