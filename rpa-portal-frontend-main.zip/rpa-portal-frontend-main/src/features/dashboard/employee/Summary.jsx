import React from 'react';
import Card from '@components/ui/Card';

export default function Summary({ className, summary }) {
  const scheduled = summary?.scheduled ?? '-';
  const success = summary?.success ?? 0;
  const fail = summary?.fail ?? 0;
  const runTime = summary?.runTime ?? '-';
  const annualEffect = summary?.annualEffect ?? '-';

  return (
    <Card title="요약 정보" className={className}>
      <div className="flex flex-col h-full">
        <div className="grid grid-cols-3 gap-3 mb-3">
          <div className="text-center p-3 rounded bg-gray-50">
            <div className="text-xs text-gray-500">실행 예정</div>
            <div className="text-2xl font-bold">{scheduled}</div>
          </div>
          <div className="text-center p-3 rounded bg-gray-50">
            <div className="text-xs text-gray-500">실행 성공</div>
            <div className="text-2xl font-bold text-green-600">{success}</div>
          </div>
          <div className="text-center p-3 rounded bg-gray-50">
            <div className="text-xs text-gray-500">실행 실패</div>
            <div className="text-2xl font-bold text-red-600">{fail}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 flex-1">
          <div className="p-3 rounded bg-gray-50 flex flex-col text-center justify-center">
            <div className="text-xs text-gray-500">수행시간</div>
            <div className="text-2xl font-medium">{runTime}</div>
          </div>
          <div className="p-3 rounded bg-gray-50 flex flex-col text-center justify-center">
            <div className="text-xs text-gray-500">연간대체효과</div>
            <div className="text-2xl font-medium">{annualEffect} 천원</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
