import React from 'react';
import UserInfo from './UserInfo';
import Summary from './Summary';
import WorkCalendar from './WorkCalendar';
import NoticesFAQ from './NoticesFAQ';
import ExecutionResults from '../ExecutionResults';
import Resources from './Resources';
import { useFetch } from '@hooks/useApi';
import { getEmployeeSummary } from '@api/employeeApi';

export default function EmployeeDashboard({ roles }) {
  const { data } = useFetch(getEmployeeSummary);
  const { user, summary } = data ?? {};
  return (
    <div className="bg-gray-50 space-y-6">
      {/* 상단 */}
      <section className="grid grid-cols-3 gap-4">
        <div className="col-span-2">
          <UserInfo className="h-full" user={user} />
        </div>
        <div>
          <Summary className="h-full" summary={summary} />
        </div>
      </section>

      {/* 중단 */}
      <section className="grid grid-cols-2 gap-4">
        <ExecutionResults title="내 업무 실행 결과" />
        <WorkCalendar />
      </section>

      {/* 하단 */}
      <section className="grid grid-cols-2 gap-4">
        <NoticesFAQ />
        <Resources />
      </section>
    </div>
  );
}
