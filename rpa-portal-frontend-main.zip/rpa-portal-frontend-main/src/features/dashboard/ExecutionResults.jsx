import React from 'react';
import Card from '@components/ui/Card';
import { useFetch } from '@hooks/useApi';
import { getWorkResults } from '@api/employeeApi';

function parseHHMMSSToSeconds(hms) {
  if (!hms) return 0;
  const parts = String(hms).split(':').map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return Number(hms) || 0;
}

function formatSecondsToHHMMSS(sec) {
  if (!sec && sec !== 0) return '00:00:00';
  sec = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
}

export default function ExecutionResults({ title = '업무 실행 결과' }) {
  const { data: rows } = useFetch(getWorkResults);

  const totalSum = (rows ?? []).reduce((s, r) => s + (r?.total ?? 0), 0);
  const successSum = (rows ?? []).reduce((s, r) => s + (r?.success ?? 0), 0);
  const failSum = (rows ?? []).reduce((s, r) => s + (r?.fail ?? 0), 0);

  let totalWeightedSec = 0;
  let totalCountForAvg = 0;
  (rows ?? []).forEach((r) => {
    const cnt = r?.total ?? 0;
    const sec = parseHHMMSSToSeconds(r?.avgTime);
    totalWeightedSec += sec * cnt;
    totalCountForAvg += cnt;
  });
  const avgSec = totalCountForAvg ? Math.round(totalWeightedSec / totalCountForAvg) : 0;
  const avgTimeStr = formatSecondsToHHMMSS(avgSec);

  const totalTimeSumSec = (rows ?? []).reduce((s, r) => s + parseHHMMSSToSeconds(r?.totalTime), 0);
  const totalTimeSumStr = formatSecondsToHHMMSS(totalTimeSumSec);

  return (
    <Card title={title}>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr>
              <th rowSpan={2} className="px-3 py-2 border bg-gray-100 text-left">
                업무명
              </th>
              <th colSpan={5} className="px-3 py-2 border bg-gray-100 text-left">
                업무 실행 결과
              </th>
            </tr>
            <tr>
              <th className="px-3 py-2 border bg-gray-50 text-left">합계</th>
              <th className="px-3 py-2 border bg-gray-50 text-left">성공</th>
              <th className="px-3 py-2 border bg-gray-50 text-left">실패</th>
              <th className="px-3 py-2 border bg-gray-50 text-left">평균시간</th>
              <th className="px-3 py-2 border bg-gray-50 text-left">누적시간</th>
            </tr>
          </thead>
          <tbody>
            {(rows ?? []).map((r, idx) => (
              <tr key={idx} className="odd:bg-white even:bg-gray-50">
                <td className="px-3 py-2 border">{r?.task}</td>
                <td className="px-3 py-2 border">{r?.total}</td>
                <td className="px-3 py-2 border">{r?.success}</td>
                <td className="px-3 py-2 border">{r?.fail}</td>
                <td className="px-3 py-2 border">{r?.avgTime}</td>
                <td className="px-3 py-2 border">{r?.totalTime}</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-100 font-semibold">
            <tr>
              <td className="px-3 py-2 border">합계</td>
              <td className="px-3 py-2 border">{totalSum}</td>
              <td className="px-3 py-2 border">{successSum}</td>
              <td className="px-3 py-2 border">{failSum}</td>
              <td className="px-3 py-2 border">{avgTimeStr}</td>
              <td className="px-3 py-2 border">{totalTimeSumStr}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </Card>
  );
}
