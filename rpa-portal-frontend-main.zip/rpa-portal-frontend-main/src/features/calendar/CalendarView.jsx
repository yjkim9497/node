// src/features/calendar/CalendarView.jsx
import koLocale from '@fullcalendar/core/locales/ko';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import FullCalendar from '@fullcalendar/react';
import timeGridPlugin from '@fullcalendar/timegrid';
import { forwardRef, useEffect, useState } from 'react';

// 시간 포맷터
function format24WithAmPm(date) {
  if (!date) return '';
  const h = date.getHours();
  const m = date.getMinutes();
  const hh = String(h).padStart(2, '0');
  const mm = String(m).padStart(2, '0');
  const suffix = h < 12 ? 'am' : 'pm';
  return `${hh}:${mm} ${suffix}`;
}

const CalendarView = forwardRef(({ events = [], view, form, setView, setCalendarTitle, setIsTodayInRange }, ref) => {
  const { showWeekends, narrowWeekends, startMonday } = form || {};

  useEffect(() => {
    if (ref?.current) ref.current.getApi().changeView(view);
  }, [view, ref]);

  // ───────── Tooltip ─────────
  const handleEventMouseEnter = (info) => {
    const tooltipDiv = document.createElement('div');
    tooltipDiv.className = 'absolute z-[10000] p-2 bg-white border rounded shadow-lg text-sm';
    tooltipDiv.innerHTML = `
        <strong>${info.event.title}</strong><br/>
        그룹: ${info.event.extendedProps.group ?? ''}<br/>
        담당자: ${info.event.extendedProps.assignedTo ?? ''}<br/>
        상세: ${info.event.extendedProps.details ?? ''}<br/>
        시작: ${info.event.start ? format24WithAmPm(info.event.start) : ''}<br/>
        종료: ${info.event.end ? format24WithAmPm(info.event.end) : ''}
      `;
    document.body.appendChild(tooltipDiv);

    const rect = info.el.getBoundingClientRect();
    const tooltipWidth = 260;
    let left = rect.right + 8 + window.scrollX;
    let top = rect.top + window.scrollY;

    if (left + tooltipWidth > window.innerWidth + window.scrollX) {
      left = rect.left + window.scrollX - tooltipWidth - 8;
    }

    tooltipDiv.style.left = `${left}px`;
    tooltipDiv.style.top = `${top}px`;
    tooltipDiv.style.width = `${tooltipWidth}px`;

    info.el._tooltip = tooltipDiv;
  };

  const handleEventMouseLeave = (info) => {
    if (info.el._tooltip) {
      info.el._tooltip.remove();
      info.el._tooltip = null;
    }
  };

  // ───────── 날짜 범위 변경 ─────────
  const handleDatesSet = (arg) => {
    if (setCalendarTitle) setCalendarTitle(arg.view.title);

    // 오늘 포함 여부 계산
    if (setIsTodayInRange) {
      const today = new Date();
      const start = arg.start;
      const end = arg.end;
      setIsTodayInRange(today >= start && today < end);
    }

    // 스크롤 스타일 조정
    document.querySelectorAll('.fc-scroller').forEach((scroller) => {
      scroller.style.overflowX = 'auto';
      scroller.style.overflowY = 'hidden';
    });
  };

  // 내부 view 상태
  const [currentView, setCurrentView] = useState(view);
  const handleViewChange = (e) => {
    const selectedView = e.target.value;
    setCurrentView(selectedView);
    if (ref?.current) {
      ref.current.getApi().changeView(selectedView);
    }
    if (setView) setView(selectedView);
  };

  return (
    <div className="h-full w-full">
      <FullCalendar
        ref={ref}
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView={view}
        locale={koLocale}
        headerToolbar={false}
        weekends={showWeekends}
        firstDay={startMonday ? 1 : 0}
        height="auto"
        contentHeight="auto"
        slotLabelContent={(arg) => ({
          html: `<span>${format24WithAmPm(arg.date)}</span>`,
        })}
        eventContent={(arg) => {
          const viewType = arg.view?.type ?? '';

          // --- 주간/일간 ---
          if (viewType.startsWith('timeGrid')) {
            const s = arg.event.start ? format24WithAmPm(arg.event.start) : '';
            const e = arg.event.end ? format24WithAmPm(arg.event.end) : '';
            const timeText = s && e ? `${s} ~ ${e}` : s || '';

            return {
              html: `
                  <div class="flex flex-col px-1 py-0.5 rounded-md bg-transparent min-w-[90px] max-w-[140px] max-h-14 break-words">
                    <span class="font-medium text-[clamp(10px,2vw,11px)]">${timeText}</span>
                    <span class="font-medium text-[clamp(11px,2vw,12px)]">${arg.event.title}</span>
                  </div>
                `,
            };
          }

          // --- 월간 ---
          if (viewType.startsWith('dayGrid')) {
            return {
              html: `
                  <div class="flex items-center gap-1 px-1 py-0.5">
                    <span class="w-2 h-2 rounded-sm" style="background-color:${
                      arg.event.backgroundColor || '#60a5fa'
                    }"></span>
                    <span class="text-[11px] sm:text-xs md:text-sm truncate font-normal mr-1">
                      ${arg.event.start ? format24WithAmPm(arg.event.start) : ''}
                    </span>
                    <span class="text-[11px] sm:text-xs md:text-sm font-bold truncate">
                      ${arg.event.title}
                    </span>
                  </div>
                `,
            };
          }

          return null;
        }}
        eventOverlap={false}
        slotEventOverlap={false}
        dayMaxEventRows={4}
        moreLinkContent={(arg) => `+${arg.num} more`}
        events={events?.map((e) => ({
          ...e,
          backgroundColor: e.color,
          borderColor: e.color,
        }))}
        eventMouseEnter={handleEventMouseEnter}
        eventMouseLeave={handleEventMouseLeave}
        datesSet={handleDatesSet}
        dayHeaderContent={(arg) => {
          const day = arg.date.getDay();
          let color = day === 0 ? '#ff4d4d' : day === 6 ? '#4d79ff' : '#333';
          return { html: `<div style="color:${color}; text-align:left;">${arg.text}</div>` };
        }}
        dayCellContent={(arg) => {
          const day = arg.date.getDay();
          const color = day === 0 ? '#ff4d4d' : day === 6 ? '#4d79ff' : '#333';

          // 월간 뷰 날짜 숫자만 커스텀
          if (arg.view.type === 'dayGridMonth') {
            return {
              html: `<div style="color:${color}; font-weight:600; text-align:left;">
                     ${arg.dayNumberText} </div> `,
            };
          }

          return arg.dayNumberText;
        }}
        dayHeaderClassNames={(arg) => {
          const isWeekend = arg.date.getDay() === 0 || arg.date.getDay() === 6;
          return narrowWeekends && isWeekend ? ['weekend-narrow'] : [];
        }}
        dayCellClassNames={(arg) => {
          const date = arg.date;
          const isWeekend = date.getDay() === 0 || date.getDay() === 6;

          let classes = [];

          if (isWeekend && narrowWeekends) {
            classes.push('weekend-narrow');
          }

          return classes;
        }}
      />
    </div>
  );
});

export default CalendarView;
