// src/features/calendar/TaskFilter.jsx
export default function TaskFilter({ tasks, selectedTasks, setSelectedTasks, taskFilter, setTaskFilter }) {
  const allTasks = tasks || [];
  const visibleTasks = taskFilter.team === '전체' ? allTasks : allTasks.filter((t) => t.team === taskFilter.team);
  const allSelected = visibleTasks.every((t) => selectedTasks.includes(t.id));

  const filteredTasksForCheckbox = allTasks.filter(
    (t) => (taskFilter.team === '전체' || t.team === taskFilter.team) && t.title?.includes(taskFilter.search)
  );

  const handleAllChange = (e) => {
    const visibleIds = visibleTasks.map((t) => t.id);
    if (e.target.checked) setSelectedTasks((prev) => Array.from(new Set([...prev, ...visibleIds])));
    else setSelectedTasks((prev) => prev.filter((id) => !visibleIds.includes(id)));
  };

  const handleItemChange = (e, taskId) => {
    if (e.target.checked) setSelectedTasks((prev) => [...prev, taskId]);
    else setSelectedTasks((prev) => prev.filter((id) => id !== taskId));
  };

  const handleTeamChange = (e) => {
    const newTeam = e.target.value;
    setTaskFilter((prev) => ({ ...prev, team: newTeam }));

    if (newTeam === '전체') setSelectedTasks(allTasks.map((t) => t.id));
    else {
      const teamTasks = allTasks.filter((t) => t.team === newTeam).map((t) => t.id);
      setSelectedTasks(teamTasks);
    }
  };

  return (
    <div className="p-3 flex-1 overflow-auto text-sm">
      <div className="mb-3 flex items-center">
        <label htmlFor="task-search" className="w-14 font-medium text-gray-700">
          업무명
        </label>
        <input
          id="task-search"
          type="text"
          placeholder="업무명 검색"
          value={taskFilter.search}
          onChange={(e) => setTaskFilter((prev) => ({ ...prev, search: e.target.value }))}
          className="p-1 border rounded flex-1"
        />
      </div>

      <div className="mb-3 flex items-center">
        <label htmlFor="task-team" className="w-16 font-medium text-gray-700">
          팀
        </label>
        <select
          id="task-team"
          value={taskFilter.team}
          onChange={handleTeamChange}
          className="p-1 border rounded flex-1"
        >
          <option value="전체">전체</option>
          {[...new Set(allTasks.map((t) => t.team))]?.map((team) => (
            <option key={team} value={team}>
              {team}
            </option>
          ))}
        </select>
      </div>

      <div className="border-t border-b py-2 mt-4">
        <label className="flex items-center mb-2 font-medium">
          <input type="checkbox" checked={allSelected} onChange={handleAllChange} className="mr-2" />
          전체 선택
        </label>

        {filteredTasksForCheckbox?.map((task, idx) => (
          <div
            key={task.id}
            className={`flex items-center py-2 ${idx !== filteredTasksForCheckbox.length - 1 ? 'border-b' : ''}`}
          >
            <input
              id={`task-${task.id}`}
              type="checkbox"
              checked={selectedTasks.includes(task.id)}
              onChange={(e) => handleItemChange(e, task.id)}
              className="mr-2"
            />
            <label htmlFor={`task-${task.id}`} className="flex items-center cursor-pointer flex-1">
              <div className="w-3 h-3 mr-2 rounded-sm" style={{ backgroundColor: task.color || '#ccc' }}></div>
              {task.title}
            </label>
          </div>
        ))}
      </div>
    </div>
  );
}
