// src/components/performance/DonutChart.jsx
import React, { useMemo } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

export default function DonutChart({ summary = { totalRuns: 0, normalCount: 0, errors: [] } }) {
  const { totalRuns = 0, normalCount = 0, errors = [] } = summary;

  const dataLabels = errors.map((e) => e.label).concat(['정상']);
  const errorsCounts = errors.map((e) => e.count);
  const normal = normalCount || Math.max(0, totalRuns - errorsCounts.reduce((a, b) => a + b, 0));
  const datasetValues = errorsCounts.concat([normal]);
  const colors = errors.map((e) => e.color || '#ccc').concat(['#e5e7eb']);

  const chartData = useMemo(
    () => ({
      labels: dataLabels,
      datasets: [
        {
          data: datasetValues.map((v) => Number(((v / Math.max(1, totalRuns)) * 100).toFixed(2))),
          backgroundColor: colors,
          borderWidth: 1,
        },
      ],
    }),
    [totalRuns, normalCount, errors]
  );

  const options = useMemo(
    () => ({
      responsive: true,
      cutout: '60%',
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => {
              const idx = context.dataIndex;
              const label = chartData.labels[idx];
              const valDisplay = datasetValues[idx];
              const percent = totalRuns ? ((datasetValues[idx] / totalRuns) * 100).toFixed(3) : '0.000';
              return `${label}: ${valDisplay}건 (${percent}%)`;
            },
          },
        },
      },
    }),
    [chartData, datasetValues, totalRuns]
  );

  const totalErrors = errorsCounts.reduce((a, b) => a + b, 0);
  const pct = totalRuns ? ((totalErrors / totalRuns) * 100).toFixed(2) : '0.00';

  return (
    <div className="relative p-4 border rounded-lg shadow bg-white h-full flex items-center justify-center">
      {/* Doughnut Chart */}
      <Doughnut data={chartData} options={options} />

      {/* 중앙 텍스트 (absolute overlay) */}
      <div className="absolute text-center">
        <div className="font-bold text-gray-800">총 오류 {totalErrors}건</div>
        <div className="text-sm text-gray-600">전체의 {pct}%</div>
      </div>
    </div>
  );
}
