// src/features/performance/ChartPanel.jsx
import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import UnifiedTable from './UnifiedTable';

/**
 * ChartPanel now handles series of arbitrary length.
 * execution: { today: [{time,count}], yesterday: [...] }
 * results: { success: [{time,count}], fail: [...] }
 */
export default function ChartPanel({ title, leftMode = false, execution, results }) {
  const [view, setView] = useState('chart');

  // Build chart data in a way that works with arbitrary-length arrays
  let chartData = [];
  if (leftMode && execution && execution.today) {
    const len = Math.max(execution.today.length, execution.yesterday?.length || 0);
    // merge by index (time labels come from execution.today or execution.yesterday)
    for (let i = 0; i < len; i++) {
      chartData.push({
        시간: execution.today[i]?.time || execution.yesterday?.[i]?.time || `${i}`,
        당일: execution.today[i]?.count ?? 0,
        전일: execution.yesterday?.[i]?.count ?? 0,
      });
    }
  } else if (results && results.success) {
    const len = Math.max(results.success.length, results.fail?.length || 0);
    for (let i = 0; i < len; i++) {
      chartData.push({
        시간: results.success[i]?.time || results.fail?.[i]?.time || `${i}`,
        정상: results.success[i]?.count ?? 0,
        실패: results.fail?.[i]?.count ?? 0,
      });
    }
  }

  const tableMode = leftMode ? 'execution' : 'result';
  const tableData = leftMode ? execution : results;

  return (
    <div
      className="p-4 border rounded-lg shadow bg-white col-span-1"
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-around',
      }}
    >
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-bold text-gray-700">{title}</h3>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setView(view === 'chart' ? 'table' : 'chart')}
            className="px-2 py-1 border rounded text-sm"
          >
            {view === 'chart' ? '표 보기' : '그래프 보기'}
          </button>
        </div>
      </div>

      {view === 'chart' ? (
        <div style={{ height: 260 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <XAxis dataKey="시간" />
              <YAxis />
              <Tooltip />
              <Legend />
              {leftMode ? (
                <>
                  <Line type="monotone" dataKey="당일" stroke="#1f6feb" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="전일" stroke="#57680dff" strokeDasharray="4 4" dot={false} />
                </>
              ) : (
                <>
                  <Line type="monotone" dataKey="정상" stroke="#2da44e" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="실패" stroke="#d97706" strokeDasharray="4 4" dot={false} />
                </>
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="mt-4">
          <UnifiedTable mode={tableMode} data={tableData} />
        </div>
      )}
    </div>
  );
}
