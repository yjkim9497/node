// src/features/performance/SummaryCards.jsx
import React from 'react';

function RowItem({ label, value, unit, valueClass }) {
  return (
    <div className="flex justify-between items-center py-2">
      <div className="text-sm text-gray-600">{label}</div>
      <div className={valueClass || 'text-2xl font-bold text-gray-800'}>
        {value}
        {unit ? ` ${unit}` : ''}
      </div>
    </div>
  );
}

function LeftCard({ totalExec = 0, normal = 0 }) {
  const pct = totalExec ? Math.round((normal / totalExec) * 100) : 0;
  return (
    <div className="p-6 border rounded-lg bg-white shadow">
      <h4 className="text-gray-700 font-semibold mb-3">수행 성공률</h4>
      <RowItem
        label="업무 실행 건 수"
        value={totalExec.toLocaleString()}
        unit="건"
        valueClass="text-2xl font-bold text-blue-800"
      />
      <RowItem
        label="정상 건 수"
        value={normal.toLocaleString()}
        unit="건"
        valueClass="text-2xl font-bold text-blue-800"
      />
      <div className="w-full bg-gray-200 rounded h-4 mt-4">
        <div className="h-4 rounded bg-blue-800" style={{ width: `${pct}%` }}></div>
      </div>
      <div className="text-right text-sm text-gray-600 mt-1">{pct}%</div>
    </div>
  );
}

function RightCard({ totalHours = 0, saved = 0 }) {
  const pct = totalHours ? Math.round((saved / totalHours) * 100) : 0;
  return (
    <div className="p-6 border rounded-lg bg-white shadow">
      <h4 className="text-gray-700 font-semibold mb-3">대체율</h4>
      <RowItem
        label="총 사용 시간"
        value={totalHours.toLocaleString()}
        unit="시간"
        valueClass="text-2xl font-bold text-orange-600"
      />
      <RowItem
        label="절감시간"
        value={saved.toLocaleString()}
        unit="시간"
        valueClass="text-2xl font-bold text-orange-600"
      />
      <div className="w-full bg-gray-200 rounded h-4 mt-4">
        <div className="h-4 rounded bg-orange-500" style={{ width: `${pct}%` }}></div>
      </div>
      <div className="text-right text-sm text-gray-600 mt-1">{pct}%</div>
    </div>
  );
}

export default function SummaryCards({ summary = {} }) {
  const { totalExec = 0, normal = 0, totalHours = 0, saved = 0 } = summary;
  return (
    <div className="grid grid-cols-2 gap-6 mt-6">
      <LeftCard totalExec={totalExec} normal={normal} />
      <RightCard totalHours={totalHours} saved={saved} />
    </div>
  );
}
