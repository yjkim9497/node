// src/features/performance/Filters.jsx
import React from 'react';

/**
 * Filters: period/range/workName and Excel button (calls onDownloadExcel)
 * Keeps inputs horizontal and without visible labels (sr-only for accessibility)
 */
export default function Filters({
  period,
  setPeriod,
  date,
  setDate,
  range,
  setRange,
  workName,
  setWorkName,
  onDownloadExcel,
}) {
  return (
    <div className="flex items-center justify-between w-full gap-4">
      <div className="flex items-center gap-3">
        <label className="sr-only">업무명</label>
        <select
          className="border rounded px-3 py-2 bg-white"
          value={workName}
          onChange={(e) => setWorkName(e.target.value)}
        >
          <option>전체</option>
          <option>업무001</option>
          <option>업무002</option>
        </select>

        <label className="sr-only">기간</label>
        <select
          className="border rounded px-3 py-2 bg-white"
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
        >
          <option>당일</option>
          <option>주간</option>
          <option>월간</option>
          <option>기간지정</option>
        </select>

        {period === '당일' ? (
          <input
            type="date"
            className="border rounded px-3 py-2"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        ) : (
          <>
            <input
              type="date"
              className="border rounded px-3 py-2"
              value={range.start}
              onChange={(e) => setRange((r) => ({ ...r, start: e.target.value }))}
            />
            <input
              type="date"
              className="border rounded px-3 py-2"
              value={range.end}
              onChange={(e) => setRange((r) => ({ ...r, end: e.target.value }))}
            />
          </>
        )}
      </div>

      <div>
        <button onClick={onDownloadExcel} title="Excel 다운로드" className="p-2 rounded bg-white border shadow">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
            <rect x="3" y="3" width="18" height="18" rx="2" fill="#107C41"></rect>
            <path d="M7 9h10M7 13h10M7 17h10" stroke="#fff" strokeWidth="1.2" strokeLinecap="round" />
          </svg>
        </button>
      </div>
    </div>
  );
}
