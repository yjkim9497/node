// src/features/performance/UnifiedTable.jsx
import React from 'react';

/** Cell: 값(큰 글씨) + 작은 델타(아래) */
function Cell({ value, delta }) {
  const cls = delta > 0 ? 'text-green-600' : delta < 0 ? 'text-red-600' : 'text-gray-500';
  return (
    <td className="px-2 py-1 border align-top">
      <div className="text-sm font-semibold">{value}</div>
      <div className="text-xs mt-1">
        <span className={cls}>{delta > 0 ? `+${delta}` : delta}</span>
      </div>
    </td>
  );
}

/**
 * UnifiedTable
 * - mode: "execution" | "result"
 * - data:
 *    execution: { today: [{time,count}], yesterday: [...] }
 *    result: { success: [{time,count}], fail: [...] }
 *
 * Behavior:
 * - Accepts arbitrary-length arrays.
 * - Splits the sequence into 3 blocks (as equal as possible) and renders each block (header + one A row + one B row + delta row).
 */
export default function UnifiedTable({ mode = 'execution', data }) {
  if (!data) return null;

  let arrA = [],
    arrB = [],
    labelA = '',
    labelB = '';
  if (mode === 'execution') {
    arrA = (data.today || []).map((d) => ({ time: d.time, value: d.count }));
    arrB = (data.yesterday || []).map((d) => ({ time: d.time, value: d.count }));
    labelA = '당일';
    labelB = '전일';
  } else {
    arrA = (data.success || []).map((d) => ({ time: d.time, value: d.count }));
    arrB = (data.fail || []).map((d) => ({ time: d.time, value: d.count }));
    labelA = '정상';
    labelB = '실패';
  }

  // pad arrays to same length
  const len = Math.max(arrA.length, arrB.length);
  const padArr = (arr) => {
    const out = [...arr];
    while (out.length < len) out.push({ time: out[out.length - 1]?.time ?? `${out.length}:00`, value: 0 });
    return out;
  };
  arrA = padArr(arrA);
  arrB = padArr(arrB);

  const delta = arrA.map((a, i) => a.value - (arrB[i]?.value || 0));

  // split into 3 blocks nearly equally
  const blocks = 3;
  const base = Math.floor(len / blocks);
  const rem = len % blocks;
  const slices = [];
  let start = 0;
  for (let i = 0; i < blocks; i++) {
    const size = base + (i < rem ? 1 : 0);
    slices.push({ from: start, to: start + size });
    start += size;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        {slices.map((s, blockIndex) => (
          <React.Fragment key={blockIndex}>
            <thead>
              <tr className="text-xs text-gray-500">
                {arrA.slice(s.from, s.to).map((item, idx) => (
                  <th key={`h-${blockIndex}-${idx}`} className="px-1 py-1">
                    {item.time}
                  </th>
                ))}
              </tr>
              <tr className="text-xs text-gray-400">
                <th></th>
                <th colSpan={Math.max(1, s.to - s.from)}></th>
              </tr>
            </thead>

            <tbody>
              <tr className="text-center">
                {arrA.slice(s.from, s.to).map((item, idx) => (
                  <Cell key={`a-${blockIndex}-${idx}`} value={item.value} delta={delta[s.from + idx]} />
                ))}
              </tr>
            </tbody>
          </React.Fragment>
        ))}
      </table>
    </div>
  );
}
