import { detail, modify } from '@api/commonApi';
import Button from '@components/ui/Button';
import FileManager from '@components/form/FileManager';
import Modal from '@components/modal/Modal';
import GridTable from '@components/ui/GridTable';
import { useFetch, useMutate } from '@hooks/useApi';
import ROUTES from '@routes/routes.generated';
import { useAuthStore } from '@store/authStore';
import { statusReverseMap } from '@utils/communityMapper';
import { navigate } from '@routes/NavigationProvider';

const DetailPU = ({ paths, selected, setSelected, handleDelete, setModalOpen }) => {
  const superAuthYn = useAuthStore((state) => state.superAuthYn);

  const { data: details } = useFetch(detail, { paths, id: selected?.id });
  const { mAsync: modifyBoard } = useMutate(modify);

  async function handleUpdate(noticeYn) {
    const params = { ...(details || {}), noticeYn };
    await modifyBoard({ paths, params });
    setModalOpen(false);
  }

  return (
    <Modal
      visible={selected.id}
      size="lg"
      onClose={() => setSelected({})}
      header="상세내용"
      body={
        <div className="space-y-4 overflow-y-auto max-h-[50vh] overflow-hidden">
          <GridTable
            data={details}
            rows={[
              { key: 'title', label: '제목' },
              { key: 'faqType', label: '유형' },
              {
                key: 'content',
                label: '질문',
                class: 'border-b-2 whitespace-pre-line h-[15vh]',
              },
              { key: 'answerContent', label: '답변', class: 'border-t-2 whitespace-pre-line h-[20vh]' },
            ]}
            total={6}
            lSpan={1}
          />
        </div>
      }
      footer={
        <>
          {superAuthYn && details && (
            <>
              <Button children={'삭제'} variant="secondary" onClick={() => handleDelete(details?.id)} />
              <Button
                children={'수정'}
                onClick={() => navigate(`${ROUTES.COMMUNITY_FAQ_REG.url}`, { state: details })}
              />
            </>
          )}
          <Button children={'닫기'} variant="secondary" onClick={() => setModalOpen(false)} />
        </>
      }
    />
  );
};

export default DetailPU;
