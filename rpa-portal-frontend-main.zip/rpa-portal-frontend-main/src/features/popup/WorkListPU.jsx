// src/features/popup/WorkListPU.jsx
import React, { useEffect, useMemo, useState } from 'react';
import CommonListModal from '@features/popup/CommonListModal';
import Table from '@components/ui/table/Table';
import { useFetch } from '@hooks/useApi';
import { assignmentApi } from '@api/assignmentApi';

/**
 * PU 내부에서:
 * - useFetch 로 데이터 조회
 * - keyword 로 클라이언트 필터
 * - Table 렌더링 & row 선택
 * - 확인 시 onSelect(selected) 호출
 */
export default function WorkListPU({ paths, open, onClose, onSelect }) {
  const [keyword, setKeyword] = useState('');
  const [debouncedKeyword, setDebouncedKeyword] = useState('');

  useEffect(() => {
    const id = setTimeout(() => {
      setDebouncedKeyword(keyword);
    }, 300);

    return () => clearTimeout(id);
  }, [keyword]);

  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({});

  useEffect(() => {
    if (!open) {
      setKeyword('');
      setSelected(null);
    }
  }, [open]);

  const { data, isFetching } = useFetch(assignmentApi.application.search);

  const items = useMemo(() => {
    if (!data) return [];

    const arr = Array.isArray(data) ? data : [data];
    return arr.map((item) => ({
      assignmentName: item.assignmentName,
      assignmentCode: item.assignmentCode,
    }));
  }, [data]);

  // 검색 필터: 업무명 + 업무번호
  const filteredItems = useMemo(() => {
    if (!debouncedKeyword.trim()) return items;
    const q = debouncedKeyword.trim().toLowerCase();

    return items.filter((w) =>
      [w.assignmentName, w.assignmentCode].some((field) => w && field?.toLowerCase().includes(q))
    );
  }, [items, debouncedKeyword]);

  const tableData = {
    content: filteredItems,
    pageNo: 1,
    totalPages: 1,
    totalCount: filteredItems.length,
  };

  const columns = [
    { key: 'assignmentName', label: '업무명', width: 'w-2/3' },
    { key: 'assignmentCode', label: '업무번호', width: 'w-1/3' },
  ];

  const onPageChange = (patch) => {
    setFilter((prev) => ({
      ...prev,
      ...patch,
    }));
  };

  const headerContent = (
    <div className="flex items-center gap-2 border-b pb-1">
      <input
        className="w-full border-none text-xs text-gray-700 placeholder-gray-400 focus:outline-none"
        placeholder="업무명 또는 업무번호를 입력해주세요."
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
      />
      <span className="text-sm">🔍</span>
    </div>
  );

  const handleConfirm = () => {
    onSelect(selected); // 선택된 row 넘겨주기 (없으면 null)
    onClose();
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <CommonListModal
      open={open}
      title="업무 불러오기"
      headerContent={headerContent}
      footerLeft={isFetching ? <span>조회 중...</span> : <span>조회 결과: {filteredItems.length}</span>}
      primaryLabel="확인"
      secondaryLabel="취소"
      onPrimary={handleConfirm}
      onSecondary={onClose}
    >
      <Table
        columns={columns}
        data={tableData}
        pageRowCount={filteredItems.length || 10}
        embedded
        inputProps={inputProps}
        onPageChange={onPageChange}
        onRowClick={(row) => setSelected(row)}
      />
    </CommonListModal>
  );
}
