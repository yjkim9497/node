// src/features/popup/CommonListModal.tsx
import React, { ReactNode } from 'react';
import Button from '@components/ui/Button';
import Modal from '@components/modal/Modal';

interface CommonListModalProps {
  open: boolean;
  title: string;
  size: 'xs' | 'sm' | 'md' | 'lg' | 'xl';

  /** 제목 아래쪽 설명/검색/필터 영역 */
  headerContent?: ReactNode;

  /** 테이블/리스트 영역 (Table 컴포넌트 등) */
  children: ReactNode;

  /** 하단 왼쪽 텍스트 (조회 결과 / 선택 개수 등) */
  footerLeft?: ReactNode;

  /** 버튼 관련 */
  primaryLabel?: string;
  secondaryLabel?: string;
  hidePrimary?: boolean;
  onPrimary?: () => void;
  onSecondary: () => void;

  /** 배경 클릭으로 닫기 허용 여부 */
  backdropClosable?: boolean;
}

export default function CommonListModal({
  open,
  title,
  size,
  headerContent,
  children,
  footerLeft,
  primaryLabel = '확인',
  secondaryLabel = '취소',
  hidePrimary = false,
  onPrimary,
  onSecondary,
  backdropClosable = true,
}: CommonListModalProps) {
  if (!open) return null;

  const body = (
    <div className="py-2">
      {headerContent && <div className="mb-3 text-xs text-gray-700">{headerContent}</div>}

      {/* 테이블/리스트가 들어가는 스크롤 영역 */}
      <div className="max-h-64 overflow-y-auto border">{children}</div>
    </div>
  );

  const footer = (
    <div className="flex w-full items-center justify-between">
      <div className="text-[11px] text-gray-500">{footerLeft}</div>

      <div className="flex gap-3">
        {!hidePrimary && (
          <Button type="button" variant="primary" onClick={onPrimary}>
            {primaryLabel}
          </Button>
        )}
        <Button type="button" variant="secondary" onClick={onSecondary}>
          {secondaryLabel}
        </Button>
      </div>
    </div>
  );

  return (
    <Modal
      visible={open}
      onClose={onSecondary}
      size={size}
      zIndex={50}
      className="bg-black/40" // 예전 bg-black/40 유지
      header={title}
      body={body}
      footer={footer}
      backdropClosable={backdropClosable}
    />
  );
}
