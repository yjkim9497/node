// src/pages/community/incident/List.jsx
import Button from '@components/ui/Button';
import ROUTES from '@routes/routes.generated';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import Table from '@components/ui/table/Table';
import { statusReverseMap } from '@utils/communityMapper';
import { useModalStore } from '@store/useModalStore';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';
import Modal from '@components/modal/Modal';

export default function RobotSelect({ paths, setModalOpen }) {
  const [form, setForm] = useState({});
  const [selected, setSelected] = useState({});
  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = {
    systemName: form.systemName || '',
    title: form.title || '',
    status: form.status || '',
    occurStartDate: form.occurStartDate || '',
    occurEndDate: form.occurEndDate || '',
    sortKey: form.sortKey || 'occurAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
    temp: undefined,
  };

  const [filter, setFilter] = useState(filterData);

  const { data } = useFetch(list, { paths, params: filter });

  const items = data?.content || [];
  const columns = [
    { key: 'checkbox', label: '', width: 'w-8' },
    { key: 'title', label: '로봇명', width: 'w-80' },
  ];

  const tableData = {
    ...data,
    content: items.map((item) => ({
      ...item,
      status: statusReverseMap[item?.status],
      noticeYn: item.noticeYn ? 'Y' : 'N',
    })),
  };

  const handleConfirm = () => {
    navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <Modal
      visible={true}
      size="sm"
      onClose={() => setSelected({})}
      header="로봇 선택"
      body={
        <div className="space-y-4 overflow-y-auto max-h-[50vh] overflow-hidden">
          <h3>조회할 로봇을 선택합니다.</h3>
          <div className="max-h-[88%]">
            <Table
              {...{
                columns,
                data: tableData,
                filter,
                inputProps,
                pageRowCount,
              }}
            />
          </div>
          <h3>선택 항목: {form.ids?.length}</h3>
        </div>
      }
      footer={
        <>
          <Button children={'확인'} onClick={() => handleConfirm()} />
          <Button children={'취소'} variant="secondary" onClick={() => setModalOpen(false)} />
        </>
      }
    />
  );
}
