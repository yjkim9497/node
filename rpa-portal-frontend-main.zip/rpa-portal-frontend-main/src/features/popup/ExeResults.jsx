import { detail, modify } from '@api/commonApi';
import Button from '@components/ui/Button';
import FileManager from '@components/form/FileManager';
import Modal from '@components/modal/Modal';
import GridTable from '@components/ui/GridTable';
import { useFetch, useMutate } from '@hooks/useApi';
import ROUTES from '@routes/routes.generated';
import { useAuthStore } from '@store/authStore';
import { statusReverseMap } from '@utils/communityMapper';
import { navigate } from '@routes/NavigationProvider';

const ExeResults = ({ paths, selected, setSelected, handleDelete, setModalOpen }) => {
  const superAuthYn = useAuthStore((state) => state.superAuthYn);

  const isEdit = true;

  //const { data: details } = useFetch(detail, { paths, id: selected?.id });
  const { mAsync: modifyBoard } = useMutate(modify);

  // async function handleUpdate(noticeYn) {
  //   const params = { ...(details || {}), noticeYn };
  //   await modifyBoard({ paths, params });
  //   setModalOpen(false);
  // }

  return (
    <Modal
      visible={true}
      size="lg"
      onClose={() => setModalOpen(false)}
      header={`업무 실행 결과 ${isEdit ? '수정' : '상세'}`}
      body={
        <div className="space-y-4 overflow-y-auto max-h-[50vh] overflow-hidden">
          <GridTable
            data={{}}
            rows={[
              { key: 'title', label: '업무명', colNum: 2 },
              { key: 'systemName', label: '로봇명', colNum: 2 },
              {
                key: 'createdAt',
                label: '수행일자',
                colNum: 2,
              },
              { key: 'authorName', label: '결과', colNum: 2 },
              {
                key: 'status',
                label: '원인',
                colNum: 2,
              },
              {
                key: 'actionAt',
                label: '유형',
                colNum: 2,
              },
              { key: 'content', label: '사유', class: 'whitespace-pre-line h-[15vh]' },
              { key: 'abc', label: '조치사항', class: 'whitespace-pre-line h-[15vh]' },
            ]}
            total={6}
            lSpan={1}
          />
        </div>
      }
      footer={
        <>
          {isEdit && <Button children={'확인'} onClick={() => navigate(`${ROUTES.COMMUNITY_INCIDENT_EDIT.url}`)} />}
          <Button children={isEdit ? '취소' : '닫기'} variant="secondary" onClick={() => setModalOpen(false)} />
        </>
      }
    />
  );
};

export default ExeResults;
