// src/pages/community/incident/List.jsx
import Button from '@components/ui/Button';
import ROUTES from '@routes/routes.generated';
import { useEffect, useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import { statusReverseMap } from '@utils/communityMapper';
import { useModalStore } from '@store/useModalStore';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';
import Modal from '@components/modal/Modal';
import { LabeledField } from '@components/common/LabeledField';
import DatePicker from '@components/form/DatePicker';
import TimePicker from '@components/form/TimePicker';

export default function ReservedExe({ paths, setModalOpen }) {
  const [form, setForm] = useState({});
  const [selected, setSelected] = useState({});
  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = {
    systemName: form.systemName || '',
    title: form.title || '',
    status: form.status || '',
    occurStartDate: form.occurStartDate || '',
    occurEndDate: form.occurEndDate || '',
    sortKey: form.sortKey || 'occurAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const [filter, setFilter] = useState(filterData);

  const handleConfirm = () => {
    navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    required: true,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <Modal
      visible={true}
      size="sm"
      onClose={() => setModalOpen(false)}
      header="예약 실행 설정"
      body={
        <div className="space-y-4 overflow-y-auto ">
          <div className="grid grid-cols-6 gap-2 items-center">
            <LabeledField props={inputProps('occurDate', '예약실행 일시')} className="m-auto col-span-2">
              <DatePicker {...inputProps('occurDate', '발생일자')} className={`${inputProps().className} col-span-2`} />
              <TimePicker {...inputProps('occurTime', '발생일자')} className={`${inputProps().className} col-span-2`} />
            </LabeledField>
          </div>
        </div>
      }
      footer={
        <>
          <Button
            variant="primary"
            onClick={() => {
              setModalOpen(false);
            }}
          >
            확인
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              setModalOpen(false);
            }}
          >
            취소
          </Button>
        </>
      }
    />
  );
}
