import { me, refresh } from '@api/commonAuthApi';
import Button from '@components/ui/Button';
import Modal from '@components/modal/Modal';
import { createPortal } from 'react-dom';
import GridTable from '@components/ui/GridTable';
import { useFetch } from '@hooks/useApi';
import { useAuthStore } from '@store/authStore';

const MyInfo = ({ paths, setModalOpen }) => {
  const { refreshToken } = useAuthStore() || {};
  const { data } = useFetch(me);

  const tset = async () => {
    const temp = refreshToken();
    console.log(temp);
  };

  return createPortal(
    <Modal
      visible={true}
      size="sm"
      onClose={() => setModalOpen(false)}
      header="내 정보 조회"
      body={
        <div className="space-y-4 overflow-y-auto max-h-[50vh] overflow-hidden">
          <GridTable
            data={data}
            rows={[
              { key: 'username', label: '이름' },
              { key: 'dptname', label: '소속' },
              { key: 'position', label: '직급', value: '대리' },
              { key: 'title', label: '직책', value: '' },
              { key: 'userId', label: '사용자 ID', value: 'User02' },
              { key: 'mobile', label: '휴대폰', value: '00-0000-0000' },
              { key: 'email', label: '이메일', value: 'abcd@inzisoft.com' },
              { key: 'lastActive', label: '최근 활동', value: '2025-11-11 14:20:32' },
              { key: 'test', label: 'refresh Test', value: <button children="버튼" onClick={tset} /> },
            ]}
            total={7}
            lSpan={2}
          />
        </div>
      }
      footer={<Button children={'닫기'} variant="secondary" onClick={() => setModalOpen(false)} />}
    />,
    document.body
  );
};
export default MyInfo;
