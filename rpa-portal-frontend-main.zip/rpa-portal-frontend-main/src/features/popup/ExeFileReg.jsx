// src/pages/community/incident/List.jsx
import Button from '@components/ui/Button';
import ROUTES from '@routes/routes.generated';
import { useEffect, useRef, useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import { statusReverseMap } from '@utils/communityMapper';
import { useModalStore } from '@store/useModalStore';
import { list, remove } from '@api/commonApi';
import { useFetch, useMutate } from '@hooks/useApi';
import Modal from '@components/modal/Modal';
import { LabeledField } from '@components/common/LabeledField';
import DatePicker from '@components/form/DatePicker';
import TimePicker from '@components/form/TimePicker';
import FileManager from '@components/form/FileManager';
import Input from '@components/form/Input';
import { validateForm } from '@utils/formHandlers';

export default function ExeFileReg({ paths, setModalOpen }) {
  const fileRef = useRef(null);
  const [form, setForm] = useState({});
  const [selected, setSelected] = useState({});
  const modal = useModalStore();

  const pageRowCount = 15;
  const filterData = {
    systemName: form.systemName || '',
    title: form.title || '',
    status: form.status || '',
    occurStartDate: form.occurStartDate || '',
    occurEndDate: form.occurEndDate || '',
    sortKey: form.sortKey || 'occurAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
  };

  const [filter, setFilter] = useState(filterData);

  const handleConfirm = async () => {
    if (!validateForm()) return;
    setModalOpen(false);
    //navigate(ROUTES.COMMUNITY_INCIDENT_REG.url);
  };

  const onPageChange = (obj) => {
    setFilter((prev) => ({ ...prev, ...obj }));
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    required: true,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <Modal
      visible={true}
      size="md"
      onClose={() => setModalOpen(false)}
      header="수행파일 등록"
      body={
        <div className="space-y-4 overflow-y-auto overflow-hidden">
          <div className="grid grid-cols-6 gap-4">
            <LabeledField props={inputProps('systemName', '업무명')}>
              <Button style={{ width: 'max-content' }}>업무 선택</Button>
              <Input
                {...inputProps('systemName', '업무명')}
                disabled
                className={`${inputProps().className} col-span-4`}
              />
            </LabeledField>
          </div>
          <div className="grid grid-cols-6 gap-4">
            <h3 />
            <h3 className="col-span-5 text-red-600">* 제목은 ‘업무명_수행요청일’ 로 자동 입력됩니다.</h3>
          </div>
          {/* 날짜 */}
          <div className="grid grid-cols-6 gap-4">
            <LabeledField props={{ ...inputProps('occurDate', '수행요청일') }}>
              <DatePicker
                {...inputProps('occurDate', '수행요청일')}
                disabled
                defaultValue={new Date().toISOString().split('T')[0]}
                className={`${inputProps().className} col-span-2`}
              />
            </LabeledField>
          </div>

          {/* 파일 */}
          <div className="grid grid-cols-12 gap-4 items-center">
            <LabeledField
              props={{
                ...inputProps('fileGroupSequence', '수행파일'),
                className: 'col-span-10',
                required: false,
                ref: fileRef,
                mode: 'All',
              }}
              className="pt-1 self-baseline col-span-2"
              component={FileManager}
            />
          </div>
        </div>
      }
      footer={
        <>
          <Button variant="primary" onClick={handleConfirm}>
            확인
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              setModalOpen(false);
            }}
          >
            취소
          </Button>
        </>
      }
    />
  );
}
