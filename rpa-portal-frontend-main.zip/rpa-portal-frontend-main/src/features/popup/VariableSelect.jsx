// src/features/common-modal/VariableSelect.jsx
import React, { useEffect, useMemo, useState } from 'react';
import Button from '@components/ui/Button';
import Modal from '@components/modal/Modal';
import Table from '@components/ui/table/Table';
import { useFetch } from '@hooks/useApi';
import { list } from '@api/commonApi';
import { set } from 'date-fns';

/**
 * 공용 변수 선택 모달
 * - onSelect: 확인 시 선택된 변수 row 전달 (없으면 null)
 */
export default function VariableSelect({ paths, modalOpen, setModalOpen, onSelect }) {
  const [keyword, setKeyword] = useState('');
  const [debouncedKeyword, setDebouncedKeyword] = useState('');
  const [jobGroup, setJobGroup] = useState('ALL');
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({});

  // 검색 디바운스
  useEffect(() => {
    const id = setTimeout(() => setDebouncedKeyword(keyword), 300);
    return () => clearTimeout(id);
  }, [keyword]);

  // 모달 닫힐 때 상태 초기화
  useEffect(() => {
    if (!modalOpen) {
      setKeyword('');
      setDebouncedKeyword('');
      setJobGroup('ALL');
      setSelected(null);
    }
  }, [modalOpen]);

  const pageRowCount = 15;
  const filterData = {
    systemName: form.systemName || '',
    title: form.title || '',
    status: form.status || '',
    occurStartDate: form.occurStartDate || '',
    occurEndDate: form.occurEndDate || '',
    sortKey: form.sortKey || 'occurAt',
    sortOrder: form.sortOrder || 'DESC',
    pageNo: 1,
    pageRowCount,
    temp: undefined,
  };

  const [filter, setFilter] = useState(filterData);

  // 공용 변수 조회 (필요에 따라 API 함수 변경)
  const { data, isFetching } = useFetch(list, { paths, params: filter });

  // 응답 → 배열 & 필드 정규화
  const items = useMemo(() => {
    if (!data) return [];

    const arr = Array.isArray(data?.content) ? data.content : Array.isArray(data) ? data : [data];

    return arr.map((item) => ({
      ...item,
      variableName: item.variableName ?? item.name,
      variableValue: item.variableValue ?? item.value,
      variableTypeName: item.variableTypeName ?? item.typeName,
      modAt: item.modAt ?? item.updateAt ?? item.modDate,
      modifyId: item.modifyId ?? item.modifier ?? item.modUserId,
      jobGroup: item.jobGroup ?? item.groupCode,
    }));
  }, [data]);

  // 검색 + 작업그룹 필터
  const filteredItems = useMemo(() => {
    let result = items;

    if (jobGroup !== 'ALL') {
      result = result.filter((v) => !v.jobGroup || v.jobGroup === jobGroup);
    }

    if (debouncedKeyword.trim()) {
      const q = debouncedKeyword.trim().toLowerCase();
      result = result.filter((v) =>
        [v.variableName, v.variableValue].some((field) => (field || '').toString().toLowerCase().includes(q))
      );
    }

    return result;
  }, [items, jobGroup, debouncedKeyword]);

  const tableData = {
    content: filteredItems,
    pageNo: 1,
    totalPages: 1,
    totalCount: filteredItems.length,
  };

  const columns = [
    { key: 'checkbox', label: '', width: 'w-8' },
    { key: 'variableName', label: '변수명', width: 'w-40' },
    { key: 'variableValue', label: '값', width: 'w-48', className: 'max-w-xs truncate' },
    { key: 'variableType', label: '타입', width: 'w-24' },
    { key: 'modAt', label: '최종 수정 일자', width: 'w-32' },
    { key: 'modifyId', label: '최종 수정자', width: 'w-24' },
  ];

  const handleConfirm = () => {
    if (onSelect) {
      onSelect(selected); // 선택된 row 넘겨주기 (없으면 null)
    }
    setModalOpen(false);
  };

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    <Modal
      visible={modalOpen}
      size="md"
      header="공용 변수 선택"
      onClose={() => setModalOpen(false)}
      body={
        <div className="space-y-3 overflow-y-auto max-h-[60vh] overflow-hidden">
          {/* 상단 검색 영역 (이미지 2-1, 2-2) */}
          <div className="flex flex-col gap-2 border-b pb-2 text-xs">
            {/* 변수명 검색 */}
            <div className="flex items-center gap-2">
              <input
                className="w-full border-none text-xs text-gray-700 placeholder-gray-400 focus:outline-none"
                placeholder="변수명을 입력해주세요."
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
              />
              <span className="text-sm">🔍</span>
            </div>

            {/* 작업 그룹 + 안내 문구 */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1">
                <span>작업 그룹:</span>
                <select
                  className="rounded border border-gray-300 px-2 py-1 text-xs"
                  value={jobGroup}
                  onChange={(e) => setJobGroup(e.target.value)}
                >
                  <option value="ALL">전체</option>
                  {/* 실제 그룹 코드에 맞게 수정 */}
                  <option value="GROUP_A">그룹 A</option>
                  <option value="GROUP_B">그룹 B</option>
                </select>
              </div>
            </div>
          </div>

          {/* 테이블 영역 */}
          <div className="max-h-[88%]">
            <Table
              columns={columns}
              data={tableData}
              pageRowCount={filteredItems.length || 10}
              embedded
              inputProps={inputProps}
              onRowClick={(row) => setSelected(row)}
            />
          </div>

          {/* 선택 정보 / 조회 결과 */}
          <div className="flex items-center justify-between text-xs">
            <span>조회 결과: {isFetching ? '조회 중...' : filteredItems.length}</span>
            <span>선택 변수: {selected?.variableName ? selected.variableName : '-'}</span>
          </div>
        </div>
      }
      footer={
        <>
          <Button onClick={handleConfirm} disabled={!selected}>
            확인
          </Button>
          <Button variant="secondary" onClick={() => setModalOpen(false)}>
            취소
          </Button>
        </>
      }
    />
  );
}
