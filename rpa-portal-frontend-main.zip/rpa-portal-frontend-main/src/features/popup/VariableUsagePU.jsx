// src/features/common-modal/VariableUsageModal.jsx
import React, { useMemo, useState } from 'react';
import CommonListModal from '@features/popup/CommonListModal';
import Table from '@components/ui/table/Table';

/**
 * rows 예시:
 * [{ id, workName, modifier, modifiedAt, useYn: 'Y' | 'N' }]
 */
export default function VariableUsagePU({ open, rows = [], onClose }) {
  const [useYnFilter, setUseYnFilter] = useState('ALL');

  const filtered = useMemo(() => {
    if (useYnFilter === 'ALL') return rows;
    return rows.filter((r) => r.useYn === useYnFilter);
  }, [rows, useYnFilter]);

  const columns = [
    { key: 'workName', label: '업무명', width: 'w-1/2' },
    { key: 'modifier', label: '최종 수정자', width: 'w-1/6' },
    { key: 'modifiedAt', label: '최종 수정 일자', width: 'w-1/4' },
    { key: 'useYn', label: '사용 여부', width: 'w-1/12' },
  ];

  const headerContent = (
    <div className="flex items-center gap-2 text-xs">
      <span>사용여부 :</span>
      <select
        className="rounded border px-1 py-0.5 text-xs"
        value={useYnFilter}
        onChange={(e) => setUseYnFilter(e.target.value)}
      >
        <option value="ALL">전체</option>
        <option value="Y">Y</option>
        <option value="N">N</option>
      </select>
    </div>
  );

  return (
    <CommonListModal
      open={open}
      title="공용 변수 사용 업무"
      headerContent={headerContent}
      footerLeft={<span>조회 결과: {filtered.length}</span>}
      hidePrimary
      secondaryLabel="닫기"
      onSecondary={onClose}
    >
      <Table columns={columns} items={filtered} />
    </CommonListModal>
  );
}
