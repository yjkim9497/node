// src/features/admin/attribute/basefile/RegPU.jsx
import { useLayoutEffect, useMemo, useState } from 'react';
import Modal from '@components/modal/Modal';
import Button from '@components/ui/Button';
import { LabeledField } from '@components/common/LabeledField';
import Input from '@components/form/Input';
import Textarea from '@components/form/Textarea';
import Radio from '@components/form/Radio';

const ynOptions = [
  { label: '예', value: true },
  { label: '아니오', value: false },
];

export default function RegPU(props) {
  const {
    visible,
    onClose,
    onSubmit, // (form) => Promise|void
    resetKey, // optional
    initialForm, // optional: 신규/수정 공용 초기값
    params, // optional: ModifyPU에서 기존 데이터만 넘길 때 사용
  } = props;

  const defaults = useMemo(
    () => ({
      typeNm: '',
      description: '',
      templateYn: false,
      approvalYn: false,
      useYn: true,
      id: undefined,
    }),
    []
  );

  // 매 렌더마다 최신 props 기준으로 합성
  const initialSource = useMemo(() => ({ ...defaults, ...(initialForm ?? params) }), [defaults, initialForm, params]);

  const [form, setForm] = useState(() => initialSource);

  useLayoutEffect(() => {
    if (!visible) return;
    setForm(initialSource);
  }, [visible, resetKey, initialSource]);

  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form?.[name] ?? '',
    form,
    setForm,
    placeholder: label,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
    resetKey,
  });

  const header = form?.id ? '속성 수정' : '속성 등록';

  return (
    <Modal
      visible={visible}
      size="md"
      onClose={onClose}
      header={header}
      body={
        <div className="space-y-4 overflow-y-auto max-h-[50vh] overflow-hidden">
          <div className="grid grid-cols-12 border-t border-gray-200">
            {/* 유형명 */}
            <LabeledField
              props={{ ...inputProps('typeNm', '유형명') }}
              className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center"
              component={Input}
              compClassName="col-span-9 px-4 py-3 border-b"
            />

            {/* 설명 */}
            <LabeledField
              props={{ ...inputProps('description', '설명'), placeholder: '내용을 입력하세요', required: false }}
              className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center"
              component={Textarea}
              compClassName="col-span-9 px-4 py-3 border-b h-[20vh]"
            />

            {/* 템플릿 여부 */}
            <div className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center">
              템플릿
            </div>
            <div className="col-span-9 px-4 py-3 border-b flex items-center gap-6">
              {ynOptions.map((opt, i) => (
                <label
                  key={`templateYn-${opt.label}`}
                  htmlFor={`templateYn-${opt.label}`}
                  className="inline-flex items-center gap-2 cursor-pointer"
                >
                  <Radio
                    id={`templateYn-${opt.label}`}
                    name="templateYn"
                    value={opt.value}
                    form={form}
                    setForm={setForm}
                    required={i === 0}
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>

            {/* 결제필요여부 */}
            <div className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center">
              결제필요여부
            </div>
            <div className="col-span-9 px-4 py-3 border-b flex items-center gap-6">
              {ynOptions.map((opt, i) => (
                <label
                  key={`approvalYn-${opt.label}`}
                  htmlFor={`approvalYn-${opt.label}`}
                  className="inline-flex items-center gap-2 cursor-pointer"
                >
                  <Radio
                    id={`approvalYn-${opt.label}`}
                    name="approvalYn"
                    value={opt.value}
                    form={form}
                    setForm={setForm}
                    required={i === 0}
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>

            {/* 사용 여부 */}
            <div className="col-span-3 bg-gray-50 px-4 py-3 border-b text-sm text-gray-600 flex items-center justify-center">
              사용 여부
            </div>
            <div className="col-span-9 px-4 py-3 border-b flex items-center gap-6">
              {ynOptions.map((opt, i) => (
                <label
                  key={`useYn-${opt.label}`}
                  htmlFor={`useYn-${opt.label}`}
                  className="inline-flex items-center gap-2 cursor-pointer"
                >
                  <Radio
                    id={`useYn-${opt.label}`}
                    name="useYn"
                    value={opt.value}
                    form={form}
                    setForm={setForm}
                    required={i === 0}
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      }
      footer={
        <>
          <Button
            onClick={() => {
              const draft = {
                ...form,
                useYn: form.useYn,
                templateYn: form.templateYn,
                approvalYn: form.approvalYn,
              };
              onSubmit?.(draft);
            }}
          >
            확인
          </Button>
          <Button variant="secondary" onClick={onClose}>
            취소
          </Button>
        </>
      }
    />
  );
}
