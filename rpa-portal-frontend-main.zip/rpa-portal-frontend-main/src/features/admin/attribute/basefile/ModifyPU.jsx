// src/features/admin/attribute/basefile/ModifyPU.jsx
import RegPU from './RegPU';

export default function ModifyPU(params) {
  return <RegPU {...params} />;
}
