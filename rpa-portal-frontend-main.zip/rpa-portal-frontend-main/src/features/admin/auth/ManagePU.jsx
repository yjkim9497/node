import { detail, list, modify } from '@api/commonApi';
import Button from '@components/ui/Button';
import Modal from '@components/modal/Modal';
import { useFetch, useMutate } from '@hooks/useApi';
import { useAuthStore } from '@store/authStore';
import Table from '@components/ui/table/Table';
import { useMemo, useState } from 'react';
import GridTable from '@components/ui/GridTable';
import { LabeledField } from '@components/common/LabeledField';
import Checkbox from '@components/form/Checkbox';

const ManagePU = ({ paths, tree, selected, setModalOpen, canDel, canMod }) => {
  const [form, setForm] = useState({});
  const [isEdit, setIsEdit] = useState(false);
  const [tabName, setTabName] = useState(false);
  const [arrays, setArrays] = useState({});
  const superAuthYn = useAuthStore((state) => state.superAuthYn);
  const id = selected.authoritySequence;
  const { data } = useFetch(detail, { paths, id });

  const btnText = id ? (isEdit ? '수정' : '조회') : '등록';

  const columns = [
    {
      label: '구분',
      width: 'w-40',
      className: 'bg-gray-100 justify-between',
      parentsOnly: true,
      children: [
        { key: 'depth1', rowSpan: 'rs1', width: 'w-16', className: 'bg-gray-100' },
        { key: 'depth2', rowSpan: 'rs2', width: 'w-16', className: 'bg-gray-100' },
        { key: 'depth3', rowSpan: 'rs3', width: 'w-16', className: 'bg-gray-100' },
      ],
    },
    {
      key: !id || isEdit ? 'checkbox' : 'READ',
      name: 'READ',
      label: '조회 ',
      width: 'w-8',
      totalArray: arrays.READ ?? [],
      valueMap: !id || isEdit ? undefined : { true: 'V' },
    },
    {
      key: !id || isEdit ? 'checkbox' : 'ADD',
      name: 'ADD',
      label: '추가 ',
      width: 'w-8',
      totalArray: arrays.ADD ?? [],
      valueMap: !id || isEdit ? undefined : { true: 'V' },
    },
    {
      label: '수정',
      width: 'w-8',
      children: [
        {
          key: !id || isEdit ? 'checkbox' : 'MOD',
          label: '전체',
          width: 'w-8',
          name: 'MOD',
          suffix: '_ALL',
          totalArray: arrays.MOD_ALL ?? [],
          valueMap: !id || isEdit ? undefined : { ALL: 'V' },
        },
        {
          key: !id || isEdit ? 'checkbox' : 'MOD',
          label: '본인',
          width: 'w-8',
          name: 'MOD',
          suffix: '_ME',
          totalArray: arrays.MOD_ME ?? [],
          valueMap: !id || isEdit ? undefined : { ME: 'V' },
        },
      ],
    },
    {
      label: '삭제',
      width: 'w-8',
      children: [
        {
          key: !id || isEdit ? 'checkbox' : 'DEL',
          label: '전체',
          width: 'w-8',
          name: 'DEL',
          suffix: '_ALL',
          totalArray: arrays.DEL_ALL ?? [],
          valueMap: !id || isEdit ? undefined : { ALL: 'V' },
        },
        {
          key: !id || isEdit ? 'checkbox' : 'DEL',
          label: '본인',
          width: 'w-8',
          name: 'DEL',
          suffix: '_ME',
          totalArray: arrays.DEL_ME ?? [],
          valueMap: !id || isEdit ? undefined : { ME: 'V' },
        },
      ],
    },
    {
      key: !id || isEdit ? 'checkbox' : 'CFM',
      label: '승인',
      width: 'w-8',
      name: 'CFM',
      totalArray: arrays.CFM ?? [],
      valueMap: !id || isEdit ? undefined : { true: 'V' },
    },
    {
      label: '실행',
      width: 'w-8',
      children: [
        {
          key: !id || isEdit ? 'checkbox' : 'EXE',
          label: '전체',
          width: 'w-8',
          name: 'EXE',
          suffix: '_ALL',
          totalArray: arrays.EXE_ALL ?? [],
          valueMap: !id || isEdit ? undefined : { ALL: 'V' },
        },
        {
          key: !id || isEdit ? 'checkbox' : 'EXE',
          label: '본인',
          width: 'w-8',
          name: 'EXE',
          suffix: '_ME',
          totalArray: arrays.EXE_ME ?? [],
          valueMap: !id || isEdit ? undefined : { ME: 'V' },
        },
        {
          key: !id || isEdit ? 'checkbox' : 'EXE',
          label: '재수행',
          width: 'w-8',
          name: 'EXE',
          suffix: '_RE',
          totalArray: arrays.EXE_RE ?? [],
          valueMap: !id || isEdit ? undefined : { RE: 'V' },
        },
      ],
    },
  ];

  //const { data: details } = useFetch(detail, { paths, });
  const { mAsync: modifyBoard } = useMutate(modify);

  function extractNamedNodes(tree) {
    const result = [];
    let prev = {};
    function traverse(node, title = '', span = []) {
      if (!node || typeof node !== 'object') return;
      const { name, permissions } = node;
      const temp = [title, node.title].filter(Boolean)?.join('_') || '';
      const [depth1 = '', depth2 = '', depth3 = ''] = temp.split('_') || [];
      const [rowSpan1 = 1, rowSpan2 = 1, rowSpan3 = 1] = [...span, node.rowSpan];
      if (permissions) {
        const rs1 = depth1 && depth1 === prev?.depth1 ? 0 : rowSpan1;
        const rs2 = depth2 && depth2 === prev?.depth2 ? 0 : rowSpan2;
        const rs3 = depth3 && depth3 === prev?.depth3 ? 0 : rowSpan3;
        const rs = { ...permissions, name: `ROLE_${name}_`, depth1, depth2, depth3, rs1, rs2, rs3 };
        result.push(rs);
        prev = rs;
      }

      // 자식 노드 순회
      Object.values(node.children).forEach((child) => {
        if (child && typeof child === 'object') {
          traverse(child, [title, node.title].filter(Boolean)?.join('_'), [...span, node.rowSpan]);
        }
      });
    }

    Object.values(tree).forEach((e) => traverse(e));

    return result;
  }

  /* ---- 문자열 부분 포함(약어) 검사 (subsequence) ---- */
  function isSubsequence(abbrev, word) {
    const a = abbrev.toLowerCase();
    const w = word.toLowerCase();
    let i = 0,
      j = 0;
    while (i < a.length && j < w.length) {
      if (a[i] === w[j]) i++;
      j++;
    }
    return i === a.length;
  }

  function buildRoleList(roleList = [], checkList = [], temp = {}) {
    const tree = JSON.parse(JSON.stringify(temp));
    const regex = /_(READ|ADD|MOD|DEL|CFM|EXE)[\w\d_]*$/i;

    const forms = {};
    const totals = {};

    const collectUpdate = (update, key, role) => {
      if (!update[key]) update[key] = [];
      update[key].push(role);
    };

    let prevParts = [];

    for (const role of checkList) {
      const valideRole = roleList.includes(role);
      const clean = role.replace(/^ROLE_/, '');
      const match = clean.match(regex);
      const matchedStr = match ? match[0] : '';

      const [k, value = true] = matchedStr.split('_').filter(Boolean);
      const newKey = value === true ? k : `${k}_${value}`;

      let isFound = false;

      const name = match ? clean.replace(matchedStr, '') : clean;
      const keys = name.split('_').filter(Boolean);

      let path = '';
      let roleCursor = tree;

      const diffIndex = keys.findIndex((key, i) => prevParts[i] !== key);

      keys.forEach((key, idx) => {
        path += (idx ? '_' : '') + key;

        const children = roleCursor.children ?? roleCursor;
        const found = Object.values(children).find((rk) => isSubsequence(key, rk.key));

        if (found) {
          isFound = true;
          roleCursor = found;
          roleCursor.name = path;

          if (idx === keys.length - 1) {
            roleCursor.permissions = {
              ...(roleCursor.permissions ?? {}),
              [k]: valideRole ? value : false,
            };
          }

          roleCursor.rowSpan = roleCursor.rowSpan ?? 1;
          if (diffIndex !== -1 && idx < diffIndex) {
            roleCursor.rowSpan += 1;
          }
        }
      });

      prevParts = keys;

      if (isFound) {
        collectUpdate(totals, newKey, role);
        if (newKey !== k) collectUpdate(totals, k, role);
        if (valideRole) {
          collectUpdate(forms, newKey, role);
          if (newKey !== k) collectUpdate(forms, k, role);
        }
      }
    }

    //일괄 상태 업데이트 (Batch Update 효과)
    const applyUpdates = (collected) => () => {
      const nextState = {};
      Object.entries(collected).forEach(([key, roles]) => {
        nextState[key] = [...(nextState[key] ?? []), ...roles];
      });
      return nextState;
    };

    setForm(applyUpdates(forms));
    setArrays(applyUpdates(totals));

    return extractNamedNodes(tree);
  }

  //스튜디오 정보 추가.
  const content = useMemo(
    () =>
      buildRoleList(
        data?.authorityList,
        data?.authorityCheckList,
        tabName
          ? {
              stdo: {
                key: 'stdo',
                title: '스튜디오',
                children: {
                  prcscm: {
                    key: 'prcscm',
                    title: '형상 관리',
                    children: {},
                  },
                  share: {
                    key: 'share',
                    title: '공유',
                    children: {
                      lib: {
                        key: 'lib',
                        title: '라이브러리',
                        children: {},
                      },
                    },
                  },
                },
              },
            }
          : tree
      ),
    [data, tabName]
  );
  //console.log('arrays', arrays);
  //console.log(content);
  //console.log(form);
  const inputProps = (name, label) => ({
    id: name,
    name,
    value: form[name],
    form,
    setForm,
    placeholder: label,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  if (!content) return null;

  return (
    <Modal
      visible={data}
      size="xl"
      onClose={() => setModalOpen(false)}
      header={`권한 정보 ${btnText}`}
      body={
        <div className="space-y-4 overflow-y-auto max-h-[70vh] overflow-hidden">
          <GridTable
            data={data}
            rows={[
              { key: 'authorityName', label: '권한명', colNum: 2 },
              {
                key: 'use',
                label: '사용 권한',
                colNum: 2,
                value: (
                  <div className="flex w-full justify-start gap-5">
                    <div className="flex flex-row-reverse gap-2">
                      <LabeledField
                        props={{ ...inputProps('Portal', 'Portal') }}
                        className="ml-0"
                        component={Checkbox}
                      />
                    </div>
                    <div className="flex flex-row-reverse gap-2">
                      <LabeledField
                        props={{ ...inputProps('Studio', 'Studio') }}
                        className="ml-0"
                        component={Checkbox}
                      />
                    </div>
                  </div>
                ),
              },
            ]}
            total={8}
            lSpan={1}
          />
          <div className="w-full flex justify-start gap-2">
            <Button
              children={'iAuto Portal'}
              variant={!tabName ? 'primary' : 'gost'}
              onClick={() => setTabName(false)}
            />
            <Button children={'Studio'} variant={tabName ? 'primary' : 'gost'} onClick={() => setTabName(true)} />
          </div>
          <Table {...{ columns, data: { content }, inputProps }} />
        </div>
      }
      footer={
        <div className="flex space-x-2">
          {canDel && <Button children={'삭제'} variant="secondary" onClick={() => {}} />}
          {canMod && (
            <Button
              children={'수정'}
              onClick={() => {
                setIsEdit((prev) => !prev);
                //navigate(`edit/${id}`);
              }}
            />
          )}

          <Button children={'닫기'} variant="secondary" onClick={() => setModalOpen(false)} />
        </div>
      }
    />
  );
};

export default ManagePU;
