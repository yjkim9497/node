// src/components/form/applyDefaultValue.ts
import React from 'react';

export function applyDefaultValue(
  value: any,
  defaultValue: any,
  resetKey: number,
  depth: string | null | undefined,
  name: string = '',
  setForm: React.Dispatch<any>
) {
  if ((value === undefined || resetKey) && defaultValue !== value) {
    setForm((prev: any) =>
      depth ? { ...prev, [depth]: { ...(prev[depth] || {}), [name]: defaultValue } } : { ...prev, [name]: defaultValue }
    );
  }
}
