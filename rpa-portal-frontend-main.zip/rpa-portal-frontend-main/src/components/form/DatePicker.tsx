import React from 'react';
import UnifiedInput from './UnifiedInput';
import { BaseFormProps } from './formProps';

const DatePicker: React.FC<BaseFormProps> = (props) => <UnifiedInput {...props} type="date" />;

export default DatePicker;
