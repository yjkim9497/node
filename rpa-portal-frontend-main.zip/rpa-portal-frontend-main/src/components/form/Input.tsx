import React from 'react';
import UnifiedInput from './UnifiedInput';
import { InputProps } from './formProps';

const Input: React.FC<InputProps> = (props) => <UnifiedInput {...props} type={props.type || 'text'} />;

export default Input;
