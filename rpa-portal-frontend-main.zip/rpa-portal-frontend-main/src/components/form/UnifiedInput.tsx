// src/components/form/UnifiedInput.tsx
import React, { useEffect, useRef, useState } from 'react';
import { handleInputChange, handleCheckRadio } from '@utils/formHandlers';
import { InputProps, CheckboxProps, RadioProps, BaseFormProps } from './formProps';
import { applyDefaultValue } from './applyDefaultValue';

type UnifiedProps = (InputProps | CheckboxProps | RadioProps) & {
  type?: string; // 'text' | 'checkbox' | 'radio' | 'date' | 'time'
};

export default function UnifiedInput({
  id,
  name,
  label,
  form,
  setForm,
  type = 'text',
  min,
  max,
  value,
  defaultValue,
  resetKey = 0,
  placeholder,
  maxLength,
  depth,
  required,
  onChange,
  onBlur,
  className,
  disabled = false,
}: UnifiedProps) {
  const [typeState, setType] = useState(type);
  const isPassword = type === 'password';
  const checkRadio = type === 'checkbox' || type === 'radio';
  const picker = type === 'date' || type === 'time';

  const inputRef = useRef<HTMLInputElement>(null);

  const formValue = depth ? (name ? form[depth]?.[name] : undefined) : name ? form?.[name] : undefined;

  // checked 상태 계산 (checkbox/radio 전용)
  let checked: boolean | undefined = undefined;
  if (type === 'checkbox') {
    if (placeholder === 'All') {
      checked =
        formValue?.length > 0 &&
        formValue?.length === (value as any)?.length &&
        formValue?.sort()?.every((v: any, i: number) => v === (value as any).sort()?.[i]);
    } else {
      checked = Array.isArray(formValue) ? formValue?.includes(id) : formValue ?? false;
    }
  } else if (type === 'radio') {
    // TODO: 확인필요
    checked = formValue === value;
  }
  const temp = defaultValue === undefined ? (type === 'checkbox' || type === 'radio' ? false : '') : defaultValue;

  // defaultValue 적용
  useEffect(() => {
    applyDefaultValue(formValue, temp, resetKey, depth, name, setForm);
  }, [resetKey]);

  const commonProps = {
    id,
    name,
    type,
    'data-label': label,
    required,
    placeholder,
    maxLength,
    className,
  };

  const handleClick = () => {
    inputRef.current?.showPicker(); // 네이티브 캘린더/타임 피커 강제 실행
  };

  //type === 'password', show/hide
  const toggle = () => {
    if (!inputRef.current || type !== 'password') return;
    const next = typeState === 'password' ? 'text' : 'password';
    setType(next);
  };

  // checkbox/radio 이벤트
  if (checkRadio) {
    return (
      <input
        {...commonProps}
        value={value ?? ''}
        checked={checked ?? false}
        disabled={disabled}
        onChange={(e) => {
          (e.currentTarget as any).valueArray = value; // checkbox 전체선택용
          handleCheckRadio(e, setForm, depth, value);
        }}
        onClick={(e) => e.stopPropagation()}
      />
    );
  }

  // input/date/time 이벤트
  return (
    <>
      <input
        {...commonProps}
        {...(picker ? { min, max } : {})}
        ref={inputRef}
        type={typeState}
        value={value ?? ''}
        disabled={disabled}
        onClick={picker ? handleClick : undefined}
        onChange={(e) => {
          handleInputChange(e, setForm, depth);
          onChange?.(e);
        }}
        onBlur={(e) => {
          handleInputChange(e, setForm, depth);
          onBlur?.(e);
        }}
      />
      {isPassword && (
        <button
          type="button"
          onClick={toggle}
          style={{
            position: 'absolute',
            right: '0px',
            transform: 'translateX(-20%)',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
          }}
          aria-label={typeState === 'password' ? '비밀번호 보이기' : '비밀번호 숨기기'}
        >
          {typeState === 'password' ? '👁' : '✕'}
        </button>
      )}
    </>
  );
}
