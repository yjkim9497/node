// src/components/form/formProps.ts
import React, { ChangeEvent } from 'react';

//////////////////// 공통 Base ////////////////////
export interface BaseFormProps {
  /** form 상태 객체 */
  form: Record<string, any>;
  /** setForm */
  setForm: React.Dispatch<any>;
  /** 중첩 구조용 depth (optional) */
  depth?: string | null;
  /** 초기값 강제 재적용 신호 */
  resetKey?: number;
  label?: string;
  /** 공통 이벤트 핸들러 */
  onChange?: (e: ChangeEvent<any>) => void;
}

//////////////////// Input ////////////////////
export interface InputProps
  extends BaseFormProps,
    Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'form'> {
  type?: string;
}

//////////////////// Textarea ////////////////////
export interface TextareaProps
  extends BaseFormProps,
    Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'onChange' | 'form'> {}

//////////////////// Checkbox ////////////////////
export interface CheckboxProps
  extends BaseFormProps,
    Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'form'> {
  /** checkbox 그룹 값 또는 단일 값 */
  value: any[] | string;
}

//////////////////// Radio ////////////////////
export interface RadioProps
  extends BaseFormProps,
    Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'form'> {
  value: string;
}

//////////////////// Select ////////////////////
export interface SelectProps
  extends BaseFormProps,
    Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'onChange' | 'form'> {
  options: { value: string; label: string }[];
}

//////////////////// File 관련 ////////////////////
export interface FileMeta {
  fileSequence: number;
  fileGroupSequence: number;
  fileName: string;
  fileSize: number;
  filePath: string;
}

export interface UploadResult {
  files: FileMeta[];
  fileGroupSequence: number;
}

export type UploaderParams = {
  files: File[];
  tableId: string;
  columnId: string;
  fileGroupSequence?: number | null;
};

export type FileInputProps = Pick<
  React.InputHTMLAttributes<HTMLInputElement>,
  'id' | 'required' | 'className' | 'multiple' | 'disabled' | 'accept' | 'onChange'
> & { label?: string };

export interface FileListProps {
  fileGroupSequence?: number | null;
  onListChanged?: (files: FileMeta[]) => void;
  readOnly?: boolean;
  className?: string;
  version?: number;
}
