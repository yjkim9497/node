import React from 'react';
import UnifiedInput from './UnifiedInput';
import { BaseFormProps } from './formProps';

const TimePicker: React.FC<BaseFormProps> = (props) => <UnifiedInput {...props} type="time" />;

export default TimePicker;
