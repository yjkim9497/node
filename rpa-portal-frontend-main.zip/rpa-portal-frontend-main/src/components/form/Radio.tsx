import React from 'react';
import UnifiedInput from './UnifiedInput';
import { RadioProps } from './formProps';

const Radio: React.FC<RadioProps> = (props) => <UnifiedInput {...props} type="radio" />;

export default Radio;
