import React from 'react';
import UnifiedInput from './UnifiedInput';
import { CheckboxProps } from './formProps';

const Checkbox: React.FC<CheckboxProps> = (props) => <UnifiedInput {...props} type="checkbox" />;

export default Checkbox;
