// src/components/form/Textarea.tsx
import React, { useEffect } from 'react';
import { handleInputChange } from '@utils/formHandlers';
import { TextareaProps } from './formProps';
import { applyDefaultValue } from './applyDefaultValue';

export default function Textarea({
  id,
  name,
  label,
  form,
  setForm,
  placeholder,
  rows = 3,
  defaultValue = '',
  resetKey = 0,
  depth,
  required,
  className,
  disabled = false,
  onChange,
  onBlur,
}: TextareaProps) {
  const value = depth ? (name ? form[depth]?.[name] : undefined) : name ? form?.[name] : undefined;

  useEffect(() => {
    applyDefaultValue(value, defaultValue, resetKey, depth, name, setForm);
  }, [resetKey]);

  return (
    <textarea
      id={id}
      name={name}
      data-label={label}
      placeholder={placeholder}
      rows={rows}
      required={required}
      disabled={disabled}
      value={value || ''}
      onChange={(e) => {
        handleInputChange(e, setForm, depth);
        onChange?.(e);
      }}
      onBlur={(e) => {
        handleInputChange(e, setForm, depth);
        onBlur?.(e);
      }}
      className={className}
    />
  );
}
