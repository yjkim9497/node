// src/components/form/Select.tsx
import React, { useEffect } from 'react';
import { handleInputChange } from '@utils/formHandlers';
import { SelectProps } from './formProps';
import { applyDefaultValue } from './applyDefaultValue';

export default function Select({
  id,
  name,
  label,
  form,
  setForm,
  options,
  defaultValue = '',
  resetKey = 0,
  multiple = false,
  depth,
  required,
  disabled = false,
  className,
}: SelectProps) {
  const value = depth ? (name ? form[depth]?.[name] : undefined) : name ? form?.[name] : undefined;

  useEffect(() => {
    applyDefaultValue(value, defaultValue, resetKey, depth, name, setForm);
  }, [resetKey]);

  return (
    <select
      id={id}
      name={name}
      data-label={label}
      required={required}
      multiple={multiple}
      value={value || ''}
      disabled={disabled}
      onChange={(e) => handleInputChange(e, setForm, depth)}
      className={className}
    >
      {options.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  );
}
