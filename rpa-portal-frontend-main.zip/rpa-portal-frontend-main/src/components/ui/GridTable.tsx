import React, { useMemo } from 'react';
import clsx from 'clsx';
import { useTruncateMatrixObserver } from '@hooks/useTruncateObserver';

type AlignType = 'left' | 'center' | 'right';

interface GridCell<T = string> {
  key: string;
  label?: React.ReactNode;
  value?: React.ReactNode;
  labelSpan?: number;
  valueSpan?: number;
  lAlign?: AlignType;
  vAlign?: AlignType;
  rowSpan?: number;
  colNum?: number;
  children?: GridCell[];
  class?: string;
  invisible?: boolean;
}

interface PlacedCell {
  key: string;
  node: React.ReactNode;
  gridColumnStart: number;
  gridColumnSpan: number;
  gridRowStart: number;
  gridRowSpan: number;
  align?: AlignType;
  className?: string;
}

interface GridTableProps<T = Record<string, any>> {
  data?: T;
  rows: GridCell<T>[];
  total?: number;
  lSpan?: number;
  lAlign?: AlignType;
  vAlign?: AlignType;
  defaultRowSpan?: number;
}

const GridTable: React.FC<GridTableProps> = ({
  data = {},
  rows = [],
  total = 6,
  lSpan = 1,
  defaultRowSpan = 1,
  lAlign = 'left',
  vAlign = 'left',
}) => {
  const { register } = useTruncateMatrixObserver();
  const placedCells = useMemo(() => {
    const occupancy: number[][] = [];

    const ensureRow = (r: number) => {
      while (occupancy.length <= r) occupancy.push(new Array(total).fill(0));
    };

    const markOccupied = (rStart: number, cStart: number, rSpan: number, cSpan: number) => {
      for (let rr = rStart; rr < rStart + rSpan; rr++) {
        ensureRow(rr);
        for (let cc = cStart; cc < cStart + cSpan; cc++) occupancy[rr][cc] = 1;
      }
    };

    // find first column >= minCol in `row` that can fit `need` contiguous free cols
    const findFreeCol = (row: number, need: number, minCol = 0) => {
      ensureRow(row);
      for (let c = minCol; c <= total - need; c++) {
        let free = true;
        for (let cc = c; cc < c + need; cc++) {
          if (occupancy[row][cc]) {
            free = false;
            break;
          }
        }
        if (free) return c;
      }
      return -1;
    };

    const out: PlacedCell[] = [];

    // placeCell: tries to place at rowHint (or 0) and at/after colHint (if provided).
    // If can't place in that row, it will scan subsequent rows (still respecting colHint as minCol only for first attempted row).
    const placeCell = (
      node: React.ReactNode,
      colSpan: number,
      rowSpan: number,
      align?: AlignType,
      className?: string,
      key?: string,
      rowHint?: number,
      colHint?: number
    ): [number, number] => {
      let r = rowHint ?? 0;
      // First attempt: try to place in rowHint at or after colHint (if given)
      let c = findFreeCol(r, colSpan || 1, colHint ?? 0);

      // If not found in that row, find in later rows (in later rows, allow search from 0)
      while (c === -1) {
        r++;
        ensureRow(r);
        c = findFreeCol(r, colSpan || 1, 0);
      }
      if (colSpan) {
        markOccupied(r, c, rowSpan, colSpan);

        out.push({
          key: key ?? `cell-${out.length}`,
          node,
          gridColumnStart: c + 1,
          gridColumnSpan: colSpan,
          gridRowStart: r + 1,
          gridRowSpan: rowSpan,
          align,
          className,
        });
      }
      return [r, c];
    };

    // compute how many contiguous free columns exist in `row` starting at startCol
    const calcRemainingColSpan = (row: number, startCol: number) => {
      ensureRow(row);
      let count = 0;
      for (let c = startCol; c < total; c++) {
        if (occupancy[row][c] === 0) count++;
        else break;
      }
      return count;
    };

    /** 재귀적 배치
     * startRow: 시도할 기본 row (label을 이 row에 넣으려 시도)
     * accOffset: (optional) 최소 시작 컬럼(index, 0-based) — label placement 시 이 값을 minCol로 사용
     */
    const traverse = (items: GridCell[], startRow = 0, accOffset = 0) => {
      let currentRow = startRow;

      for (const item of items) {
        // invisible 처리: flag가 있고 data에 값 없으면 skip
        if (item.invisible && !data?.[item.key]) continue;

        const colNum = item.colNum ?? 1;
        const rowSpan = item.rowSpan ?? defaultRowSpan;
        const len = total / colNum - accOffset;

        // labelSpan 기본 계산 (기존 로직 유지)
        const labelSpan =
          item?.valueSpan === 0
            ? len
            : item.labelSpan ?? Math.max(1, Math.floor(lSpan / (item.children?.length ? colNum : 1)));

        // valueSpan: 명시값 우선. 없으면 현재 row의 연속된 빈칸을 기준으로 자동 계산
        let valueSpan = labelSpan === 0 ? len : item.children?.length ? 0 : item.valueSpan; // may be undefined

        const valueNode = item.value ?? data?.[item.key];
        const valueYn = item.key?.endsWith('Yn');

        // 배치 헬퍼: label과 value를 연속으로 배치 (value는 label 오른쪽부터)
        const placeLabelAndValue = () => {
          // label은 accOffset(=minCol) 이후에 배치되도록 시도
          const [labelRow, labelCol] = placeCell(
            item.label,
            labelSpan,
            rowSpan,
            item.lAlign ?? lAlign,
            `label-cell bg-gray-100 border-r ${item.class ?? 'p-2'}`,
            `${item.key}-label`,
            currentRow,
            accOffset > 0 ? accOffset : undefined // label은 accOffset 이후에 배치 시도
          );

          // value는 label 바로 오른쪽을 colHint로 줘서 우측으로 붙게 함
          const valueStartCol = labelCol + labelSpan;

          if (valueSpan == null) {
            // 자동 계산: 현재 row에서 label 오른쪽부터 연속된 빈 칸 수
            const rem = calcRemainingColSpan(labelRow || currentRow, valueStartCol);
            // 가능한 최소 1, 그리고 len - labelSpan 을 초과하지 않도록 cap(기존 len 기반 제약을 완곡히 보장)
            const cap = Math.max(1, Math.floor(len - labelSpan));
            valueSpan = Math.max(1, Math.min(rem, cap));
          }

          const [valueRow, valueCol] = placeCell(
            valueYn ? (valueNode ? 'Y' : 'N') : valueNode,
            valueSpan,
            rowSpan,
            item.vAlign ?? vAlign,
            `value-cell truncate ${item.class ?? 'p-2'}`,
            `${item.key}-value`,
            labelRow,
            valueStartCol // label 옆부터 강제 시도 (minCol)
          );

          return { labelRow, labelCol, valueRow, valueCol };
        };

        const { labelRow, labelCol, valueRow, valueCol } = placeLabelAndValue();

        // children 존재 시: **같은 row**에서 부모 label+value 우측부터 배치
        if (item.children?.length) {
          // children 시작 컬럼은 value의 끝 열 (absolute column index)
          const childStartCol = valueCol + (valueSpan ?? 0);

          // 각 자식을 순서대로 같은 row에서 배치(배치 실패시 이후 row로 자동 이행됨)
          let childAcc = childStartCol;
          item.children.forEach((child, i) => {
            // child를 traverse로 넣되 accOffset을 childAcc로 줘서 label placement 시 minCol로 작동
            traverse(
              [
                {
                  ...child,
                  colNum,
                  labelSpan,
                  // preserve child's explicit valueSpan if provided; otherwise allow auto compute inside traverse
                },
              ],
              labelRow + (child.rowSpan ?? i), // same row as parent
              labelSpan
            );

            // after placing one child entry, we should recompute where the next child should start:
            // find how many columns were just consumed by the last placed cell(s).
            // We can inspect last entries in out to update childAcc.
            // Find the latest placed cell that belongs to this child (label or value)
            const lastPlaced = out[out.length - 1];
            if (lastPlaced) {
              // next child should start after the end of the last placed cell's column
              childAcc = lastPlaced.gridColumnStart - 1 + lastPlaced.gridColumnSpan;
            } else {
              // fallback: move one column
              childAcc = childAcc + 1;
            }
          });
        }
      }
    };

    traverse(rows);
    return { placed: out, totalGridRows: occupancy.length };
  }, [rows, total, lSpan, defaultRowSpan, data]);

  const gridStyle: React.CSSProperties = {
    display: 'grid',
    gridTemplateColumns: `repeat(${total}, 1fr)`,
    gridAutoRows: 'minmax(40px, auto)',
  };
  return (
    <div className="rounded-md border border-gray-300 overflow-hidden">
      <div style={gridStyle}>
        {placedCells.placed.map((pc, i) => (
          <div
            key={pc.key}
            ref={register(0, i)}
            className={clsx(`border border-gray-200`, pc.className)}
            style={{
              gridColumn: `${pc.gridColumnStart} / span ${pc.gridColumnSpan}`,
              gridRow: `${pc.gridRowStart} / span ${pc.gridRowSpan}`,
              display: 'flex',
              flexWrap: 'wrap',
              alignContent: pc.align ?? 'left',
            }}
          >
            {pc.node}
          </div>
        ))}
      </div>
    </div>
  );
};

export default GridTable;
