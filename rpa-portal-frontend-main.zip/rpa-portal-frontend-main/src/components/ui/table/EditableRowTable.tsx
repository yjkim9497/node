// src/components/ui/table/EditableRowTable.tsx
import React, { ReactNode, useMemo, useState } from 'react';
import Table from './Table';
import Button from '@components/ui/Button';

export interface EditableRowTableProps<Row> {
  /** 도메인 데이터 컬럼만 넘겨주세요. 체크박스 컬럼은 자동으로 앞에 붙습니다. */
  columns: any[];
  /** 행 리스트 (상위 컴포넌트에서 관리하는 상태) */
  value: Row[];
  /** 행 리스트 변경 콜백 (setState 처럼 사용) */
  onChange: (rows: Row[]) => void;
  /** 빈 행 하나를 만들어 주는 팩토리 함수 */
  createEmptyRow: () => Row;
  /** row 고유 key 생성 함수 (없으면 id/workSequence/robotSequence/인덱스 순으로 사용) */
  rowKey?: (row: Row, index: number) => string;
  /** 최소 행 개수 (기본 1: 모두 삭제해도 1행은 남도록) */
  minRows?: number;
  /** 상단 오른쪽 영역에 추가로 넣을 버튼들 (예: 공용 변수 불러오기) */
  rightActions?: ReactNode;
  /** 상단 왼쪽에 추가로 붙일 요소 */
  leftActionsExtra?: ReactNode;
  /** 래퍼 div className */
  className?: string;
  /** Table 의 embedded 모드 사용 여부 */
  embedded?: boolean;
  /** 체크박스 컬럼 표시 여부 (기본 true) */
  showCheckbox?: boolean;
  /** 추가 / 삭제 버튼 라벨 */
  addLabel?: string;
  deleteLabel?: string;
}

export default function EditableRowTable<Row>({
  columns,
  value,
  onChange,
  createEmptyRow,
  rowKey,
  minRows = 1,
  rightActions,
  leftActionsExtra,
  className,
  embedded = false,
  showCheckbox = true,
  addLabel = '추가',
  deleteLabel = '삭제',
}: EditableRowTableProps<Row>) {
  // 이 테이블 안에서만 쓰는 선택 상태용 form (ids 배열)
  const [selectForm, setSelectForm] = useState<{ ids?: string[] }>({ ids: [] });

  const rows = value ?? [];

  const resolveRowKey = (row: Row, index: number) =>
    String(
      rowKey
        ? rowKey(row, index)
        : (row as any)?.id ?? (row as any)?.workSequence ?? (row as any)?.robotSequence ?? index
    );

  const handleAdd = () => {
    onChange([...(rows || []), createEmptyRow()]);
  };

  const handleDelete = () => {
    const selectedIds = selectForm.ids ?? [];
    if (!selectedIds.length) return;

    let next = rows.filter((row, index) => !selectedIds.includes(resolveRowKey(row, index)));

    // 최소 행 개수 보장
    if (minRows > 0 && next.length < minRows) {
      const need = minRows - next.length;
      const extra: Row[] = Array.from({ length: need }, () => createEmptyRow());
      next = [...next, ...extra];
    }

    setSelectForm({ ids: [] });
    onChange(next);
  };

  const tableData = {
    content: rows,
    pageNo: 1,
    totalPages: 1,
    totalCount: rows.length,
    pageRowCount: rows.length,
  };

  const tableColumns = useMemo(
    () => (showCheckbox ? [{ key: 'checkbox', label: '', width: 'w-8' }, ...columns] : columns),
    [columns, showCheckbox]
  );

  return (
    <div className={className}>
      {/* 상단 버튼 영역 */}
      <div className="mb-2 flex items-center justify-between">
        <div className="flex gap-2">
          <Button size="sm" onClick={handleAdd}>
            {addLabel}
          </Button>
          {showCheckbox && (
            <Button size="sm" variant="secondary" onClick={handleDelete}>
              {deleteLabel}
            </Button>
          )}
          {leftActionsExtra}
        </div>
        {rightActions}
      </div>

      {/* 실제 테이블 */}
      <Table
        embedded={embedded}
        columns={tableColumns}
        data={tableData}
        onPageChange={() => {}}
        form={selectForm}
        setForm={setSelectForm}
        filter={{}} // 정렬 안 쓰는 테이블이라 빈 객체 전달
        rowKey={rowKey as any}
      />
    </div>
  );
}
