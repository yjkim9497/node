// src/components/ui/Table/TablePagination.tsx
import Select from '@components/form/Select';
import { FC, useEffect, useState } from 'react';
import { Label } from 'recharts';

interface Props {
  pageNo: number;
  totalPages: number;
  totalCount: number;
  pageRowCount: number;
  onPageChange: (args: Record<string, any>) => void;
  groupSize?: number;
}

const TablePagination: FC<Props> = ({ pageNo, totalPages, totalCount, pageRowCount, onPageChange, groupSize = 5 }) => {
  const [form, setForm]: [Record<string, any>, any] = useState({ pageRowCount });
  const startItem = (pageNo - 1) * pageRowCount + 1;
  const endItem = Math.min(pageNo * pageRowCount, totalCount);

  // compute pageNo groups
  const currentGroup = Math.floor((pageNo - 1) / groupSize);
  const groupStart = currentGroup * groupSize + 1;
  const groupEnd = Math.min(groupStart + groupSize - 1, totalPages);

  const pageNos = [] as number[];
  for (let i = groupStart; i <= groupEnd; i++) pageNos.push(i);

  const prevGroupPage = Math.max(1, groupStart - 1);
  const nextGroupPage = Math.min(totalPages, groupEnd + 1);

  useEffect(() => {
    form?.pageRowCount && onPageChange({ pageRowCount: form?.pageRowCount });
  }, [form.pageRowCount]);

  const inputProps = (name: string, label: string) => ({
    id: name,
    name,
    value: form?.name,
    form,
    setForm,
    placeholder: label,
    label,
    className: 'border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400',
  });

  return (
    !!totalCount && (
      <div className="flex items-center justify-between py-2 px-1">
        <div className="text-sm">
          조회결과 {startItem}-{endItem}/{totalCount}
        </div>

        <div className="flex items-center gap-1">
          <button
            className={`px-2 py-1 border rounded ${pageNo === 1 ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : ''}`}
            onClick={() => onPageChange({ pageNo: 1 })}
            disabled={pageNo === 1}
          >
            ⏮
          </button>

          <button
            className={`px-2 py-1 border rounded ${
              groupStart === 1 ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : ''
            }`}
            onClick={() => onPageChange({ pageNo: prevGroupPage })}
            disabled={groupStart === 1}
          >
            {'<<'}
          </button>

          <button
            className={`px-2 py-1 border rounded ${pageNo === 1 ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : ''}`}
            onClick={() => onPageChange({ pageNo: Math.max(1, pageNo - 1) })}
            disabled={pageNo === 1}
          >
            {'<'}
          </button>

          {pageNos.map((p) => (
            <button
              key={p}
              onClick={p === pageNo ? undefined : () => onPageChange({ pageNo: p })}
              className={`px-2 py-1 border rounded ${p === pageNo ? 'bg-blue-600 text-white' : ''}`}
            >
              {p}
            </button>
          ))}

          <button
            className={`px-2 py-1 border rounded ${
              pageNo === totalPages ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : ''
            }`}
            onClick={() => onPageChange({ pageNo: Math.min(totalPages, pageNo + 1) })}
            disabled={pageNo === totalPages}
          >
            {'>'}
          </button>

          <button
            className={`px-2 py-1 border rounded ${
              groupEnd === totalPages ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : ''
            }`}
            onClick={() => onPageChange({ pageNo: nextGroupPage })}
            disabled={groupEnd === totalPages}
          >
            {'>>'}
          </button>

          <button
            className={`px-2 py-1 border rounded ${
              pageNo === totalPages ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : ''
            }`}
            onClick={() => onPageChange({ pageNo: totalPages })}
            disabled={pageNo === totalPages}
          >
            ⏭
          </button>
        </div>

        <Select
          {...inputProps('pageRowCount', '페이지')}
          className="border rounded px-2 py-1 focus:ring-2 focus:ring-blue-400"
          options={[
            { label: '15개씩 보기', value: '15' },
            { label: '20개씩 보기', value: '20' },
            { label: '25개씩 보기', value: '25' },
            { label: '30개씩 보기', value: '30' },
          ]}
        />
        {/* <div style={{ width: 120 }} /> */}
      </div>
    )
  );
};

export default TablePagination;
