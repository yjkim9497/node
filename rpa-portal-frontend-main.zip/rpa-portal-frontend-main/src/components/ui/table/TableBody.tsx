import React, { FC, Fragment, useMemo, useState } from 'react';
import clsx from 'clsx';
import Checkbox from '@components/form/Checkbox';
import LabelWrapper from '@components/common/LabelWrapper';
import Table from './Table';
import keyTransformMapper from '@utils/keyTransformMapper';
import { useTruncateMatrixObserver } from '@hooks/useTruncateObserver';
import Radio from '@components/form/Radio';

/* -----------------------------
   Types
   -----------------------------*/
interface Column {
  [k: string]: any;
  rowSpan: string;
  default: any;
  key?: string;
  label?: React.ReactNode;
  header?: React.ReactNode;
  width?: string;
  className?: string;
  children?: Column[];
  render?: (row: Record<string, any>, rowIndex: number, rowId: string) => React.ReactNode;
  title?: ((row: Record<string, any>) => string) | string;
}

interface Props {
  columns: Column[];
  data: any[];
  aligns?: 'left' | 'center' | 'right';
  pageNo?: number;
  onRowClick?: (row: any) => void;
  inputProps: (id: string, label: string) => any;
  nested?: { childColumns: Column[]; getChildren?: (row: any) => any[] | undefined | null };
  rowKey?: (row: any, index: number) => string;
}

/* -----------------------------
   PreparedColumn + helpers
   Precompute tree-derived metadata once and reuse
   -----------------------------*/
interface PreparedColumn {
  original: Column;
  leaves: Column[]; // all leaf nodes under this column
  leafCount: number;
  maxDepth: number; // depth (levels) including self
  depthMap: Map<number, Column[]>; // depth index -> columns at that depth relative to this column
  ratios: number[]; // width ratios for each leaf
}

type RegisterFn = (rowIndex: number, colIndex: number) => (el: HTMLElement | null) => void;

const parseTailwindWidthNum = (cls?: string): number => {
  if (!cls) return 1;
  const match = (cls || '').match(/w-(\\d+)/);
  return match ? parseInt(match[1], 10) : 1;
};

const collectLeaves = (col?: Column): Column[] => {
  if (!col) return [];
  if (!col.children || col.children.length === 0) return [col];
  return col.children.flatMap((c) => collectLeaves(c));
};

const computeMaxDepth = (col?: Column): number => {
  if (!col) return 0;
  if (!col.children || col.children.length === 0) return 1;
  return 1 + Math.max(...col.children.map((c) => computeMaxDepth(c)));
};

const collectAtDepthLocal = (col?: Column, depth = 0): Column[] => {
  if (!col) return [];
  if (depth === 0) return [col];
  if (!col.children || col.children.length === 0) return [];
  let level: Column[] = col.children.slice();
  for (let d = 1; d < depth; d++) {
    level = level.flatMap((n) => (n.children && n.children.length ? n.children : []));
    if (level.length === 0) return [];
  }
  return level;
};

const normalizeColumns = (cols: Column[]): Column[] => {
  const normalized: Column[] = [];
  cols.forEach((col) => {
    if (!col.key && col.children && col.children.length > 0) {
      normalized.push(...normalizeColumns(col.children));
    } else {
      const cloned = { ...col };
      if (cloned.children) cloned.children = normalizeColumns(cloned.children);
      normalized.push(cloned);
    }
  });
  return normalized;
};

const prepareColumns = (cols: Column[]): PreparedColumn[] => {
  const normalized = normalizeColumns(cols);

  const prepared: PreparedColumn[] = normalized.map((col) => {
    const leaves = collectLeaves(col);
    const leafCount = leaves.length;
    const maxDepth = computeMaxDepth(col);
    const depthMap = new Map<number, Column[]>();
    for (let d = 0; d < maxDepth; d++) {
      depthMap.set(d, collectAtDepthLocal(col, d));
    }
    const totalLeafWidth = leaves.reduce((s, ln) => s + parseTailwindWidthNum(ln.width ?? ln.className), 0);
    const ratios = leaves.map((ln) => (parseTailwindWidthNum(ln.width ?? ln.className) / (totalLeafWidth || 1)) * 100);

    return {
      original: col,
      leaves,
      leafCount,
      maxDepth,
      depthMap,
      ratios,
    };
  });

  return prepared;
};

/* -----------------------------
   Cell renderers (strategic, small helpers)
   -----------------------------*/
interface CellContext {
  col: Column;
  row: Record<string, any>;
  rowIndex: number;
  rowId: string;
  nested?: Props['nested'];
  expanded?: Set<string | number>;
  toggle?: (id: string | number) => void;
  inputProps?: (id: string, label: string) => any;
  pageNo?: number;
}

type CellRenderer = (ctx: CellContext) => React.ReactNode;

const Renderers: Record<string, CellRenderer> = {
  expand: ({ col, row, rowIndex, rowId, nested, expanded, toggle }) => {
    const getChildren = nested?.getChildren ?? ((r) => r?.children);
    const kids = nested ? getChildren?.(row) || [] : [];
    const canExpand = !!nested && kids.length > 0;
    const isExpanded = canExpand && !!expanded?.has(rowId);
    if (!canExpand) return null;
    return (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          toggle?.(rowId);
        }}
        aria-expanded={isExpanded}
        aria-controls={`nested-panel-${rowId}`}
        className="flex h-6 w-6 items-center justify-center rounded-md border text-sm m-auto"
        title={isExpanded ? '접기' : '펼치기'}
      >
        <span className={clsx('transition-transform select-none', isExpanded ? 'rotate-45' : '')}>+</span>
      </button>
    );
  },
  checkbox: ({ col, row, rowIndex, rowId, inputProps, pageNo }) => {
    return (
      <LabelWrapper data-stop-row-click>
        <Checkbox
          key={`checkbox-${pageNo ?? 0}-${rowId}-${col.name ?? ''}`}
          {...(inputProps ? inputProps(col.name ?? 'ids', '항목') : {})}
          id={col.name ? `${row.name ?? ''}${col.name}${col.suffix ?? ''}` : rowId}
          value={rowId}
          placeholder={col.suffix ? `${row.name ?? ''}${col.name}` : 'undefined'}
          defaultValue={[]}
          className="cursor-pointer"
        />
      </LabelWrapper>
    );
  },

  radio: ({ row, rowIndex, rowId, inputProps, pageNo }) => {
    return (
      <LabelWrapper data-stop-row-click>
        <Radio
          key={`checkbox-${pageNo ?? 0}-${rowId}`}
          {...(inputProps ? inputProps('ids', '항목') : {})}
          id={rowId}
          value={rowId}
          defaultValue={''}
          className="cursor-pointer"
        />
      </LabelWrapper>
    );
  },

  valueMap: ({ col, row }) => col.valueMap[row[col.key ?? '']] ?? col.valueMap.default ?? '',

  badge: ({ col, row }) => (
    <span className="inline-block rounded bg-red-100 px-2 py-0.5 text-xs text-red-700">{row[col.key as string]}</span>
  ),

  marker: () => <span className="flex justify-center text-gray-600 select-none">ㄴ</span>,

  yn: ({ col, row }) => (row[col.key as string] ? 'Y' : 'N'),

  delimiter: ({ col, row }) => {
    const delim = col.delimiter ?? ',';
    const seg = col.key?.split(delim)?.filter(Boolean);
    return seg?.reduce(
      (a: string, c: string, i: number) => a + (i > 0 ? delim : '') + keyTransformMapper(c, row?.[c]),
      ''
    );
  },

  default: ({ col, row }) => col.content ?? row?.[col.key ?? ''] ?? col.default ?? '-',
};

const detectType = (col: Column): string => {
  if (!col.key) return 'default';
  if (col.key === 'expand') return 'expand';
  if (col.key === 'checkbox') return 'checkbox';
  if (col.key === 'radio') return 'radio';
  if (col.key === 'badge') return 'badge';
  if (col.key === 'marker') return 'marker';
  if (col.valueMap) return 'valueMap';
  if (col.delimiter) return 'delimiter';
  if (col.key?.endsWith('Yn')) return 'yn';
  return 'default';
};

function getMatrixSize(data: any, rowNum?: number) {
  const rowI = data.size - 1;
  const colI = (data.get(rowNum)?.length ?? 0) - 1;

  return { rowI, colI };
}

/* -----------------------------
   RowRenderer component
   -----------------------------*/
interface RowRendererProps {
  preparedColumns: PreparedColumn[];
  row: Record<string, any>;
  rowIndex: number;
  rowId: string;
  aligns: 'left' | 'center' | 'right';
  register: RegisterFn;
  expanded: Set<string | number>;
  toggle: (id: string | number) => void;
  nested?: Props['nested'];
  inputProps: (id: string, label: string) => any;
  pageNo?: number;
  onRowClick?: (row: any, e: any) => void;
}

const RowRenderer: FC<RowRendererProps> = ({
  preparedColumns,
  row,
  rowIndex,
  rowId,
  aligns,
  register,
  expanded,
  toggle,
  nested,
  inputProps,
  pageNo,
  onRowClick,
}) => {
  const rowHeight = 38;
  const maxDepth = Math.max(...preparedColumns.map((p) => p.maxDepth), 1);

  return (
    <tr key={rowId} className="even:bg-gray-50 hover:bg-blue-100" onClick={(e) => onRowClick?.(row, e)}>
      {preparedColumns.map((p, colIndex) => {
        const col = p.original;
        const rowSpan = row[col.rowSpan ?? 'rowSpan'];
        const tdClass = clsx(
          'border align-center p-0',
          (col.key === 'checkbox' || col.key === 'radio' || col.key === 'expand') && 'relative',
          col.width,
          col.className
        );
        if (rowSpan === 0) return;
        return (
          <td
            key={`${rowId}-${col.key ?? colIndex}-${col.name ?? ''}${col.suffix ?? ''}`}
            className={tdClass}
            colSpan={p.leafCount}
            rowSpan={rowSpan > 1 ? rowSpan : undefined}
          >
            <div
              style={{
                display:
                  col.totalArray &&
                  !col.totalArray?.some((e: any) => e.includes(`${row.name}${col.name}${col.suffix ?? ''}`))
                    ? 'none'
                    : 'grid',
                gridTemplateColumns: p.ratios.map((r) => `${r}%`).join(' '),
                gridTemplateRows: `repeat(${p.maxDepth}, ${(rowHeight * Math.max(maxDepth, rowSpan)) / p.maxDepth}px)`,
                width: '100%',
              }}
            >
              {Array.from({ length: maxDepth }).map((_, depthIdx) => {
                const nodes = p.depthMap.get(depthIdx) || [];
                const { rowI, colI } = getMatrixSize(p.depthMap, depthIdx);
                if (!nodes || nodes.length === 0) return null;
                return (
                  <Fragment key={`depth-${depthIdx}`}>
                    {nodes.map((node, cIdx) => {
                      const nodeLeaf = collectLeaves(node).length || 1;
                      const title =
                        typeof node.title === 'function'
                          ? node.title(row)
                          : typeof node.title === 'string'
                          ? node.title
                          : undefined;

                      // only register leaf nodes for truncate observer
                      const shouldRegister = !node.children || node.children.length === 0;

                      return (
                        <div
                          ref={shouldRegister ? register(rowIndex, colIndex) : null}
                          key={`${rowId}-${col.key}-${node.key ?? Math.random()}-${depthIdx}`}
                          onClick={(e) => {
                            if (node.render) e.stopPropagation();
                          }}
                          style={{
                            gridColumn: `span ${nodeLeaf}`,
                            alignContent: 'center',
                            textAlign: aligns,
                          }}
                          className={clsx(
                            'px-2 py-2 w-full truncate',
                            node.className,
                            rowI && depthIdx < rowI ? 'border-b' : '',
                            colI && cIdx < colI ? 'border-r' : ''
                          )}
                          title={title}
                        >
                          {node.render
                            ? node.render(row, rowIndex, rowId)
                            : (() => {
                                const type = detectType(node);
                                const ctx: CellContext = {
                                  col: node,
                                  row,
                                  rowIndex,
                                  rowId,
                                  nested,
                                  expanded,
                                  toggle,
                                  inputProps,
                                  pageNo,
                                };
                                const renderer = Renderers[type] ?? Renderers.default;
                                return renderer(ctx);
                              })()}
                        </div>
                      );
                    })}
                  </Fragment>
                );
              })}
            </div>
          </td>
        );
      })}
    </tr>
  );
};

/* -----------------------------
   NestedRow component
   keep using top-level Table for nested content to preserve existing behavior
   -----------------------------*/
const NestedRow: FC<{
  id: string | number;
  colCount: number;
  aligns: 'left' | 'center' | 'right';
  kids: any[];
  onRowClick?: (row: any) => void;
  inputProps: (id: string, label: string) => any;
  nested: { childColumns: Column[] };
  getChildren: (row: any) => any[] | undefined | null;
}> = ({ id, colCount, kids, onRowClick, inputProps, nested, getChildren, aligns }) => {
  const [nestedForm, setNestedForm] = useState<Record<string, unknown>>({});

  return (
    <tr id={`nested-panel-${id}`} className="bg-gray-50/50">
      <td colSpan={colCount} className="p-0">
        <div className="border-t pl-8 py-3" onClick={(e) => e.stopPropagation()}>
          <Table
            embedded
            columns={nested.childColumns}
            data={{
              content: kids,
              pageNo: 1,
              totalPages: 1,
              totalCount: kids.length,
              pageRowCount: kids.length,
            }}
            onPageChange={() => {}}
            onRowClick={onRowClick}
            form={nestedForm}
            setForm={setNestedForm}
            childColumns={nested.childColumns}
            getChildren={getChildren}
            aligns={aligns}
          />
        </div>
      </td>
    </tr>
  );
};

/* -----------------------------
   Main TableBody component
   -----------------------------*/
const TableBody: FC<Props> = ({ columns, data, pageNo, inputProps, onRowClick, nested, rowKey, aligns = 'left' }) => {
  const [expanded, setExpanded] = useState<Set<string | number>>(new Set());
  const hookResult = useTruncateMatrixObserver();
  const register = (hookResult as unknown as { register?: RegisterFn }).register ?? (() => () => undefined);

  // prepare columns once
  const preparedColumns = useMemo(() => prepareColumns(columns), [columns]);

  const totalLeafColumns = useMemo(() => preparedColumns.reduce((s, p) => s + p.leafCount, 0), [preparedColumns]);

  const toggle = (id: string | number) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const getChildren = nested?.getChildren ?? ((row) => row?.children);

  return (
    <tbody>
      {(!data || data.length === 0) && (
        <tr>
          <td colSpan={totalLeafColumns} className="text-center py-5 text-gray-500">
            데이터가 없습니다.
          </td>
        </tr>
      )}

      {data?.map((row, idx) => {
        const id = rowKey
          ? rowKey(row, idx)
          : String(row?.id ?? row?.workSequence ?? row?.robotSequence ?? `${pageNo ?? 0}-${idx}`);

        const kids = nested ? getChildren(row) || [] : [];
        const canExpand = !!nested && kids.length > 0;
        const isExpanded = canExpand && expanded.has(id);

        return (
          <Fragment key={id}>
            <RowRenderer
              preparedColumns={preparedColumns}
              row={row}
              rowIndex={idx}
              rowId={id}
              aligns={aligns}
              register={register}
              expanded={expanded}
              toggle={toggle}
              nested={nested}
              inputProps={inputProps}
              pageNo={pageNo}
              onRowClick={onRowClick}
            />

            {canExpand && isExpanded && (
              <NestedRow
                id={id}
                colCount={totalLeafColumns}
                kids={kids}
                onRowClick={onRowClick}
                inputProps={inputProps}
                nested={nested!}
                getChildren={getChildren}
                aligns={aligns}
              />
            )}
          </Fragment>
        );
      })}
    </tbody>
  );
};

export default TableBody;
