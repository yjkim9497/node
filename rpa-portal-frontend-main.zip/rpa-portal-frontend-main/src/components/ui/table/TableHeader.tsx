// src/components/ui/Table/TableHeader.tsx
import LabelWrapper from '@components/common/LabelWrapper';
import Checkbox from '@components/form/Checkbox';
import React, { FC } from 'react';

interface Props {
  columns: any[];
  totalArray: any[];
  inputProps: (id: string, label: string) => any;
  filter: Record<string, any>;
  onPageChange: (args: Record<string, any>) => void;
  aligns: 'left' | 'center' | 'right';
}

const isGroup = (c: any) => !c.parentsOnly && Array.isArray(c?.children) && c.children.length > 0;
const hasGroupRow = (cols: any[]) => cols.some(isGroup);
const leafLabel = (c: any, filter: any) =>
  c.sortKey
    ? `${c.label ?? ''}${c.sortKey && filter.sortKey === c.sortKey ? (filter.sortOrder === 'DESC' ? ' ▼' : ' ▲') : ''}`
    : c.label;
const leafClass = (c: any) => `border ${c?.key === 'checkbox' ? 'relative' : 'px-2 py-2'} ${c?.width ?? ''}`;

const TableHeader: FC<Props> = ({ columns, totalArray, filter, aligns, onPageChange, inputProps }) => {
  const hasGroups = hasGroupRow(columns);

  const onSort = (e: React.MouseEvent, c: any) => {
    if (!c?.sortKey) return;
    e.stopPropagation();
    onPageChange(
      filter.sortKey === c.sortKey
        ? { sortOrder: filter.sortOrder === 'DESC' ? 'ASC' : 'DESC' }
        : { sortKey: c.sortKey, sortOrder: 'DESC' }
    );
  };

  const renderLeaf = (c: any, extra: Record<string, any> = {}) => (
    <th
      key={c.suffix ? `${c.name}${c.suffix}` : c.name ?? c.key}
      scope="col"
      className={leafClass(c)}
      style={{ justifyItems: c.aligns ?? aligns, textAlign: c.aligns ?? aligns }}
      onClick={(e) => onSort(e, c)}
      {...extra}
    >
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '100%',
          alignItems: 'center',
          gridTemplateRows: `repeat(${c.key === 'checkbox' && c.label ? 2 : 1}, 
            ${c.key === 'checkbox' && c.label ? '28' : '32'}px)`,
          width: '100%',
        }}
      >
        {c.label && leafLabel(c, filter)}
        {c.key === 'checkbox' && (
          <div style={{ position: 'relative' }}>
            <LabelWrapper>
              <Checkbox
                {...inputProps(c.name ?? 'ids', '항목')}
                id="All"
                value={c.totalArray ?? totalArray}
                disabled={!(c.totalArray ?? totalArray)?.length}
                defaultValue={[]}
                placeholder="All"
                className="cursor-pointer"
              />
            </LabelWrapper>
          </div>
        )}
      </div>
    </th>
  );

  return (
    <thead>
      {/* Upper row: groups and standalone leaves */}
      <tr className="bg-gray-100">
        {columns.map((c: any, idx: number) =>
          c.children?.length > 0 ? (
            <th
              key={`grp-${idx}`}
              scope="colgroup"
              colSpan={c.children?.length}
              rowSpan={c.parentsOnly ? 2 : 1}
              className={`border px-2 py-2 ${c?.width ?? ''} ${c?.className ?? ''}`}
              style={{ justifyItems: c.aligns ?? aligns, textAlign: c.aligns ?? aligns }}
            >
              {c.header ?? c.label}
            </th>
          ) : (
            renderLeaf(c, { rowSpan: hasGroups ? 2 : 1 })
          )
        )}
      </tr>

      {/* Lower row: only children of groups */}
      {hasGroups && (
        <tr className="bg-gray-50">
          {columns.flatMap((c: any) => (isGroup(c) ? c.children.map((child: any) => renderLeaf(child)) : []))}
        </tr>
      )}
    </thead>
  );
};

export default TableHeader;
