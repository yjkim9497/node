import { NavLink, useLocation } from 'react-router-dom';
import { startTransition } from 'react';
import { navigate } from '@routes/NavigationProvider';

export default function TransLink({ to, children, ...rest }) {
  const location = useLocation();

  const handleClick = (e) => {
    e.preventDefault();
    if (location.pathname !== to) {
      startTransition(() => navigate(to));
    }
  };

  return (
    <NavLink to={to} {...rest} onClick={handleClick}>
      {children}
    </NavLink>
  );
}
