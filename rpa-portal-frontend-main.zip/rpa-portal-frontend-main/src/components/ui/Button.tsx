// src/components/common/Button.tsx
import { FC, ButtonHTMLAttributes, ReactNode } from 'react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline' | 'overlay';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  shape?: 'round' | 'square';
  asLabel?: boolean;
  children: ReactNode;
}

const Button: FC<ButtonProps> = ({
  variant = 'outline',
  size = 'md',
  shape = 'square',
  asLabel = false,
  children,
  ...props
}) => {
  const base = 'px-3 py-1 rounded font-medium border truncate max-w-xs';
  const labelBase =
    'px-3 py-1 rounded font-medium border truncate max-w-xs select-none cursor-default pointer-events-none';

  const variantClass =
    variant === 'primary'
      ? 'bg-blue-600 text-white border-transparent hover:bg-blue-700'
      : variant === 'secondary'
      ? 'bg-gray-100 text-gray-800 border-gray-300 hover:bg-gray-200'
      : variant === 'ghost'
      ? 'bg-transparent text-gray-700 border-gray-200 hover:bg-gray-100'
      : variant === 'danger'
      ? 'bg-red-600 text-white border-transparent hover:bg-red-700'
      : variant === 'overlay'
      ? 'bg-black/40 text-white border-transparent hover:bg-black/50'
      : // outline
        'bg-transparent text-blue-600 border-blue-600 hover:bg-blue-600 hover:text-white';

  const sizeClass =
    size === 'xs'
      ? 'text-xs'
      : size === 'sm'
      ? 'text-sm'
      : size === 'md'
      ? 'text-base'
      : size === 'lg'
      ? 'text-lg'
      : size === 'xl'
      ? 'text-xl'
      : '';

  const shapeClass = shape === 'round' ? 'rounded-full' : 'rounded-md';

  return (
    <button className={`${asLabel ? labelBase : base} ${variantClass} ${sizeClass} ${shapeClass}`} {...props}>
      {children}
    </button>
  );
};

export default Button;
