// src/components/common/Toggle.tsx
import React, { cloneElement } from 'react';
import clsx from 'clsx';

type ToggleChild = React.ReactElement<{ className?: string }>;

type Props = {
  size?: 'sm' | 'md';
  className?: string;
  title?: string;
  /** Must be checkbox (UnifiedInput/Checkbox) */
  children: ToggleChild;
};

export default function Toggle({ size = 'sm', className, title, children }: Props) {
  const isSm = size === 'sm';

  const inputEl = cloneElement(children, {
    className: clsx('sr-only peer', children.props.className),
  });

  return (
    <label
      className={clsx(
        'relative inline-flex items-center select-none cursor-pointer',
        className
      )}
      title={title}
      onClick={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
    >
      {inputEl}

      {/* Track */}
      <span
        aria-hidden
        className={clsx(
          'block rounded-full transition-colors duration-200',
          isSm ? 'w-9 h-5' : 'w-11 h-6',
          'bg-gray-300 peer-checked:bg-green-500',
          'peer-focus-visible:ring-2 peer-focus-visible:ring-blue-400',
          'peer-disabled:bg-gray-200'
        )}
      />

      {/* Knob */}
      <span
        aria-hidden
        className={clsx(
          'absolute left-0.5 top-0.5 bg-white rounded-full shadow transition-transform duration-200',
          isSm ? 'w-4 h-4' : 'w-5 h-5',
          'translate-x-0',
          isSm ? 'peer-checked:translate-x-4' : 'peer-checked:translate-x-5',
          'peer-disabled:opacity-60'
        )}
      />
    </label>
  );
}
