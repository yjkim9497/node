// src/components/common/LoadingSpinner.jsx
export default function LoadingSpinner({ variant = 'overlay' }) {
  if (variant === 'inline') {
    return (
      <div className="flex items-center justify-center p-4">
        <div className="w-6 h-6 border-[3px] border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (variant === 'small') {
    return (
      <div className="inline-flex items-center justify-center">
        <div className="w-4 h-4 border-[2.5px] border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // 화면 중앙 전역 스피너
  return (
    <div className="fixed inset-0 flex items-center justify-center z-[500] pointer-events-none">
      <div className="w-20 h-20 border-[7px] border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
}
