export default function Card({ title, children, className = '' }) {
  return (
    <div
      className={`p-3 border rounded-lg shadow bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 ${className}`}
    >
      {title && <div className="text-gray-700 font-medium mb-3">{title}</div>}
      <div>{children}</div>
    </div>
  );
}
