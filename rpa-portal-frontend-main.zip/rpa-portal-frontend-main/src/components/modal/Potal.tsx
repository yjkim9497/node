import { ReactNode, useMemo } from 'react';
import { createPortal } from 'react-dom';
// -----------------------------
// Portal helper (DO NOT NEED NOW!!)
// -----------------------------
function ensureContainer(id = 'portal-root') {
  if (typeof document === 'undefined') return null;
  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement('div');
    el.setAttribute('id', id);
    document.body.appendChild(el);
  }
  return el;
}

export default function Portal({
  children,
  containerId = 'portal-root',
}: {
  children: ReactNode;
  containerId?: string;
}) {
  // SSR safe: only create portal on client
  const container = useMemo(
    () => (typeof document !== 'undefined' ? ensureContainer(containerId) : null),
    [containerId]
  );

  if (!container) return <>{children}</>; // SSR fallback (renders inline)
  return createPortal(children, container);
}
