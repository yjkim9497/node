import React, { useEffect, useRef, useState } from 'react';
import Button from '@components/ui/Button';
import Modal from './Modal';
import { useModalStore } from '@store/useModalStore';

const GlobalModal: React.FC = () => {
  const { stack, close } = useModalStore();

  return (
    <div
      id="portal-root"
      className={
        stack.length > 0 ? 'fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[2000]' : undefined
      }
    >
      {stack.map((modal, i) => (
        <ErrorAwareModal key={modal.id} modal={modal} i={i} close={close} />
      ))}
    </div>
  );
};

export default GlobalModal;

interface ErrorAwareModalProps {
  modal: ReturnType<typeof useModalStore.getState>['stack'][number];
  close: (id?: string) => void;
  i: number;
}

const ErrorAwareModal: React.FC<ErrorAwareModalProps> = ({ modal, close, i }) => {
  const [progress, setProgress] = useState(0);
  const intervalRef = useRef<number | null>(null);

  const onClose = () => {
    modal.onClose?.();
    close(modal.id);
  };

  const clearIntervalSafe = () => {
    if (intervalRef.current !== null) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  useEffect(() => {
    if (modal.type !== 'error' && !modal.showProgress) return;
    console.log(modal.content);
    const start = Date.now();
    const duration = modal.autoCloseDuration || 1500;
    setProgress(0);
    clearIntervalSafe();

    intervalRef.current = window.setInterval(() => {
      const elapsed = Date.now() - start;
      const percent = Math.min((elapsed / duration) * 100, 100);
      setProgress(percent);
      if (elapsed >= duration) {
        clearIntervalSafe();
        onClose();
      }
    }, 100);

    return clearIntervalSafe;
  }, [modal, close]);

  return (
    <Modal
      key={modal.id}
      onClose={onClose}
      className="fixed"
      visible={Boolean(modal.id)}
      size={modal.size}
      zIndex={modal.type === 'error' ? 1500 : 1000 - i}
      header={modal.type === 'error' ? 'ERROR' : modal.title}
      body={
        <>
          <div className="p-2 text-base text-center text-gray-700 whitespace-pre-line">{modal.content}</div>
          {(modal.type === 'error' || modal.showProgress) && (
            <div className="relative w-full h-1 bg-gray-200 mt-2 rounded-full overflow-hidden">
              <div
                className="absolute left-0 top-0 h-full bg-blue-500 transition-all duration-100 ease-linear"
                style={{ width: `${progress}%` }}
              />
            </div>
          )}
        </>
      }
      footer={
        <>
          {modal.confirmText ||
            (modal.onConfirm && (
              <Button
                variant="primary"
                onClick={() => {
                  modal.onConfirm?.();
                  onClose();
                }}
              >
                {modal.confirmText ?? '확인'}
              </Button>
            ))}
          <Button
            variant="secondary"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              modal.onCancel?.();
              onClose();
            }}
          >
            {modal.cancelText ?? modal.onConfirm ? '취소' : '닫기'}
          </Button>
        </>
      }
    />
  );
};
