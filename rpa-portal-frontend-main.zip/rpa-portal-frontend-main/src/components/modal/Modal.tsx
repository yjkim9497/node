// src/components/modal/Modal.tsx
import { FC, MouseEvent, ReactNode } from 'react';

export type ModalSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface ModalProps {
  visible: boolean;
  onClose: () => void;
  className?: string;
  size?: ModalSize;
  zIndex?: number;
  header?: ReactNode;
  body?: ReactNode;
  footer?: ReactNode;
  /** 배경 클릭으로 닫기 허용 여부 (기본값: true) */
  backdropClosable?: boolean;
}

const sizeClasses: Record<ModalSize, string> = {
  xs: 'max-w-xs',
  sm: 'max-w-lg',
  md: 'max-w-2xl',
  lg: 'max-w-4xl',
  xl: 'max-w-6xl',
};

const Modal: FC<ModalProps> = ({
  visible,
  className,
  zIndex = 50,
  onClose,
  size = 'xs',
  header,
  body,
  footer,
  backdropClosable = true,
}) => {
  if (!visible) return null;

  const widthClass = sizeClasses[size];

  const handleBackdropMouseDown = (e: MouseEvent<HTMLDivElement>) => {
    if (!backdropClosable) return;
    if (e.target !== e.currentTarget) return; // 배경 영역만 클릭했을 때
    onClose();
  };

  return (
    <div
      className={`fixed inset-0 flex justify-center items-center p-6 ${
        className ? className : 'bg-black bg-opacity-50'
      }`}
      style={{ zIndex }}
      onMouseDown={handleBackdropMouseDown}
    >
      <div
        className={`relative w-full bg-white rounded-2xl shadow-xl overflow-hidden ${widthClass} max-h-[90vh]`}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative px-6 py-4">
          <h3 className="text-xl font-bold text-center">{header}</h3>
          <button
            className="absolute top-3 right-3 text-gray-600 hover:text-gray-900"
            onClick={onClose}
            onMouseDown={(e) => e.preventDefault()}
            aria-label="close"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-2 overflow-y-auto">{body}</div>

        {/* Footer */}
        {footer && <div className="px-6 py-3 mb-2 flex justify-center gap-2">{footer}</div>}
      </div>
    </div>
  );
};

export default Modal;
