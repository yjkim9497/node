import TransLink from '@components/ui/TransLink';
import UserBar from '@components/layout/UserBar';
import React from 'react';

export default function NavMenu({ data, titles }) {
  return (
    <nav className="nav-menu flex justify-between">
      <ul className="menu">
        <li key={'dashboard'}>
          <TransLink to={'/dashboard'}>RPA Potal</TransLink>
        </li>
        {data
          .filter((e) => !e.meta)
          .map((menu) => (
            <li key={menu.title}>
              <TransLink to={menu.url} className={menu.title === titles[0] ? 'active' : ''}>
                {menu.title}
              </TransLink>
              {!menu.hide && menu.children?.find((e) => !e.meta) && (
                <ul className="submenu">
                  {menu.children
                    .filter((e) => !e.meta)
                    .map((sub) => (
                      <li key={sub.title}>
                        <TransLink to={sub.url} className={sub.title === titles[1] ? 'active' : ''}>
                          {sub.title}
                        </TransLink>
                      </li>
                    ))}
                </ul>
              )}
            </li>
          ))}
      </ul>
      <UserBar />
    </nav>
  );
}
