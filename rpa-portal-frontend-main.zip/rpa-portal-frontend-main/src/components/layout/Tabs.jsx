// src/components/layout/Tabs.jsx
import { navigate } from '@routes/NavigationProvider';

export default function Tabs({ items, title }) {
  if (items.length < 1) return null;

  return (
    <div className="relative mb-2">
      <div className="flex items-end gap-2 h-10">
        {items.map((tab) => {
          const isActive = tab.title === title;
          return (
            <button
              key={tab.title}
              onClick={() => {
                if (tab.action) tab.action(tab); // props 기반
                else if (tab.url) navigate(tab.url);
              }}
              className={`px-4 font-medium rounded-t-lg border transition-all duration-150
                ${isActive ? 'bg-white text-gray-800 border-b-white shadow h-10' : 'bg-gray-200 text-gray-600 h-7'}`}
            >
              {tab.title}
            </button>
          );
        })}
      </div>
      <div className="absolute bottom-0 left-0 w-full border-b border-gray-400"></div>
    </div>
  );
}
