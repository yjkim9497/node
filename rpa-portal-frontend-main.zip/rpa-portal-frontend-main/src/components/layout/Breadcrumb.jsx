import React from 'react';
import { useLocation } from 'react-router-dom';

export default function Breadcrumb({ titles = [], sep = ' > ' }) {
  return (
    titles?.length > 0 && (
      <h1 className="text-2xl mb-2 font-bold">
        {titles.map((node, i) => (
          <span key={i}>
            {i > 0 && <span className="mx-2 text-gray-400">{sep}</span>}
            <span className="text-gray-600">{node}</span>
          </span>
        ))}
      </h1>
    )
  );
}
