import DotDotDot from '@components/common/DotDotDot';
import MyInfo from '@features/popup/MyInfo';
import ROUTES from '@routes/routes.generated';
import { useAuthStore } from '@store/authStore';
import { useModalStore } from '@store/useModalStore';
import { useState } from 'react';
import { navigate } from '@routes/NavigationProvider';
import { createPortal } from 'react-dom';

export default function UserBar() {
  const { username, dptname = '부서명', setAuth } = useAuthStore.getState() || {};
  const [modalOpen, setModalOpen] = useState(false);
  const modal = useModalStore();

  const changePass = () => {
    navigate(ROUTES.PASSWORD.url);
  };

  const onLogout = () => {
    const content = '로그아웃 하시겠습니까?';
    const onConfirm = () => {
      setAuth();
    };
    modal.open({ content, onConfirm });
  };

  //if (!username) return null;

  const list = [
    {
      content: '내 정보 확인',
      onClick: () => {
        setModalOpen(true);
      },
    },
    { content: '비밀번호 변경', onClick: changePass },
    { content: '로그아웃', onClick: onLogout },
  ];
  return (
    <div className="flex items-center space-x-2 p-2 mr-12">
      {/* 프로필 아이콘 */}
      <div className="w-6 h-6 rounded-full bg-blue-200 flex items-center justify-center">
        <span className="text-sm text-blue-700 font-semibold">👤</span>
      </div>

      {/* 이름과 부서 */}
      <span className="text-sm font-medium text-white">{username}님</span>
      <span className="text-white">|</span>
      <span className="text-sm text-white">{dptname}</span>

      {/* 점 세 개 아이콘 */}
      <DotDotDot list={list} dotColor="white" />
      {modalOpen && <MyInfo {...{ setModalOpen }} />}
    </div>
  );
}
