import React, { Component, ReactNode } from 'react';
import { useModalStore } from '@store/useModalStore';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundaryClass extends Component<Props, State> {
  state: State = { hasError: false };

  componentDidMount() {
    // 전역 동기 에러
    window.onerror = (msg, src, lineno, colno, err) => {
      console.log('Sync Error');
      const content = msg?.toString()?.replace('Uncaught Error: ', '');
      useModalStore.getState().open({ type: 'error', content: content || '기타 동기 오류' });
      return false; // 기본 브라우저 동작 유지 여부
    };

    // 전역 비동기 에러
    window.onunhandledrejection = (event) => {
      event.preventDefault();
      console.log('Async Error');
      const { status, statusText, data } = event.reason?.response?.data || {};
      const message = status
        ? `${status}\n${data?.details ?? statusText}`
        : event.reason?.message ?? '기타 비동기 오류';
      useModalStore.getState().open({ type: 'error', content: message });
    };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.log('Component Error');
    useModalStore.getState().open({ type: 'error', content: `${error.message} | ${errorInfo.componentStack}` });
  }

  render() {
    return this.props.children;
  }
}

export const ErrorBoundary: React.FC<{ children: ReactNode }> = ({ children }) => (
  <ErrorBoundaryClass>{children}</ErrorBoundaryClass>
);
