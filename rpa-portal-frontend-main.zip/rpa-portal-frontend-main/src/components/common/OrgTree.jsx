import React, { useState, useEffect, useMemo } from 'react';
import { Tree } from 'react-arborist';
import './OrgTree.css';

//
// ------ MOCK DATA (unchanged) ------
const orgTree = [
  {
    id: 'dept-1',
    name: '개발본부',
    type: 'department',
    children: [
      {
        id: 'dept-1-1',
        name: '프론트엔드팀',
        type: 'department',
        children: [
          { id: 'u-1', name: '김프론트', email: 'front@corp.com', type: 'user', departmentId: 'dept-1-1' },
          { id: 'u-2', name: '이프론트', email: 'lee@corp.com', type: 'user', departmentId: 'dept-1-1' },
        ],
      },
      {
        id: 'dept-1-2',
        name: '백엔드팀',
        type: 'department',
        children: [{ id: 'u-3', name: '박백엔드', email: 'back@corp.com', type: 'user', departmentId: 'dept-1-2' }],
      },
    ],
  },
  {
    id: 'dept-2',
    name: '인사팀',
    type: 'department',
    children: [{ id: 'u-4', name: '최인사', email: 'hr@corp.com', type: 'user', departmentId: 'dept-2' }],
  },
];

const flattenUsers = (tree, result = []) => {
  tree.forEach((node) => {
    if (node.type === 'user') result.push(node);
    if (node.children) flattenUsers(node.children, result);
  });
  return result;
};
const allUsers = flattenUsers(orgTree);

// filter: 부서만 남긴 트리 (user 노드 제거)
const filterDepartmentsOnly = (nodes) =>
  nodes
    .map((n) => {
      if (n.type === 'user') return null;
      return {
        ...n,
        children: n.children ? filterDepartmentsOnly(n.children) : [],
      };
    })
    .filter(Boolean);

export default function OrgTree() {
  const [mode, setMode] = useState('NORMAL'); // "NORMAL" | "DEPT"
  const [selectedUsers, setSelectedUsers] = useState([]); // user objects
  const [selectedDepartments, setSelectedDepartments] = useState([]); // array of department ids
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [search, setSearch] = useState('');

  // tree data - DEPT 모드이면 사용자 노드 제거
  const treeData = useMemo(() => (mode === 'DEPT' ? filterDepartmentsOnly(orgTree) : orgTree), [mode]);

  // 안전한 선택 처리 (행 전체 클릭)
  const handleRowClick = (node) => {
    if (!node || !node.data) return;
    const item = node.data;

    // -- 폴더 토글: 자식이 있는 경우에만 토글 허용
    const hasChildren = Array.isArray(node.children) && node.children.length > 0;
    if (item.type === 'department' && hasChildren) {
      node.toggle(); // 열기/닫기
    }

    // -- 선택 동작: 모드/타입에 따라 다르게 처리
    else if (mode === 'NORMAL') {
      if (item.type !== 'user') return; // NORMAL: 사용자만 선택 가능(요구에 따름)
      setSelectedUsers((prev) =>
        prev.some((u) => u.id === item.id) ? prev.filter((u) => u.id !== item.id) : [...prev, item]
      );
    } else {
      // DEPT 모드: 부서 id 단위로 토글
      if (item.type !== 'department') return;
      setSelectedDepartments((prev) =>
        prev.includes(item.id) ? prev.filter((id) => id !== item.id) : [...prev, item.id]
      );
    }
  };

  // DEPT 모드에서 선택된 부서의 사용자 집합 + 검색
  useEffect(() => {
    if (mode !== 'DEPT') {
      setFilteredUsers([]);
      return;
    }

    let users = allUsers.filter((u) => selectedDepartments.includes(u.departmentId));
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      users = users.filter(
        (u) => (u.name || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q)
      );
    }
    setFilteredUsers(users);
  }, [mode, selectedDepartments, search]);

  // 우측 테이블 렌더
  const renderTable = (data) => (
    <table className="result-table">
      <thead>
        <tr>
          <th style={thStyle}>이름</th>
          <th style={thStyle}>이메일</th>
          <th style={thStyle}>부서</th>
          <th style={thStyle}></th>
        </tr>
      </thead>
      <tbody>
        {data.map((r) => (
          <tr key={r.id}>
            <td style={tdStyle}>{r.name}</td>
            <td style={tdStyle}>{r.email || '-'}</td>
            <td style={tdStyle}>{r.departmentId || '-'}</td>
            <td style={{ ...tdStyle, textAlign: 'right' }}>
              <button
                className="remove-btn"
                onClick={() => {
                  if (mode === 'NORMAL') setSelectedUsers((prev) => prev.filter((p) => p.id !== r.id));
                  else setSelectedDepartments((prev) => prev.filter((id) => id !== r.departmentId));
                }}
              >
                ❌
              </button>
            </td>
          </tr>
        ))}
        {data.length === 0 && (
          <tr>
            <td colSpan={4} style={{ textAlign: 'center', color: '#888', padding: 12 }}>
              항목이 없습니다.
            </td>
          </tr>
        )}
      </tbody>
    </table>
  );

  // Node 렌더러: 안전하게 node.data 확인, 사용자 숨김(DEPT 모드 handled by treeData), arrow 표시 조건 엄격하게
  const NodeRenderer = ({ node, style }) => {
    const d = node?.data;
    if (!d) return null;

    const isFolder = d.type === 'department';
    const hasChildren = Array.isArray(node.children) && node.children.length > 0;
    const isSelected =
      mode === 'NORMAL'
        ? selectedUsers.some((u) => u.id === d.id)
        : hasChildren
        ? false
        : selectedDepartments.includes(d.id);

    return (
      <div
        className={`tree-row hover:bg-gray-300 ${isSelected ? 'bg-blue-100' : ''}`}
        style={style}
        onClick={() => handleRowClick(node)}
      >
        {/* 화살표: 자식이 있을 때만 표시 / 애니메이션은 class 'open'으로 처리 */}
        {isFolder ? (
          hasChildren ? (
            <span
              className={`arrow ${node.isOpen ? 'open' : ''}`}
              onClick={(e) => {
                e.stopPropagation();
                node.toggle();
              }}
            >
              ▶
            </span>
          ) : (
            <span className="arrow-placeholder" />
          )
        ) : (
          <span className="arrow-placeholder" />
        )}

        {/* 아이콘 */}
        <span className="node-icon">{isFolder ? (node.isOpen ? '📂' : '📁') : '👤'}</span>

        {/* 레이블 */}
        <span className="node-label">{d.name}</span>
      </div>
    );
  };

  return (
    <div style={{ display: 'flex', gap: 24 }}>
      {/* LEFT */}
      <div style={{ width: 320 }}>
        <div style={{ marginBottom: 12 }}>
          <label style={{ marginRight: 8 }}>
            <input type="radio" checked={mode === 'NORMAL'} onChange={() => setMode('NORMAL')} /> 일반 선택
          </label>
          <label>
            <input type="radio" checked={mode === 'DEPT'} onChange={() => setMode('DEPT')} /> 부서 조회
          </label>
        </div>

        <Tree data={treeData} idField="id" childrenField="children" width={300} height={420} indent={18} rowHeight={32}>
          {NodeRenderer}
        </Tree>
      </div>

      {/* RIGHT */}
      <div style={{ flex: 1 }}>
        {mode === 'DEPT' && (
          <input
            className="search-box"
            placeholder="이름/이메일 검색"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        )}

        {mode === 'NORMAL' ? renderTable(selectedUsers) : renderTable(filteredUsers)}
      </div>
    </div>
  );
}

const thStyle = {
  padding: '6px 12px',
  borderBottom: '1px solid #ccc',
  borderRight: '1px solid #ccc',
  textAlign: 'left',
};
const tdStyle = { padding: '6px 12px', borderBottom: '1px solid #eee', borderRight: '1px solid #eee' };
