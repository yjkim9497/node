import React, { ElementType, ReactNode } from 'react';
import clsx from 'clsx';

type LabeledFieldBase = {
  className?: string;
  props?: any;
  compClassName?: string;
};

type WithComponent<T extends ElementType> = LabeledFieldBase & {
  component: T;
  children?: never; // component 모드에서는 children 불가
};

type WithChildren = LabeledFieldBase & {
  component?: never; // children 모드에서는 component 불가
  children: ReactNode;
};

type LabeledFieldProps<T extends ElementType = ElementType> = WithComponent<T> | WithChildren;

/** ※함수형 컴포넌트로 사용하지 말 것.(랜더링 문제)
/* 🔹 LabeledField는 component 또는 children 중 하나만 사용
/* - component 모드: component와 props를 넘김
/* - children 모드: children을 직접 넘김
*/
export const LabeledField = <T extends ElementType = ElementType>({
  className,
  component: Component,
  props = {},
  compClassName,
  children,
}: LabeledFieldProps<T>) => {
  const defaultClass = 'font-semibold inline-block w-fit ml-auto';
  const mergedProps = {
    ...props,
    className: clsx(props?.className, compClassName),
  };

  return (
    <>
      <label htmlFor={props?.id} className={clsx(className, defaultClass)}>
        {`${props?.required ? '* ' : ''}${props?.label}`}
      </label>

      {Component ? <Component {...mergedProps} /> : children}
    </>
  );
};
