// src/components/common/FilterBar.tsx
import { FC, ReactNode } from 'react';

interface FilterBarProps {
  top?: ReactNode;
  bottom?: ReactNode;
  onReset: () => void;
  onSearch: () => void;
}

const FilterBar: FC<FilterBarProps> = ({ top, bottom, onReset, onSearch, ...rest }) => {
  return (
    <div className="p-4 mb-2 border rounded-lg bg-white">
      <div className="flex justify-between items-start gap-6" {...rest}>
        {/* 왼쪽 필터 그룹 */}
        <div className="flex-1">
          {top && <div>{top}</div>}
          {bottom && <div>{bottom}</div>}
        </div>
        {/* 오른쪽 버튼 그룹 */}
        <div className="flex flex-col gap-2">
          <button className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300" onClick={onReset}>
            초기화
          </button>
          <button className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600" onClick={onSearch}>
            조회
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilterBar;
