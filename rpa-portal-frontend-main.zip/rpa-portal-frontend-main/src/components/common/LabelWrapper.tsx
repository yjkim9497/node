import React from 'react';

interface LabelWrapperProps {
  children: React.ReactNode;
  className?: string;
}
/**
 * LabelWrapper
 * ⚠️ 주의:
 * - 부모 요소(th, td 등)는 반드시 `position: relative` 이어야 함
 *   (이 컴포넌트가 absolute + inset:0 으로 부모 전체를 덮기 때문)
 */
const LabelWrapper: React.FC<LabelWrapperProps> = ({ children, className }) => {
  return (
    <label
      className={className}
      style={{
        position: 'absolute',
        display: 'flex',
        inset: '0',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {children}
    </label>
  );
};

export default LabelWrapper;
