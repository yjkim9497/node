import Portal from '@components/modal/Potal';
import React, { useRef, useState } from 'react';
import { createPortal } from 'react-dom';

const DotDotDot = ({
  list = [],
  dotColor = 'black', // 점 색상
  menuBgColor = 'white', // 메뉴 배경색
  menuTextColor = 'black', // 메뉴 글자 색상
}) => {
  const [open, setOpen] = useState(false);
  const btnRef = useRef(null);
  const menuRef = useRef(null);
  const [pos, setPos] = useState({ top: 0, left: 0 });

  const toggleMenu = (e) => {
    e.stopPropagation();
    const maxLen = list?.reduce((a, c) => Math.max(a, c.content?.length), 0);
    const menuWidth = maxLen * 10 + 60;
    const menuHeight = list.length * 42; // row 높이 기반

    const clickX = e.clientX;
    const clickY = e.clientY;

    const screenW = window.innerWidth;
    const screenH = window.innerHeight;

    let left = clickX;
    let top = clickY;

    // ---- 화면 밖 벗어나면 자동 조정 ----
    if (clickX + menuWidth > screenW) {
      left = screenW - menuWidth - 10;
    }

    if (clickY + menuHeight > screenH) {
      top = screenH - menuHeight - 10;
    }

    setPos({ top, left });
    setOpen((v) => !v);
  };

  const handleOptionClick = (action) => {
    action?.();
    setOpen(false); // 메뉴 닫기
  };

  return (
    <div style={{ position: 'relative', display: 'inherit' }}>
      <button
        ref={btnRef}
        onClick={toggleMenu}
        style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}
      >
        <svg width="20" height="20" viewBox="0 0 20 20">
          <circle cx="10" cy="4" r="2" fill={dotColor} />
          <circle cx="10" cy="10" r="2" fill={dotColor} />
          <circle cx="10" cy="16" r="2" fill={dotColor} />
        </svg>
      </button>

      {open &&
        list.length > 0 &&
        createPortal(
          <>
            {/*  화면 전체 클릭 시 닫힘 */}
            <div
              onClick={(e) => {
                e.stopPropagation();
                setOpen(false);
              }}
              style={{
                position: 'fixed',
                top: 0,
                left: 0,
                width: '100vw',
                height: '100vh',
                zIndex: 99,
                background: 'transparent',
              }}
            />
            <div
              ref={menuRef}
              style={{
                position: 'absolute',
                top: pos.top,
                left: pos.left,
                background: menuBgColor,
                border: '1px solid #ccc',
                boxShadow: '0 2px 5px rgba(0,0,0,0.15)',
                borderRadius: '4px',
                marginTop: '4px',
                zIndex: 100,
                minWidth: '120px',
                width: 'max-content',
              }}
            >
              {list.map((item, idx) => (
                <div
                  key={idx}
                  className="hover:bg-gray-200 "
                  onClick={(e) => {
                    e.stopPropagation();
                    handleOptionClick(item.onClick);
                  }}
                  style={{
                    padding: '8px 12px',
                    cursor: 'pointer',
                    color: menuTextColor,
                  }}
                >
                  {item.content}
                </div>
              ))}
            </div>
          </>,
          document.body
        )}
    </div>
  );
};

export default DotDotDot;
