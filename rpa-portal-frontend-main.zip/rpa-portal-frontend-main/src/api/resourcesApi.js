import { delay } from '@utils/api';

// src/api/resourcesApi.js
export const getResources = async () => {
  delay();
  return [
    { id: 1, title: '제목 텍스트 예시 1', desc: '내용 텍스트 내용 텍스트 내용 텍스트 내용 텍스트' },
    { id: 2, title: '제목 텍스트 예시 2', desc: '내용 텍스트 내용 텍스트 내용 텍스트' },
    { id: 3, title: '제목 텍스트 예시 3', desc: '내용 텍스트 내용 텍스트' },
  ];
};
