// src/api/processApi.ts
import commonApi from '@api/commonApi';

export type Id = number | string;
export type Yn = 'Y' | 'N';

/**
 * 5.0 프로세스 관리 기본 타입
 * - 백엔드 필드명에 맞춰서 processId/processName 등은 프로젝트에 맞게 조정해 사용
 */
export interface ProcessItem {
  processId: Id;
  processName: string;
  description?: string;
  useYn?: Yn;
  [k: string]: any;
}

/** Base Path: /process (5.0 프로세스 관리) */
const PATH_PROCESS = ['/process'] as const;

/**
 * 공통 CRUD:
 *  - 5.0.1 목록 조회   — GET  /process/list
 *  - 5.0.2 단건 조회   — GET  /process/{processId}
 *  - 5.0.3 등록       — POST /process/add
 *  - 5.0.4 수정       — POST /process/modify/{processId}
 *  - 5.0.5 삭제       — POST /process/delete
 */
export const processApi = {
  /** 5.0.1 프로세스 목록 조회 */
  list: (params?: Record<string, any>) =>
    commonApi.list<ProcessItem[]>({
      paths: [...PATH_PROCESS],
      params,
    }),

  /** 5.0.2 프로세스 단건 조회 */
  detail: (processId: Id) =>
    commonApi.detail<ProcessItem>({
      paths: [...PATH_PROCESS],
      id: processId,
    }),

  /** 5.0.3 프로세스 등록 */
  add: (payload: Partial<ProcessItem> | FormData) =>
    commonApi.add<Id>({
      paths: [...PATH_PROCESS],
      params: payload as any,
    }),

  /** 5.0.4 프로세스 수정 */
  modify: (processId: Id, payload: Partial<ProcessItem>) =>
    commonApi.modify<boolean>({
      paths: [...PATH_PROCESS],
      params: { ...payload, id: processId },
    }),

  /** 5.0.5 프로세스 삭제 */
  remove: (processId: Id[]) =>
    commonApi.remove<boolean>({
      paths: [...PATH_PROCESS],
      ids: processId,
    }),
};

export default processApi;
