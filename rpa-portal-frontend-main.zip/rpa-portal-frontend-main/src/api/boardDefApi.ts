// src/api/community/boardDef.api.ts
import { http } from '@api/axios';

export type Yn = 'Y' | 'N';

export interface BoardDef {
  categoryType: string;
  categoryName: string;
  description?: string;
  useYn?: Yn;
  readRole?: string;
  writeRole?: string;
  attachEnabledYn?: Yn;
  maxAttachCount?: number;
  maxAttachSize?: number;
  orderNo?: number;
  [k: string]: any;
}

const BASE = '/community/boarddef' as const;

const P = {
  enabled: `${BASE}/enabled`,
  byType: (ct: string) => `${BASE}/${encodeURIComponent(ct)}`,
  add: `${BASE}/add`,
  modify: (ct: string) => `${BASE}/modify/${encodeURIComponent(ct)}`,
  delete: (ct: string) => `${BASE}/delete/${encodeURIComponent(ct)}`,
  enable: (ct: string) => `${BASE}/enable/${encodeURIComponent(ct)}`,
} as const;

const pickId = (body: any): number => {
  const id = body?.data?.id ?? body?.id ?? body;
  if (typeof id !== 'number') {
    throw new Error('[boardDef.add] id not found in response');
  }
  return id;
};

// 6.0.1 사용중 게시판 정의 목록 조회 — GET /enabled
export const listEnabled = async (): Promise<BoardDef[]> => {
  const { data } = await http.get<BoardDef[]>(P.enabled);
  return data;
};

// 6.0.2 게시판 정의 단건 조회 — GET /{categoryType}
export const detail = async (ct: string): Promise<BoardDef> => {
  const { data } = await http.get<BoardDef>(P.byType(ct));
  return data;
};

// 6.0.3 게시판 정의 생성 — POST /add
export const add = async (payload: Partial<BoardDef>): Promise<number> => {
  const { data } = await http.post(P.add, payload);
  return pickId(data);
};

// 6.0.4 게시판 정의 수정 — POST /modify/{categoryType}
export const modify = async (
  ct: string,
  payload: Partial<BoardDef>,
): Promise<BoardDef> => {
  const { data } = await http.post<BoardDef>(P.modify(ct), payload);
  return data;
};

// 6.0.5 게시판 정의 삭제 — POST /delete/{categoryType}
export const remove = async (ct: string): Promise<void> => {
  await http.post(P.delete(ct));
};

// 6.0.6 게시판 재활성화(선택 복구) — POST /enable/{categoryType}
export const enable = async (ct: string): Promise<void> => {
  await http.post(P.enable(ct));
};
