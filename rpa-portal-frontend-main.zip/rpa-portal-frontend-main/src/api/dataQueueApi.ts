// src/api/dataQueueApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

export type Id = number | string;
export type Yn = 'Y' | 'N';

export interface DataQueue {
  queueId: Id;
  queueName: string;
  description?: string;
  useYn?: Yn;
  // 기타 필드들 (생성일, 수정일 등) 필요 시 추가
  [k: string]: any;
}

export interface QueueMessage {
  messageId: Id;
  queueId: Id;
  payload?: string; // 또는 any (JSON)
  status?: string; // READY, DONE, ERROR 등
  createdAt?: string;
  updatedAt?: string;
  [k: string]: any;
}

/** 페이지 응답이 필요한 경우에 대비한 타입 */
export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages?: number;
  size?: number;
  number?: number;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
/** 9.0 데이터 큐 관리 - Base Path: /queue */
const PATHS_QUEUE = ['/queue'] as const;

const BASE_QUEUE = PATHS_QUEUE.slice(0, 2).join(''); // "/queue"

/** -------- 공통 유틸: 파일명 파싱 -------- */
function parseFilename(disposition?: string | null) {
  if (!disposition) return;
  const utf8 = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(disposition);
  if (utf8) return decodeURIComponent(utf8[1]);
  const ascii = /filename\s*=\s*"([^"]+)"/i.exec(disposition) || /filename\s*=\s*([^;]+)/i.exec(disposition);
  return ascii?.[1]?.trim();
}

/** -------- 9.0 데이터 큐 API -------- */
/**
 *  - 9.0.1 큐 목록 조회        → queue.list
 *  - 9.0.2 큐 상세 조회        → queue.detail
 *  - 9.0.3 큐 등록            → queue.add
 *  - 9.0.4 큐 수정            → queue.modify
 *  - 9.0.5 큐 삭제            → queue.remove
 *  - 9.0.6 큐 엑셀 다운로드    → queue.download
 */
export const dataQueueApi = {
  /** 9.0 큐 정의/관리 */
  queue: {
    /** 9.0.1 큐 목록 조회 — GET /queue/list (commonApi.list 래핑) */
    list: (params?: Record<string, any>) =>
      commonApi.list<DataQueue[]>({
        paths: PATHS_QUEUE as any,
        params,
      }),

    /** 9.0.2 큐 상세 조회 — GET /queue/{queueId} */
    detail: (queueId: Id) =>
      commonApi.detail<DataQueue>({
        paths: PATHS_QUEUE as any,
        id: queueId,
      }),

    /** 9.0.3 큐 등록 — POST /queue/add */
    add: (payload: Partial<DataQueue>) =>
      commonApi.add<Id>({
        paths: PATHS_QUEUE as any,
        params: payload as any,
      }),

    /** 9.0.4 큐 수정 — POST /queue/modify/{queueId} */
    modify: (queueId: Id, payload: Partial<DataQueue>) =>
      commonApi.modify<boolean>({
        paths: PATHS_QUEUE as any,
        params: { ...payload, id: queueId },
      }),

    /** 9.0.5 큐 삭제 — POST /queue/delete */
    remove: (queueId: Id[]) =>
      commonApi.remove<boolean>({
        paths: PATHS_QUEUE as any,
        ids: queueId,
      }),

    /** 9.0.6 큐 목록 엑셀 다운로드 — GET /queue/download (blob) */
    download: async (params?: Record<string, any>) => {
      const res = await http.get(`${BASE_QUEUE}/download`, {
        params,
        responseType: 'blob',
      });
      const filename = parseFilename(res.headers?.['content-disposition'] as string | undefined);
      return { blob: res.data as Blob, filename };
    },
  },
};

export default dataQueueApi;
