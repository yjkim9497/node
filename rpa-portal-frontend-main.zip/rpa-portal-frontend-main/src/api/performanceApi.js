// src/api/performanceApi.js
import { delay } from '@utils/api';
import axios from 'axios';

/**
 * Mock-able API layer.
 * 실제로는 axios.get/post 로 백엔드 엔드포인트를 호출하도록 바꾸면 됩니다.
 *
 * 함수 시그니처는 모두 ({ date, workName, period, range }) 를 받도록 통일해서
 * 호출부가 파라미터 확장에 유연하게 대응할 수 있게 했습니다.
 */

// 기본 baseURL은 환경변수 또는 빈값(동일 origin)
axios.defaults.baseURL = import.meta.env.VITE_SERVER_API || '';

// 유틸: 느린 네트워크 흉내

// 간단한 PRNG (deterministic-ish) — date/workName으로 결과 재현 가능
function makeRand(seedStr = '') {
  let seed = 0;
  for (let i = 0; i < seedStr.length; i++) seed = (seed * 31 + seedStr.charCodeAt(i)) | 0;
  return () => {
    seed = (seed * 16807) % 2147483647;
    return (seed & 0x7fffffff) / 2147483647;
  };
}

// 유틸: 날짜 문자열 'YYYY-MM-DD' -> Date
function parseDate(s) {
  if (!s) return null;
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
}

// 유틸: 날짜 difference in days inclusive
function daysBetween(start, end) {
  const s = parseDate(start);
  const e = parseDate(end);
  if (!s || !e) return 0;
  const msPerDay = 24 * 60 * 60 * 1000;
  return Math.round((e - s) / msPerDay) + 1;
}

// 유틸: generate a sequence of timestamps (hours or dates) of length n
function makeTimeLabels({ mode = 'hour', date = null, count = 24 }) {
  if (mode === 'hour') {
    return Array.from({ length: count }, (_, i) => {
      const hh = i.toString().padStart(2, '0');
      return `${hh}:00`;
    });
  } else if (mode === 'day') {
    // if date provided as start and count days
    const start = date ? parseDate(date) : new Date();
    return Array.from({ length: count }, (_, i) => {
      const d = new Date(start.getTime() + i * 24 * 3600 * 1000);
      const mm = (d.getMonth() + 1).toString().padStart(2, '0');
      const dd = d.getDate().toString().padStart(2, '0');
      return `${d.getFullYear()}-${mm}-${dd}`;
    });
  }
  return [];
}

// mock: generate an array of objects [{ time, count }]
function genSeries({ length = 24, seed = 'x', base = 20, variance = 15, labelMode = 'hour', startDate = null }) {
  const rand = makeRand(seed);
  const labels = makeTimeLabels({ mode: labelMode === 'hour' ? 'hour' : 'day', date: startDate, count: length });
  return labels.map((t, i) => ({
    time: t,
    count: Math.max(0, Math.round(base + variance * (rand() - 0.5) * 1.5 + (i % 5) - 2)),
  }));
}

/**
 * fetchExecutionData
 * returns: { today: [{time,count}...], yesterday: [{time,count}...] }
 * - if period === '당일' -> hour series (24)
 * - else -> day series length = number of days in range (or default window)
 */
export async function fetchExecutionData({ date, workName, period = '당일', range = {} } = {}) {
  await delay(120);

  if (period === '당일') {
    const seedToday = `exec-${workName}-${date}-today`;
    const seedYester = `exec-${workName}-${date}-yesterday`;
    const today = genSeries({ length: 24, seed: seedToday, base: 20, variance: 15, labelMode: 'hour' });
    const yesterday = genSeries({ length: 24, seed: seedYester, base: 18, variance: 12, labelMode: 'hour' });
    return { today, yesterday };
  } else {
    // 주간/월간/기간지정 => return daily series; decide start/end
    let count = 7;
    if (period === '월간') count = 30;
    if (range && range.start && range.end) {
      count = Math.max(1, daysBetween(range.start, range.end));
    }
    const seedToday = `exec-${workName}-${date}-days-${count}`;
    const seedYester = `exec-${workName}-${date}-days-${count}-y`;
    const today = genSeries({
      length: count,
      seed: seedToday,
      base: 200,
      variance: 50,
      labelMode: 'day',
      startDate: range.start || date,
    });
    const yesterday = genSeries({
      length: count,
      seed: seedYester,
      base: 180,
      variance: 45,
      labelMode: 'day',
      startDate: range.start || date,
    });
    return { today, yesterday };
  }
}

/**
 * fetchResultData
 * returns: { success: [{time,count}...], fail: [{time,count}...] }
 * similar rules for period/range as above
 */
export async function fetchResultData({ date, workName, period = '당일', range = {} } = {}) {
  await delay(110);
  if (period === '당일') {
    const seedS = `res-${workName}-${date}-s`;
    const seedF = `res-${workName}-${date}-f`;
    const success = genSeries({ length: 24, seed: seedS, base: 15, variance: 12, labelMode: 'hour' });
    const fail = genSeries({ length: 24, seed: seedF, base: 2, variance: 4, labelMode: 'hour' });
    return { success, fail };
  } else {
    let count = 7;
    if (period === '월간') count = 30;
    if (range && range.start && range.end) count = Math.max(1, daysBetween(range.start, range.end));
    const success = genSeries({
      length: count,
      seed: `res-${workName}-${date}-s-${count}`,
      base: 200,
      variance: 60,
      labelMode: 'day',
      startDate: range.start || date,
    });
    const fail = genSeries({
      length: count,
      seed: `res-${workName}-${date}-f-${count}`,
      base: 5,
      variance: 15,
      labelMode: 'day',
      startDate: range.start || date,
    });
    return { success, fail };
  }
}

/**
 * fetchErrorSummary
 * returns: {
 *   totalRuns: number,
 *   normalCount: number,
 *   errors: [{ label, count, color }]
 * }
 *
 * Note: colors are provided here (server should send colors if desired)
 */
export async function fetchErrorSummary({ date, workName, period = '당일', range = {} } = {}) {
  await delay(180);
  // create mock counts:
  // totalRuns = normal + sum(errors)
  // we simulate normal being larger
  const rand = makeRand(`${date}-${workName}-err`);
  const normalCount = Math.round(1000 + rand() * 2000);
  // errors sample
  const possible = [
    { label: '패키지 실행 실패', color: '#9b59b6' },
    { label: '파일 누락', color: '#2ecc71' },
    { label: '네트워크 오류', color: '#f1c40f' },
    { label: '메모리 부족', color: '#f87171' },
    { label: '기타 오류', color: '#e67e22' },
  ];
  // pick 2-4 error types randomly
  const countErrTypes = 2 + Math.floor(rand() * 3);
  const errors = [];
  let sumErr = 0;
  for (let i = 0; i < countErrTypes; i++) {
    const p = possible[i % possible.length];
    const c = Math.max(0, Math.round(rand() * 80));
    errors.push({ label: p.label, count: c, color: p.color });
    sumErr += c;
  }
  // total runs = normal + sumErr
  const totalRuns = normalCount + sumErr;
  return { totalRuns, normalCount, errors };
}

/**
 * fetchSummaryKpi
 * returns KPI values used by SummaryCards
 */
export async function fetchSummaryKpi({ date, workName, period = '당일', range = {} } = {}) {
  await delay(170);
  const rand = makeRand(`${date}-${workName}-kpi`);
  const totalExec = Math.round(50000 + rand() * 100000);
  const normal = Math.round(totalExec * (0.7 + rand() * 0.25));
  const totalHours = Math.round(2000 + rand() * 8000);
  const saved = Math.round(totalHours * (0.4 + rand() * 0.4));
  return { totalExec, normal, totalHours, saved };
}
