// src/api/performance/performanceApi.ts
import { http } from '@api/axios';

/** ------- 공통 타입 ------- */
export type Filters = Record<string, any>[] | Record<string, any>;
export type DataRows<T = any> =
  | T[]
  | { content: T[]; totalElements?: number; [k: string]: any };

/** (선택) 차트/요약 등에서 재사용할 수 있는 타입들 */
export interface TimePoint { time: string; count: number }
export interface ExecutionData { today: TimePoint[]; yesterday: TimePoint[] }
export interface ResultData { success: TimePoint[]; fail: TimePoint[] }
export interface ErrorSummary {
  totalRuns: number;
  normalCount: number;
  errors: { label: string; count: number; color?: string }[];
}
export interface SummaryKpi {
  totalExec: number;
  normal: number;
  totalHours: number;
  saved: number;
}

/** ------- 내부 유틸 ------- */
const BASE = (paths: readonly string[]) => paths.slice(0, 2).join('');

function parseFilename(disposition?: string | null) {
  if (!disposition) return;
  const utf8 = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(disposition);
  if (utf8) return decodeURIComponent(utf8[1]);
  const ascii =
    /filename\s*=\s*"([^"]+)"/i.exec(disposition) ||
    /filename\s*=\s*([^;]+)/i.exec(disposition);
  return ascii?.[1]?.trim();
}

/** 섹션 팩토리: /filters, /data, /download 공통 구현 */
function makeSection<T = any>(paths: readonly string[]) {
  const base = BASE(paths);
  return {
    /** 섹션 base URL(필요 시 직접 접근) */
    url: (suffix = '') => (suffix ? `${base}/${suffix}` : base),

    /** 5.x.0 필터목록 — GET /filters */
    filters: <R = Filters>(params?: Record<string, any>) =>
      http.get<R>(`${base}/filters`, { params }).then(r => r.data),

    /** 5.x.1 데이터 조회 — GET /data */
    data: <R = DataRows<T>>(params?: Record<string, any>) =>
      http.get<R>(`${base}/data`, { params }).then(r => r.data),

    /** 5.x.2 엑셀 다운로드 — GET /download (blob) */
    download: async (params?: Record<string, any>) => {
      const res = await http.get(`${base}/download`, {
        params,
        responseType: 'blob',
      });
      const filename = parseFilename(res.headers?.['content-disposition'] as string | undefined);
      return { blob: res.data as Blob, filename };
    },
  };
}

/** ------- Paths ------- */
const PATH_MY    = ['/performance', '/my-work'] as const;
const PATH_DEPT  = ['/performance', '/department'] as const;
const PATH_UNIT  = ['/performance', '/unit-work'] as const;
const PATH_ROBOT = ['/performance', '/robot'] as const;

/** ------- Export API ------- */
export const performanceApi = {
  /** 5.1 내업무 */
  myWork: makeSection(PATH_MY),

  /** 5.2 부서별 */
  department: makeSection(PATH_DEPT),

  /** 5.3 단위업무별 */
  unitWork: makeSection(PATH_UNIT),

  /** 5.4 로봇별 */
  robot: makeSection(PATH_ROBOT),
};

/*
— 사용 예시 —

1) 실행 현황(시계열) 조회:
const exec = await performanceApi.myWork.data<ExecutionData>({
  date: '2025-10-24',
  period: '당일',           // 또는 '주간' | '월간' | '기간'
  workName: '배치A',
  // 서버 규약에 맞는 추가 파라미터들(view, range.start/end 등)
});

2) 결과(성공/실패) 조회:
const result = await performanceApi.department.data<ResultData>({ ...params });

3) 오류 요약:
const err = await performanceApi.unitWork.data<ErrorSummary>({ ...params });

4) KPI 요약:
const kpi = await performanceApi.robot.data<SummaryKpi>({ ...params });

5) 필터 목록:
const filters = await performanceApi.myWork.filters();

6) 엑셀 다운로드:
const { blob, filename } = await performanceApi.department.download({ ...params });
// 파일 저장은 호출부에서 처리
*/
