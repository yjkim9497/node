// src/api/commonApi.ts
import { http } from '@api/axios';

// ---------- 타입 정의 ----------
type HttpMethod = 'get' | 'post' | 'put' | 'delete';

interface ExecParams {
  method: HttpMethod;
  paths: string[];
  suffix?: string;
  params?: Record<string, any>;
  id?: number | string;
}

interface CommonApiParams {
  paths: string[];
  params?: Record<string, any>;
  id?: number | string;
  ids?: (number | string)[];
}

// ---------- 경로 조합 유틸 ----------
function buildPath(paths: string[], depth = Math.max(1, (paths?.length ?? 0) - 1)): string {
  if (!Array.isArray(paths) || paths.length === 0) throw new Error('[commonApi] paths must be a non-empty array.');
  return paths.slice(0, depth).join('');
}

// ---------- 요청 params 유틸 ----------
function idsParams({
  ids,
  paths,
  data,
}: { ids?: (number | string)[]; paths?: string[]; data?: Record<string, any> } = {}) {
  if (ids && !Array.isArray(ids)) throw new Error('[commonApi] ids must be an array.');
  const [, categoryType] = paths || [];
  return {
    ...(ids ? { ids: ids.map(Number) } : {}),
    ...(categoryType ? { categoryType } : {}),
    ...(data ? data : {}),
  };
}

// ---------- id check ----------
function checkId(id?: number | string): asserts id is number | string {
  if (!id) throw new Error('[commonApi] id is required');
}

// ---------- paths 검증 ----------
function validatePaths(paths?: string[]): asserts paths is string[] {
  if (!paths || paths.length === 0) throw new Error('[commonApi] paths is required.');
}

// ---------- 공통 실행기 ----------
async function exec<T = any>({ method, paths, suffix = '', params }: ExecParams): Promise<T> {
  validatePaths(paths);
  const base = buildPath(paths);
  const url = `${base}/${suffix}`;

  switch (method) {
    case 'get':
      return (await http.get<T>(url, { params })).data;
    case 'post':
      return (await http.post<T>(url, params)).data;
    case 'put':
      return (await http.put<T>(url, params)).data;
    case 'delete':
      return (await http.delete<T>(url, params ? { data: params } : undefined)).data;
    default:
      throw new Error(`[commonApi] unsupported method: ${method}`);
  }
}

// TODO get /list get /{id} post /add post /modify/{id} post /delete
// ---------- 공통 API ----------
export const filter = async <T = any>({ paths, params }: CommonApiParams) => {
  const suffix = params?.suffix ?? 'filter';
  return exec<T>({ method: 'get', paths, suffix, params });
};

export const list = async <T = any>({ paths, params }: CommonApiParams) => {
  const suffix = params?.suffix ?? 'list';
  return exec<T>({ method: 'get', paths, suffix, params });
};

export const detail = async <T = any>({ paths, id }: CommonApiParams) => {
  checkId(id);
  return exec<T>({ method: 'get', paths, suffix: `${id}` });
};

export const add = async <T = any>({ paths, params }: CommonApiParams) => {
  const suffix = params?.suffix ?? 'add';
  return exec<T>({ method: 'post', paths, suffix, params });
};

export const modify = async <T = any>({ paths, params }: CommonApiParams) => {
  checkId(params?.id);
  const suffix = params?.suffix ?? `modify/${params.id}`;
  return exec<T>({ method: 'post', paths, suffix, params });
};

export const remove = async <T = any>({ paths, ids }: CommonApiParams) => {
  const params = idsParams({ ids, paths });
  return exec<T>({ method: 'post', paths, suffix: 'delete', params });
};

export const publicAll = async <T = any>({ paths, ids }: CommonApiParams) => {
  const params = idsParams({ ids, paths });
  return exec<T>({ method: 'post', paths, suffix: 'bulknormal', params });
};

export const privateAll = async <T = any>({ paths, ids }: CommonApiParams) => {
  const params = idsParams({ ids, paths });
  return exec<T>({ method: 'post', paths, suffix: 'bulkprivate', params });
};

const commonApi = {
  filter,
  list,
  detail,
  add,
  modify,
  remove,
  publicAll,
  privateAll,
};

export default commonApi;
