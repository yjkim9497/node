// src/api/robotApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

export type Id = number | string;
export type RobotStatus = 'IDLE' | 'RUNNING' | 'ERROR' | 'OFFLINE';
export type UrgentLevel = 'HIGH' | 'MED' | 'LOW';
export interface Robot {
  id: number;
  robotName: string;
  status: RobotStatus;
  urgentLevel?: UrgentLevel;
  updatedAt?: string;
}

/** -------- Paths -------- */
const PATHS = ['/robot', '/admin'] as const;
const BASE = PATHS.slice(0, 2).join(''); // "/robot/admin"

// 파일명 파싱(다운로드용)
function parseFilename(disposition?: string | null) {
  if (!disposition) return;
  const utf8 = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(disposition);
  if (utf8) return decodeURIComponent(utf8[1]);
  const ascii = /filename\s*=\s*"([^"]+)"/i.exec(disposition) || /filename\s*=\s*([^;]+)/i.exec(disposition);
  return ascii?.[1]?.trim();
}

export const robotApi = {
  list: (params?: any) => commonApi.list<Robot[]>({ paths: PATHS as any, params }),
  detail: (id: Id) => commonApi.detail<Robot>({ paths: PATHS as any, id }),
  add: (payload: Partial<Robot>) => commonApi.add<number>({ paths: PATHS as any, params: payload }),
  modify: (id: Id, payload: Partial<Robot>) =>
    commonApi.modify<boolean>({ paths: PATHS as any, params: { ...payload, id } }),
  remove: (ids: Id[]) => commonApi.remove<boolean>({ paths: PATHS as any, ids }),
  publicAll: (ids: Array<Id>) => commonApi.publicAll<boolean>({ paths: PATHS as any, ids }),
  privateAll: (ids: Array<Id>) => commonApi.privateAll<boolean>({ paths: PATHS as any, ids }),

  control: (id: Id, payload: { action: string; params?: any }) =>
    http.post<boolean>(`${BASE}/control/${id}`, payload).then((r) => r.data),
  monitorStart: (id: Id) => http.post<boolean>(`${BASE}/monitor/start/${id}`, {}).then((r) => r.data),
  versionUpdate: (id: Id, payload: Record<string, any>) =>
    http.post<boolean>(`${BASE}/version/update/${id}`, payload).then((r) => r.data),

  profileExport: async (id: Id) => {
    const res = await http.post(`${BASE}/profile/export`, { responseType: 'blob' });
    const filename = parseFilename(res.headers?.['content-disposition'] as string | undefined);
    return { blob: res.data as Blob, filename };
  },
  profileImport: (id: Id, fileOrForm: File | Blob | FormData, field = 'file') => {
    const form =
      fileOrForm instanceof FormData
        ? fileOrForm
        : (() => {
            const f = new FormData();
            f.append(field, fileOrForm);
            return f;
          })();
    return http.post<boolean>(`${BASE}/profile/import`, form).then((r) => r.data);
  },
};
