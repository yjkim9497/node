// src/api/admin/systemEnvironmentApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- Types (필요 시 수정) -------- */
export interface SystemEnvironment {
  id: number;
  /** 환경 키 (예: SPRING_PROFILES_ACTIVE) */
  key: string;
  /** 값 (예: prod, http://api.example.com 등) */
  value: string;
  /** 그룹/섹션 (예: DB, APP, UI 등) */
  group?: string;
  /** 설명 */
  description?: string;
  /** 사용 여부 */
  useYn?: 'Y' | 'N';
  /** 메타 */
  createdAt?: string; // ISO
  updatedAt?: string; // ISO
  [k: string]: any;
}

/** -------- Paths/Base -------- */
const PATHS_ENV = ['/admin/settings', '/system/environment'] as const;

/** -------- API -------- */
export const systemEnvironmentApi = {
  /** 7.6.6.1 시스템 환경 목록 — GET /list */
  list: (params?: Record<string, any>) => commonApi.list<SystemEnvironment[]>({ paths: PATHS_ENV as any, params }),

  /** 7.6.6.2 시스템 환경 추가 — POST /add */
  add: (payload: Partial<SystemEnvironment>) => commonApi.add<number>({ paths: PATHS_ENV as any, params: payload }),

  /** 7.6.6.3 시스템 환경 수정 — POST /modify/{id} */
  modify: (id: number | string, payload: Partial<SystemEnvironment>) =>
    commonApi.modify<boolean>({ paths: PATHS_ENV as any, params: { ...payload, id } }),

  /** 7.6.6.4 시스템 환경 삭제 — POST /delete */
  remove: (ids: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS_ENV as any, ids }),
};
