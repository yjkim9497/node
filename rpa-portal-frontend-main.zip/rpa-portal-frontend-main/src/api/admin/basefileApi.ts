// src/api/admin/basefileApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- Types (필요 시 실제 스키마로 확장) -------- */
export type Id = number | string;
export type Yn = 'Y' | 'N';

export interface BaseFileAttribute {
  id: number;
  name: string;
  enabled?: boolean; // 사용여부
  description?: string;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
/** 12.1 /admin/basefile - 기초파일 관리 */
const PATHS_BASEFILE = ['/admin', '/basefile'] as const;

/** -------- API -------- */
export const basefileApi = {
  /** 12.1.1 기초파일 목록 - GET /admin/basefile/list */
  list: (params?: Record<string, any>) =>
    commonApi.list<BaseFileAttribute[]>({
      paths: PATHS_BASEFILE as any,
      params,
    }),

  /** 12.1.2 기초파일 등록 - POST /admin/basefile/add */
  add: (payload: Partial<BaseFileAttribute>) =>
    commonApi.add<number>({
      paths: PATHS_BASEFILE as any,
      // 기존 attributeApi 패턴 유지: suffix 로 add 명시
      params: { ...payload, suffix: 'add' },
    }),

  /** 12.1.3 기초파일 수정 - POST /admin/basefile/modify/{id} */
  modify: (id: Id, payload: Partial<BaseFileAttribute>) =>
    commonApi.modify<boolean>({
      paths: PATHS_BASEFILE as any,
      params: { ...payload, id },
    }),

  /** 12.1.4 기초파일 삭제 - POST /admin/basefile/delete */
  remove: (ids: Id[]) =>
    commonApi.remove<boolean>({
      paths: PATHS_BASEFILE as any,
      ids,
    }),

  /** 12.1.5 기초파일 사용여부 변경 - POST /admin/basefile/activation/{activationYn} */
  setUseYn: ({ activationYn, ids }: { activationYn: Yn; ids: Id[] }) =>
    http
      .post<boolean>(`/admin/basefile/activation/${activationYn}`, {
        ids,
      })
      .then((r) => r.data),
};

export default basefileApi;
