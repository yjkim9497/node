// src/api/admin/environmentApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** ---------- Types (필요 시 확장) ---------- */
export interface RobotEnvironment {
  id: number;
  robotId?: number | string;
  name?: string;
  os?: string;
  version?: string;
  network?: string;
  description?: string;
  updatedAt?: string;
  [k: string]: any;
}

export interface WorkEnvironment {
  id: number;
  workId?: number | string;
  name?: string;
  vars?: Record<string, any>;
  description?: string;
  updatedAt?: string;
  [k: string]: any;
}

/** ---------- Paths/Base ---------- */
const PATHS_ROBOT = ['/admin/robot', '/environment'] as const; // 7.3
const PATHS_WORK = ['/admin/work', '/environment'] as const; // 7.4

const BASE_WORK = PATHS_WORK.slice(0, 2).join(''); // "/admin/work/environment"

/** ---------- API ---------- */
export const environmentApi = {
  /** 7.3 로봇환경관리 */
  robot: {
    /** 7.3.1 리스트 — GET /list */
    list: (params?: Record<string, any>) => commonApi.list<RobotEnvironment[]>({ paths: PATHS_ROBOT as any, params }),

    /** 7.3.2 상세 — GET /{id} */
    detail: (id: number | string) => commonApi.detail<RobotEnvironment>({ paths: PATHS_ROBOT as any, id }),

    /** 7.3.3 수정 — POST /modify/{id} */
    modify: (id: number | string, payload: Partial<RobotEnvironment>) =>
      commonApi.modify<boolean>({ paths: PATHS_ROBOT as any, params: { ...payload, id } }),
  },

  /** 7.4 업무 환경 관리 */
  work: {
    /** 7.4.1 리스트 — GET /list */
    list: (params?: Record<string, any>) => commonApi.list<WorkEnvironment[]>({ paths: PATHS_WORK as any, params }),

    /** 7.4.2 상세 — GET /{id} */
    detail: (id: number | string) => commonApi.detail<WorkEnvironment>({ paths: PATHS_WORK as any, id }),

    /** 7.4.3 등록 — POST /add  (suffix를 body에 섞지 않기 위해 직접 POST) */
    add: (payload: Partial<WorkEnvironment>) => http.post<number>(`${BASE_WORK}/add`, payload).then((r) => r.data),

    /** 7.4.4 수정 — POST /{id} */
    modify: (id: number | string, payload: Partial<WorkEnvironment>) =>
      commonApi.modify<boolean>({ paths: PATHS_WORK as any, params: { ...payload, id } }),

    /** 7.4.5 삭제 — POST /delete */
    remove: (ids: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS_WORK as any, ids }),
  },
};
