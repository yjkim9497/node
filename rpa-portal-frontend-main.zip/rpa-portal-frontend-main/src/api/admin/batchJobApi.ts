// src/api/admin/batchJobApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- Types -------- */
export type Id = number | string;

export interface BatchJob {
  id: number;
  name: string;
  /** 크론 표현식 등 */
  schedule?: string;
  /** 활성화 여부 */
  useYn?: 'Y' | 'N';
  /** 마지막 실행 결과 */
  lastResult?: 'SUCCESS' | 'FAIL' | 'RUNNING' | 'QUEUED' | 'CANCELED';
  lastRunAt?: string; // ISO
  nextRunAt?: string; // ISO
  description?: string;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
const PATHS_JOB = ['/admin/settings', '/batch/job'] as const;
const BASE = PATHS_JOB.slice(0, 2).join(''); // "/admin/settings/batch/job"

/** -------- API -------- */
export const batchJobApi = {
  /** 7.6.7.1 배치작업 목록 — GET /list */
  list: (params?: Record<string, any>) =>
    commonApi.list<BatchJob[]>({ paths: PATHS_JOB as any, params }),

  /** 7.6.7.2 배치작업 실행 — POST /execute
   *  예시 payload:
   *    { id: 1 } 또는 { ids: [1,2,3] } 또는 { id: 1, params: {...} }
   *  반환 타입을 호출부에서 제네릭으로 지정 가능 (기본 boolean) */
  execute: <T = boolean>(payload: { id?: number | string; ids?: Array<number | string>; [k: string]: any }) =>
    http.post<T>(`${BASE}/execute`, payload).then(r => r.data),

  /** 7.6.7.3 배치작업 수정 — POST /modify/{id} */
  modify: (id: Id, payload: Partial<BatchJob>) =>
    commonApi.modify<boolean>({ paths: PATHS_JOB as any, params: { ...payload, id } }),
};
