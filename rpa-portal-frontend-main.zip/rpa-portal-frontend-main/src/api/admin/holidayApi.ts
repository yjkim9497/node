// src/api/admin/holidayApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- Types (예시. 필요시 수정) -------- */
export interface Holiday {
  holidayId: number;
  /** ISO date (e.g., 2025-01-01) */
  date: string;
  /** 휴일명 (e.g., 신정) */
  name: string;
  /** 지역 (전국/지자체 등) */
  region?: string;
  /** 근무일 여부(선택) */
  workingDay?: boolean;
  /** 사용여부(Y/N) 등 기타 필드 */
  [k: string]: any;
}

export interface HolidayFilterOption {
  label: string;
  value: string | number;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
const PATHS_HOL = ['/admin/settings', '/holiday'] as const;
const BASE = PATHS_HOL.slice(0, 2).join(''); // "/admin/settings/holiday"

/** 내부: Content-Disposition에서 파일명 추출 */
function getFilenameFromDisposition(disposition?: string): string | undefined {
  if (!disposition) return;
  // filename*=UTF-8''... 우선
  const utf8 = /filename\*=UTF-8''([^;]+)/i.exec(disposition);
  if (utf8?.[1]) return decodeURIComponent(utf8[1]);

  const ascii = /filename="?([^"]+)"?/i.exec(disposition);
  return ascii?.[1];
}

/** -------- API -------- */
export const holidayApi = {
  /** 7.6.4.0 필터 목록 — GET /filter */
  filters: (params?: Record<string, any>) =>
    http.get<HolidayFilterOption[]>(`${BASE}/filter`, { params }).then((r) => r.data),

  /** 7.6.4.1 휴일관리 목록 — GET /list */
  list: (params?: Record<string, any>) => commonApi.list<Holiday[]>({ paths: PATHS_HOL as any, params }),

  /** 7.6.4.7 휴일정보 추가 — POST /add */
  add: (payload: Partial<Holiday>) => commonApi.add<number>({ paths: PATHS_HOL as any, params: payload }),

  /** 7.6.4.6 휴일정보 수정 — POST /modify/{holidayId} */
  modify: (holidayId: number | string, payload: Partial<Holiday>) =>
    commonApi.modify<boolean>({ paths: PATHS_HOL as any, params: { ...payload, id: holidayId } }),

  /** 7.6.4.5 휴일정보 삭제 — POST /delete */
  remove: (holidayId: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS_HOL as any, ids: holidayId }),

  /**
   * @description
   * 7.6.4.2 휴일정보 내보내기 — GET /export (파일 다운로드)
   *  반환: { blob, filename } */
  exportFile: async (params?: Record<string, any>) => {
    const res = await http.get<Blob>(`${BASE}/export`, {
      params,
      responseType: 'blob',
    });
    const filename = getFilenameFromDisposition(res.headers['content-disposition'] as string) || 'holiday-export.xlsx';
    return { blob: res.data, filename };
  },

  /**
   * @description
   * 7.6.4.3 휴일정보 가져오기 — POST /import
   *  엑셀/CSV 파일 업로드(FormData) 기준 예시 */
  importFile: (file: File, extra?: Record<string, any>) => {
    const form = new FormData();
    form.append('file', file);
    if (extra) {
      Object.entries(extra).forEach(([k, v]) => {
        if (v !== undefined && v !== null) form.append(k, String(v));
      });
    }
    return http
      .post<boolean>(`${BASE}/import`, form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      .then((r) => r.data);
  },
};
