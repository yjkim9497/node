// src/api/admin/configurationApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- Types (필요 시 확장) -------- */
export interface Configuration {
  id: number;
  name: string;
  version?: string;
  status?: 'ACTIVE' | 'INACTIVE' | 'PENDING';
  updatedAt?: string;
  [k: string]: any;
}

export interface Deployment {
  id: number;
  configId: number;
  version?: string;
  result?: 'SUCCESS' | 'FAIL';
  deployedAt?: string; // ISO
  memo?: string;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
const PATHS_CONF = ['/admin/configuration'] as const;
const BASE = PATHS_CONF.slice(0, 2).join(''); // "/admin/configuration"

/** -------- API -------- */
export const configurationApi = {
  /**
   * @description
   * 7.2.1 형상 리스트 — GET /list */
  list: (params?: Record<string, any>) => commonApi.list<Configuration[]>({ paths: PATHS_CONF as any, params }),

  /**
   * @description
   * 7.2.2 형상 등록 — POST /add
   *  (suffix를 body에 섞지 않기 위해 직접 POST) */
  add: (payload: Partial<Configuration>) => http.post<number>(`${BASE}/add`, payload).then((r) => r.data),

  /**
   * @description
   * 7.2.3 형상 삭제 — POST /delete */
  remove: (ids: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS_CONF as any, ids }),

  /**
   * @description
   * 7.2.4 배포 이력 조회 — GET /deployments */
  deployments: (params?: Record<string, any>) =>
    http.get<Deployment[]>(`${BASE}/deployments`, { params }).then((r) => r.data),

  /**
   * @description
   * 7.2.5 일괄 배포 — POST /deploy
   *  예시 payload: { ids: number[] } 또는 { criteria: {...} }
   */
  deploy: (payload: { ids?: Array<number | string>; [k: string]: any }) =>
    http.post<boolean>(`${BASE}/deploy`, payload).then((r) => r.data),
};
