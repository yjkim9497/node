// src/api/admin/authorityApi.ts
// TODO 삭제예정
// authApi.ts 에 통합
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

export interface Authority {
  id: number;
  name: string;
  code: string;
  description?: string;
  activationYn: 'Y' | 'N';
  createdAt?: string;
  updatedAt?: string;
}

export type Id = number | string;

const PATHS = ['/admin/settings', '/authority'] as const;
const BASE = PATHS.slice(0, 2).join(''); // /admin/settings/authority

export const authorityApi = {
  list: (params?: any) => commonApi.list<Authority[]>({ paths: PATHS as any, params }),
  detail: (id: Id) => commonApi.detail<Authority>({ paths: PATHS as any, id }),
  add: (payload: Partial<Authority>) => commonApi.add<number>({ paths: PATHS as any, params: payload }),
  modify: (id: Id, payload: Partial<Authority>) =>
    commonApi.modify<boolean>({ paths: PATHS as any, params: { ...payload, id } }),
  remove: (ids: Id[]) => commonApi.remove<boolean>({ paths: PATHS as any, ids }),

  checkName: (payload: { name: string; code: string }) =>
    http.get<boolean>(`${BASE}/check/name`, { params: payload }).then((r) => r.data),
  checkActivation: (payload: { id: number; name: string; code: string }) =>
    http.get<boolean>(`${BASE}/check/activation/${payload.id}`, { params: payload }).then((r) => r.data),
  toggleActivation: (id: Id, activationYn: 'Y' | 'N') =>
    http.post<boolean>(`${BASE}/activation/${id}`, { activationYn }).then((r) => r.data),
};
