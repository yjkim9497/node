// src/api/admin/userApi.ts
// TODO 삭제예정
// authApi.ts 에 통합
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** ---------- Types (필요 시 확장) ---------- */

export type Id = number | string;

export interface Page<T> {
  content: T[];
  totalCount: number;
  totalPages?: number;
  pageRowCount?: number;
  number?: number;
}

export interface User {
  id: number;
  userId: string;
  name: string;
  email?: string;
  phone?: string;
  departmentId?: number | null;
  departmentName?: string;
  role?: string;
  activationYn: 'Y' | 'N';
  locked?: boolean;
  createdAt?: string;
  updatedAt?: string;
  [k: string]: any;
}

export interface DepartmentBrief {
  id: number;
  name: string;
}

/** ---------- Paths/Base ---------- */
const PATHS = ['/admin/settings', '/user'] as const;
const BASE = PATHS.slice(0, 2).join(''); // "/admin/settings/user"

/** ---------- API ---------- */
export const userApi = {
  /** 7.6.3.1 사용자 단건 조회 — GET /{userId}/ */
  detail: (userId: Id) => commonApi.detail<User>({ paths: PATHS as any, id: userId }),

  /** 7.6.3.2 로그인 사용자 조회 — GET /info */
  me: () => http.get<User>(`${BASE}/info`).then((r) => r.data),

  /** 7.6.3.3 사용자 목록 조회 — GET /list (공통) */
  list: (params?: Record<string, any>) => commonApi.list<Page<User> | User[]>({ paths: PATHS as any, params }),

  /** 7.6.3.4 사용자 목록 필터 조회 — GET /list/filter */
  filterList: (params?: Record<string, any>) =>
    http.get<Page<User> | User[]>(`${BASE}/list/filter`, { params }).then((r) => r.data),

  /** 7.6.3.5 사용자 정보 중복 체크 — GET /check
   *  예: ?userId=&email=&phone=&name= 등 서버 스펙에 맞춰 전달 */
  checkDuplicate: (params: { userId?: string; email?: string; phone?: string; name?: string }) =>
    http.get<boolean>(`${BASE}/check`, { params }).then((r) => r.data),

  /** 7.6.3.6 아이디 중복 체크 — GET /check/id?userId=... */
  checkUserId: (userId: string) => http.get<boolean>(`${BASE}/check/id`, { params: { userId } }).then((r) => r.data),

  /** 7.6.3.7 사용자 추가 — POST /add (공통) */
  add: (payload: Partial<User>) => commonApi.add<number>({ paths: PATHS as any, params: payload }),

  /** 7.6.3.8 사용자 수정 — POST /modify/{userId}/ */
  modify: (userId: Id, payload: Partial<User>) =>
    commonApi.modify<boolean>({ paths: PATHS as any, params: { ...payload, id: userId } }),

  /** 7.6.3.9 부서명 리스트 조회 — GET /department/list */
  departmentList: (params?: Record<string, any>) =>
    http.get<DepartmentBrief[]>(`${BASE}/department/list`, { params }).then((r) => r.data),

  /** 7.6.3.10 사용자 삭제 — POST /delete */
  remove: (userId: Id[]) => commonApi.remove<boolean>({ paths: PATHS as any, ids: userId }),

  /** 7.6.3.11 비밀번호 초기화 — POST /password/init/{userId} */
  initPassword: (userId: Id) => http.post<boolean>(`${BASE}/password/init/${userId}`, {}).then((r) => r.data),

  /** 7.6.3.12 사용자 IP 중복 체크 — GET /check/ip?ip=... */
  checkIpDuplicate: (ip: string) => http.get<boolean>(`${BASE}/check/ip`, { params: { ip } }).then((r) => r.data),

  /** 7.6.3.13 내 정보 수정 — POST /info */
  updateMyInfo: (payload: Partial<User>) => http.post<boolean>(`${BASE}/info`, payload).then((r) => r.data),

  /** 7.6.3.14 계정 잠금 해제 — POST /unlock/{userId} */
  unlock: (userId: Id) => http.post<boolean>(`${BASE}/unlock/${userId}`, {}).then((r) => r.data),

  /** 7.6.3.15 사용자 활성/비활성 — POST /{userId}/activation/{activationYn} */
  setActivation: (userId: Id, activationYn: 'Y' | 'N') =>
    http.post<boolean>(`${BASE}/activation/${userId}`, { activationYn }).then((r) => r.data),

  /** 7.6.3.16 작업 그룹 소속 변경 — POST /move/{userId}
   *  예시 payload: { groupId: number } 또는 { fromGroupId, toGroupId } 등 */
  moveGroup: (userId: Id, payload: Record<string, any>) =>
    http.post<boolean>(`${BASE}/move/${userId}`, payload).then((r) => r.data),
};
