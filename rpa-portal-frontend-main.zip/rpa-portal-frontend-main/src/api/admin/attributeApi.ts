// src/api/admin/attributeApi.ts
// TODO 삭제예정
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- Types (필요 시 실제 스키마로 확장) -------- */
export interface BaseFileAttribute {
  id: number;
  name: string;
  enabled?: boolean; // 사용여부
  description?: string;
  [k: string]: any;
}

export interface CommonVariable {
  id: number;
  key: string;
  value: string;
  locked?: boolean;
  use?: boolean;
  description?: string;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
const PATHS_BASEFILE = ['/admin', '/basefile'] as const;
const PATHS_VARIABLE = ['/admin', '/variable'] as const;

const BASE_BASEFILE = PATHS_BASEFILE.slice(0, 2).join(''); // "/admin/attribute/basefile"
const BASE_VARIABLE = PATHS_VARIABLE.slice(0, 2).join(''); // "/admin/attribute/variable"

/** -------- API -------- */
export const attributeApi = {
  /** 7.1.1 기초파일 속성 */
  basefile: {
    // 7.1.1.1 목록 - GET /list
    list: (params?: Record<string, any>) =>
      commonApi.list<BaseFileAttribute[]>({ paths: PATHS_BASEFILE as any, params }),

    // 7.1.1.2 등록 - POST /add
    add: (payload: Partial<BaseFileAttribute>) =>
      commonApi.add<number>({ paths: PATHS_BASEFILE as any, params: { ...payload, suffix: 'add' } }),

    // 7.1.1.3 수정 - POST /modify/{id}
    modify: (id: number | string, payload: Partial<BaseFileAttribute>) =>
      commonApi.modify<boolean>({ paths: PATHS_BASEFILE as any, params: { ...payload, id } }),

    // 7.1.1.4 삭제 - POST /delete
    remove: (ids: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS_BASEFILE as any, ids }),

    // 7.1.1.5 사용여부 변경 - POST /activation/{activationYn}
    setUseYn: ({ activationYn, ids }: { activationYn: 'Y' | 'N'; ids: (number | string)[] }) =>
      http.post<boolean>(`${BASE_BASEFILE}/activation/${activationYn}`, { ids }).then((r) => r.data),
  },

  /** 7.1.2 공용변수 속성 */
  variable: {
    // 7.1.2.1 목록 - GET /list
    list: (params?: Record<string, any>) => commonApi.list<CommonVariable[]>({ paths: PATHS_VARIABLE as any, params }),

    // 7.1.2.2 추가 - POST /add
    add: (payload: Partial<CommonVariable>) =>
      commonApi.add<number>({ paths: PATHS_VARIABLE as any, params: { ...payload, suffix: 'add' } }),

    // 7.1.2.3 수정 - POST /modify/{id}
    modify: (id: number | string, payload: Partial<CommonVariable>) =>
      commonApi.modify<boolean>({ paths: PATHS_VARIABLE as any, params: { ...payload, id } }),

    // 7.1.2.4 삭제 - POST /delete
    remove: (ids: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS_VARIABLE as any, ids }),

    // 7.1.2.5 잠금 해제 - POST /unlock/{id}
    unlock: (id: number | string) => http.post<boolean>(`${BASE_VARIABLE}/unlock/${id}`, {}).then((r) => r.data),

    // 7.1.2.6 사용여부 변경 - POST /activation/{activationYn} body: { ids: [...] }
    setUseYn: ({ activationYn, ids }: { activationYn: 'Y' | 'N'; ids: (number | string)[] }) =>
      http.post<boolean>(`${BASE_VARIABLE}/activation/${activationYn}`, { ids }).then((r) => r.data),

    // 7.1.2.7 사용 업무 목록 - GET /worklist
    worklist: (params?: Record<string, any>) =>
      http.get<any>(`${BASE_VARIABLE}/worklist`, { params }).then((r) => r.data),
  },
};
