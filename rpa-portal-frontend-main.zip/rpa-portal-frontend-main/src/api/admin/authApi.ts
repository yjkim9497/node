// src/api/admin/authApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- 공통 타입 -------- */
export type Id = number | string;
export type Yn = 'Y' | 'N';

/** ================= 12.4.1 권한 관리 (Authority) ================= */

export interface Authority {
  id: number;
  name: string;
  code: string;
  description?: string;
  activationYn: Yn;
  createdAt?: string;
  updatedAt?: string;
  [k: string]: any;
}

const PATHS_AUTHORITY = ['/admin/auth', '/authority'] as const;
const BASE_AUTHORITY = PATHS_AUTHORITY.slice(0, 2).join(''); // "/admin/auth/authority"

const authority = {
  /** 권한 목록 */
  list: (params?: Record<string, any>) => commonApi.list<Authority[]>({ paths: PATHS_AUTHORITY as any, params }),

  /** 권한 상세 */
  detail: (id: Id) => commonApi.detail<Authority>({ paths: PATHS_AUTHORITY as any, id }),

  /** 권한 등록 */
  add: (payload: Partial<Authority>) =>
    commonApi.add<number>({
      paths: PATHS_AUTHORITY as any,
      params: payload,
    }),

  /** 권한 수정 */
  modify: (id: Id, payload: Partial<Authority>) =>
    commonApi.modify<boolean>({
      paths: PATHS_AUTHORITY as any,
      params: { ...payload, id },
    }),

  /** 권한 삭제 */
  remove: (ids: Id[]) => commonApi.remove<boolean>({ paths: PATHS_AUTHORITY as any, ids }),

  /** 권한명/코드 중복 체크 */
  checkName: (payload: { name: string; code: string }) =>
    http
      .get<boolean>(`${BASE_AUTHORITY}/check/name`, {
        params: payload,
      })
      .then((r) => r.data),

  /** 활성화 가능 여부 체크 */
  checkActivation: (payload: { id: number; name: string; code: string }) =>
    http.get<boolean>(`${BASE_AUTHORITY}/check/activation/${payload.id}`, { params: payload }).then((r) => r.data),

  /** 활성/비활성 토글 */
  toggleActivation: (id: Id, activationYn: Yn) =>
    http
      .post<boolean>(`${BASE_AUTHORITY}/activation/${id}`, {
        activationYn,
      })
      .then((r) => r.data),
};

/** ================= 12.4.2 작업 그룹 관리 (Group) ================= */

export interface Group {
  id: number;
  name: string;
  code: string;
  description?: string;
  activationYn: Yn;
  parentId?: number | null;
  createdAt?: string;
  updatedAt?: string;
  [k: string]: any;
}

export interface UserBrief {
  id: number;
  userId: string;
  name: string;
  email?: string;
  groupId?: number | null;
  groupName?: string;
  role?: string;
  [k: string]: any;
}

const PATHS_GROUP = ['/admin/auth', '/group'] as const;
const BASE_GROUP = PATHS_GROUP.slice(0, 2).join(''); // "/admin/auth/group"

const group = {
  /** 작업 그룹 목록 */
  list: (params?: Record<string, any>) => commonApi.list<Group[]>({ paths: PATHS_GROUP as any, params }),

  /** 전체 작업 그룹 (트리/콤보용 등) */
  listAll: (params?: Record<string, any>) =>
    http.get<Group[]>(`${BASE_GROUP}/list/all`, { params }).then((r) => r.data),

  /** 그룹 상세 */
  detail: (groupId: Id) => commonApi.detail<Group>({ paths: PATHS_GROUP as any, id: groupId }),

  /** 그룹명 중복 체크 */
  checkNameDuplicate: (name: string, groupId?: Id) =>
    http
      .get<boolean>(`${BASE_GROUP}/check/name`, {
        params: { name, groupId },
      })
      .then((r) => r.data),

  /** 그룹 코드 중복 체크 */
  checkCodeDuplicate: (code: string, groupId?: Id) =>
    http
      .get<boolean>(`${BASE_GROUP}/check/code`, {
        params: { code, groupId },
      })
      .then((r) => r.data),

  /** 그룹 추가 */
  add: (payload: Partial<Group>) =>
    commonApi.add<number>({
      paths: PATHS_GROUP as any,
      params: payload,
    }),

  /** 그룹 수정 */
  modify: (groupId: Id, payload: Partial<Group>) =>
    commonApi.modify<boolean>({
      paths: PATHS_GROUP as any,
      params: { ...payload, id: groupId },
    }),

  /** 그룹 내 사용자 목록 */
  users: (groupId: Id, params?: Record<string, any>) =>
    http.get<UserBrief[]>(`${BASE_GROUP}/users/${groupId}`, { params }).then((r) => r.data),

  /** 전체 사용자 목록(그룹 포함) */
  usersAll: (params?: Record<string, any>) =>
    http.get<UserBrief[]>(`${BASE_GROUP}/users/all`, { params }).then((r) => r.data),

  /** 그룹 소속 이동 */
  move: (groupId: Id, payload: Record<string, any>) =>
    http.post<boolean>(`${BASE_GROUP}/move/${groupId}`, payload).then((r) => r.data),

  /** 그룹-유저 매핑 삭제 */
  unmapUser: (groupId: Id, userId: Id) =>
    http
      .post<boolean>(`${BASE_GROUP}/users/delete/${groupId}`, {
        userId,
      })
      .then((r) => r.data),

  /** 그룹 삭제 */
  remove: (groupId: Id[]) => commonApi.remove<boolean>({ paths: PATHS_GROUP as any, ids: groupId }),

  /** 특정 사용자 → 소속 그룹 조회 */
  userGroup: (userId: Id) => http.get<Group | null>(`${BASE_GROUP}/user/group/${userId}`).then((r) => r.data),

  /** 데이터 이동 대상 그룹 목록 */
  moveTargets: (params?: Record<string, any>) =>
    http.get<Group[]>(`${BASE_GROUP}/move/targets`, { params }).then((r) => r.data),

  /** 삭제 전 체크 */
  checkDelete: (groupId: Id) => http.get<boolean>(`${BASE_GROUP}/check/delete/${groupId}`).then((r) => r.data),

  /** 사용 여부 수정 */
  setActivation: (groupId: Id, activationYn: Yn) =>
    http
      .post<boolean>(`${BASE_GROUP}/activation/${groupId}`, {
        activationYn,
      })
      .then((r) => r.data),
};

/** ================= 12.4.3 부서 관리 (Departments) ================= */

export interface Department {
  id: Id;
  deptCode: string;
  deptName: string;
  parentId?: Id | null;
  level?: number;
  orderNo?: number;
  activationYn?: Yn;
  [k: string]: any;
}

const PATHS_DEPT = ['/admin/auth', '/departments'] as const;
const BASE_DEPT = PATHS_DEPT.slice(0, 2).join(''); // "/admin/auth/departments"

const departments = {
  /** 부서 목록 (페이징/검색) */
  list: (params?: Record<string, any>) =>
    commonApi.list<Department[]>({
      paths: PATHS_DEPT as any,
      params,
    }),

  /** 부서 트리 조회 — GET /tree */
  tree: (params?: Record<string, any>) => http.get<Department[]>(`${BASE_DEPT}/tree`, { params }).then((r) => r.data),

  /** 부서 상세 */
  detail: (id: Id) =>
    commonApi.detail<Department>({
      paths: PATHS_DEPT as any,
      id,
    }),

  /** 부서 등록 */
  add: (payload: Partial<Department>) =>
    commonApi.add<Id>({
      paths: PATHS_DEPT as any,
      params: payload,
    }),

  /** 부서 수정 */
  modify: (id: Id, payload: Partial<Department>) =>
    commonApi.modify<boolean>({
      paths: PATHS_DEPT as any,
      params: { ...payload, id },
    }),

  /** 부서 삭제 */
  remove: (ids: Id[]) =>
    commonApi.remove<boolean>({
      paths: PATHS_DEPT as any,
      ids,
    }),

  /** 부서 코드 중복 체크 — GET /check/code */
  checkCodeDuplicate: (deptCode: string, id?: Id) =>
    http
      .get<boolean>(`${BASE_DEPT}/check/code`, {
        params: { deptCode, id },
      })
      .then((r) => r.data),

  /** 사용 여부 변경 — POST /activation/{id} */
  setActivation: (id: Id, activationYn: Yn) =>
    http
      .post<boolean>(`${BASE_DEPT}/activation/${id}`, {
        activationYn,
      })
      .then((r) => r.data),
};

/** ================= 12.4.4 사용자 관리 (User) ================= */

export interface User {
  id: Id;
  userId: string;
  name: string;
  email?: string;
  deptId?: Id | null;
  deptName?: string;
  groupId?: Id | null;
  groupName?: string;
  authorities?: string[]; // 권한 코드 목록
  activationYn?: Yn;
  lockedYn?: Yn;
  createdAt?: string;
  updatedAt?: string;
  [k: string]: any;
}

const PATHS_USER = ['/admin/auth', '/user'] as const;
const BASE_USER = PATHS_USER.slice(0, 2).join(''); // "/admin/auth/user"

const user = {
  /** 사용자 목록 */
  list: (params?: Record<string, any>) =>
    commonApi.list<User[]>({
      paths: PATHS_USER as any,
      params,
    }),

  /** 사용자 상세 */
  detail: (id: Id) =>
    commonApi.detail<User>({
      paths: PATHS_USER as any,
      id,
    }),

  /** 사용자 등록 */
  add: (payload: Partial<User>) =>
    commonApi.add<Id>({
      paths: PATHS_USER as any,
      params: payload,
    }),

  /** 사용자 수정 */
  modify: (id: Id, payload: Partial<User>) =>
    commonApi.modify<boolean>({
      paths: PATHS_USER as any,
      params: { ...payload, id },
    }),

  /** 사용자 삭제 */
  remove: (ids: Id[]) =>
    commonApi.remove<boolean>({
      paths: PATHS_USER as any,
      ids,
    }),

  /** 사용자 ID 중복 체크 — GET /check/userId */
  checkUserIdDuplicate: (userId: string, id?: Id) =>
    http
      .get<boolean>(`${BASE_USER}/check/userId`, {
        params: { userId, id },
      })
      .then((r) => r.data),

  /** 계정 잠금/잠금 해제 — POST /lock/{id} */
  setLock: (id: Id, lockedYn: Yn) => http.post<boolean>(`${BASE_USER}/lock/${id}`, { lockedYn }).then((r) => r.data),

  /** 계정 사용 여부 변경 — POST /activation/{id} */
  setActivation: (id: Id, activationYn: Yn) =>
    http
      .post<boolean>(`${BASE_USER}/activation/${id}`, {
        activationYn,
      })
      .then((r) => r.data),

  /** 비밀번호 초기화 — POST /reset-password/{id} */
  resetPassword: (id: Id) => http.post<boolean>(`${BASE_USER}/reset-password/${id}`, {}).then((r) => r.data),

  /** 사용자별 권한 목록 조회 — GET /{id}/authorities */
  authorities: (id: Id) => http.get<string[]>(`${BASE_USER}/${id}/authorities`).then((r) => r.data),

  /** 사용자 권한 변경 — POST /{id}/authorities */
  setAuthorities: (id: Id, authorityCodes: string[]) =>
    http
      .post<boolean>(`${BASE_USER}/${id}/authorities`, {
        authorityCodes,
      })
      .then((r) => r.data),
};

/** ================= Export Aggregator ================= */

export const authApi = {
  authority,
  group,
  departments,
  user,
};

export default authApi;
