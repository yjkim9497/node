// src/api/admin/organizationApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- 공통 타입 -------- */
export type Id = number | string;
export type Yn = 'Y' | 'N';

/**
 * 12.5 조직도 노드(부서/조직 단위)
 * - 실제 인사시스템 스키마에 맞춰 필드는 확장하면 됨
 */
export interface OrganizationNode {
  id: Id; // 내부 PK or HR 시스템의 키
  deptCode: string; // 부서 코드
  deptName: string; // 부서명
  parentId?: Id | null; // 상위 부서 ID
  level?: number; // 트리 레벨(depth)
  orderNo?: number; // 정렬 순서
  activationYn?: Yn; // 사용 여부
  // 필요 시 조직장, 인원 수 등 추가 가능
  [k: string]: any;
}

export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages?: number;
  size?: number;
  number?: number;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
/** 12.5 /admin/organization - 조직도 관리 */
const PATHS_ORGANIZATION = ['/admin', '/organization'] as const;

/** -------- API -------- */
export const organizationApi = {
  /**
   * 12.5.1 조직도 목록 조회 — GET /admin/organization/list
   */
  list: <T = OrganizationNode>(params?: Record<string, any>) =>
    commonApi.list<T[]>({
      paths: PATHS_ORGANIZATION as any,
      params,
    }),

  /**
   * 12.5.2 조직(부서) 단건 조회 — GET /admin/organization/{id}
   */
  detail: <T = OrganizationNode>(id: Id) =>
    commonApi.detail<T>({
      paths: PATHS_ORGANIZATION as any,
      id,
    }),

  /*
   * === TODO 12.5.x 인사정보 동기화 API ===
   *
   * 향후 예시:
   *  - 전체 동기화: POST /admin/organization/sync/full
   *  - 변경분 동기화: POST /admin/organization/sync/incremental
   *
   * syncFull: () => http.post<boolean>(`${BASE_ORGANIZATION}/sync/full`, {}).then(r => r.data),
   * syncIncremental: (since: string) =>
   *   http.post<boolean>(`${BASE_ORGANIZATION}/sync/incremental`, { since }).then(r => r.data),
   */
};

export default organizationApi;
