// src/api/admin/groupApi.ts
// TODO 삭제예정
// authApi.ts 에 통합
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** ===== Types (필요 시 확장) ===== */
export interface Group {
  id: number;
  name: string;
  code: string;
  description?: string;
  activationYn: 'Y' | 'N';
  parentId?: number | null;
  createdAt?: string;
  updatedAt?: string;
  [k: string]: any;
}

export interface UserBrief {
  id: number;
  userId: string;
  name: string;
  email?: string;
  groupId?: number | null;
  groupName?: string;
  role?: string;
  [k: string]: any;
}

/** ===== Paths/Base ===== */
const PATHS = ['/admin/settings', '/group'] as const;
const BASE = PATHS.slice(0, 2).join(''); // "/admin/settings/group"

/** ===== API ===== */
export const groupApi = {
  /** 7.6.2.1 작업 그룹 목록 조회 — GET /list (공통) */
  list: (params?: Record<string, any>) => commonApi.list<Group[]>({ paths: PATHS as any, params }),

  /** 7.6.2.2 전체 작업 그룹 조회 — GET /list/all */
  listAll: (params?: Record<string, any>) => http.get<Group[]>(`${BASE}/list/all`, { params }).then((r) => r.data),

  /** 7.6.2.3 작업 그룹 단건 조회 — GET /{groupId}/ */
  detail: (groupId: number | string) => commonApi.detail<Group>({ paths: PATHS as any, id: groupId }),

  /** 7.6.2.4 작업 그룹명 중복 체크(수정) — GET /check/name?name=...&groupId?=... */
  checkNameDuplicate: (name: string, groupId?: number | string) =>
    http.get<boolean>(`${BASE}/check/name`, { params: { name, groupId } }).then((r) => r.data),

  /** 7.6.2.5 작업 그룹 코드 중복 체크 — GET /check/code?code=...&groupId?=... */
  checkCodeDuplicate: (code: string, groupId?: number | string) =>
    http.get<boolean>(`${BASE}/check/code`, { params: { code, groupId } }).then((r) => r.data),

  /** 7.6.2.6 작업 그룹 추가 — POST /add (공통) */
  add: (payload: Partial<Group>) => commonApi.add<number>({ paths: PATHS as any, params: payload }),

  /** 7.6.2.7 작업 그룹 수정 — POST /{groupId}/ (공통은 /{id}) */
  modify: (groupId: number | string, payload: Partial<Group>) =>
    commonApi.modify<boolean>({ paths: PATHS as any, params: { ...payload, id: groupId } }),

  /** 7.6.2.8 그룹 내 사용자 목록 조회 — GET /users/{groupId} */
  users: (groupId: number | string, params?: Record<string, any>) =>
    http.get<UserBrief[]>(`${BASE}/users/${groupId}`, { params }).then((r) => r.data),

  /** 7.6.2.9 전체 사용자 목록(그룹 포함) 조회 — GET /users/all */
  usersAll: (params?: Record<string, any>) =>
    http.get<UserBrief[]>(`${BASE}/users/all`, { params }).then((r) => r.data),

  /** 7.6.2.10 작업 그룹 소속 변경 — POST /move/{groupId}
   *  예시 payload: { userIds: number[] } 또는 { fromGroupId, toGroupId } 등 */
  move: (groupId: number | string, payload: Record<string, any>) =>
    http.post<boolean>(`${BASE}/move/${groupId}`, payload).then((r) => r.data),

  /** 7.6.2.11 그룹-유저 매핑 삭제 — POST /users/delete/{groupId}/ */
  unmapUser: (groupId: number | string, userId: number | string) =>
    http.post<boolean>(`${BASE}/users/delete/${groupId}`, { userId }).then((r) => r.data),

  /** 7.6.2.12 작업 그룹 삭제 — POST /{groupId}/ (공통) */
  remove: (groupId: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS as any, ids: groupId }),

  /** 7.6.2.13 사용자 그룹 조회 — GET /user/group/{userId} */
  userGroup: (userId: number | string) => http.get<Group | null>(`${BASE}/user/group/${userId}`).then((r) => r.data),

  /** 7.6.2.14 데이터 이동 대상 그룹 목록 조회 — GET /move/targets */
  moveTargets: (params?: Record<string, any>) =>
    http.get<Group[]>(`${BASE}/move/targets`, { params }).then((r) => r.data),

  /** 7.6.2.15 그룹 삭제 전 체크 — GET /check/delete/{groupId}/ */
  checkDelete: (groupId: number | string) => http.get<boolean>(`${BASE}/check/delete/${groupId}`).then((r) => r.data),

  /** 7.6.2.16 작업 그룹 사용 여부 수정 — POST /activation/{groupId}/ */
  setActivation: (groupId: number | string, activationYn: 'Y' | 'N') =>
    http.post<boolean>(`${BASE}/activation/${groupId}`, { activationYn }).then((r) => r.data),
};
