// src/api/admin/systemCodeApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- Types (필요 시 수정) -------- */
export interface SystemCode {
  id: number;
  code: string;
  name: string;
  group?: string;
  description?: string;
  sortOrder?: number;
  useYn?: 'Y' | 'N';
  createdAt?: string; // ISO
  updatedAt?: string; // ISO
  [k: string]: any;
}

/** -------- Paths/Base -------- */
const PATHS_SYS = ['/admin/settings', '/system/code'] as const;

/** -------- API -------- */
export const systemCodeApi = {
  /** 7.6.5.1 시스템 코드 목록 — GET /list */
  list: (params?: Record<string, any>) => commonApi.list<SystemCode[]>({ paths: PATHS_SYS as any, params }),

  /** 7.6.5.2 시스템 코드 추가 — POST /add */
  add: (payload: Partial<SystemCode>) => commonApi.add<number>({ paths: PATHS_SYS as any, params: payload }),

  /** 7.6.5.3 시스템 코드 수정 — POST /modify/{id} */
  modify: (id: number | string, payload: Partial<SystemCode>) =>
    commonApi.modify<boolean>({ paths: PATHS_SYS as any, params: { ...payload, id } }),

  /** 7.6.5.4 시스템 코드 삭제 — POST /delete */
  remove: (ids: (number | string)[]) => commonApi.remove<boolean>({ paths: PATHS_SYS as any, ids }),
};
