// src/api/publicResourcesApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** -------- 공통 타입 -------- */
export type Id = number | string;
export type Yn = 'Y' | 'N';

/** -------- Types (필요 시 실제 스키마로 확장) -------- */

export interface PublicVariable {
  id: Id;
  key: string;
  value: string;
  locked?: boolean;
  use?: boolean;
  description?: string;
  [k: string]: any;
}

export interface PublicFile {
  id: Id;
  fileName: string;
  description?: string;
  useYn?: Yn;
  fileGroupId?: Id;
  // etc...
  [k: string]: any;
}

export interface ShareLib {
  id: Id;
  libName: string;
  version?: string;
  description?: string;
  useYn?: Yn;
  [k: string]: any;
}

/** -------- Paths/Base -------- */
/** 8.1 /pblresource/variable - 공용 변수 */
const PATHS_VARIABLE = ['/pblresource', '/variable'] as const;
/** 8.2 /pblresource/file - 공용 파일 */
const PATHS_FILE = ['/pblresource', '/file'] as const;
/** 8.3 /pblresource/sharelib - 공유 라이브러리 */
const PATHS_SHARELIB = ['/pblresource', '/sharelib'] as const;

const BASE_VARIABLE = PATHS_VARIABLE.slice(0, 2).join(''); // "/pblresource/variable"
const BASE_FILE = PATHS_FILE.slice(0, 2).join(''); // "/pblresource/file"
const BASE_SHARELIB = PATHS_SHARELIB.slice(0, 2).join(''); // "/pblresource/sharelib"

/** -------- 공통 유틸 -------- */
function parseFilename(disposition?: string | null) {
  if (!disposition) return;
  const utf8 = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(disposition);
  if (utf8) return decodeURIComponent(utf8[1]);
  const ascii = /filename\s*=\s*"([^"]+)"/i.exec(disposition) || /filename\s*=\s*([^;]+)/i.exec(disposition);
  return ascii?.[1]?.trim();
}

/** -------- API -------- */
export const publicResourcesApi = {
  /** 8.1 공용 변수 관리 */
  variable: {
    // 8.1.1 목록 - GET /pblresource/variable/list
    list: (params?: Record<string, any>) =>
      commonApi.list<PublicVariable[]>({
        paths: PATHS_VARIABLE as any,
        params,
      }),

    // 8.1.2 추가 - POST /pblresource/variable/add
    add: (payload: Partial<PublicVariable>) =>
      commonApi.add<Id>({
        paths: PATHS_VARIABLE as any,
        params: { ...payload, suffix: 'add' },
      }),

    // 8.1.3 수정 - POST /pblresource/variable/modify/{id}
    modify: (id: Id, payload: Partial<PublicVariable>) =>
      commonApi.modify<boolean>({
        paths: PATHS_VARIABLE as any,
        params: { ...payload, id },
      }),

    // 8.1.4 삭제 - POST /pblresource/variable/delete
    remove: (ids: Id[]) =>
      commonApi.remove<boolean>({
        paths: PATHS_VARIABLE as any,
        ids,
      }),

    // 8.1.5 잠금 해제 - POST /pblresource/variable/unlock/{id}
    unlock: (id: Id) => http.post<boolean>(`${BASE_VARIABLE}/unlock/${id}`, {}).then((r) => r.data),

    // 8.1.6 사용여부 변경 - POST /pblresource/variable/activation/{activationYn}
    setUseYn: ({ activationYn, ids }: { activationYn: Yn; ids: Id[] }) =>
      http.post<boolean>(`${BASE_VARIABLE}/activation/${activationYn}`, { ids }).then((r) => r.data),

    // 8.1.7 사용 업무 목록 - GET /pblresource/variable/worklist
    worklist: (params?: Record<string, any>) =>
      http.get<any>(`${BASE_VARIABLE}/worklist`, { params }).then((r) => r.data),
  },

  /** 8.2 공용 파일 관리 */
  file: {
    // 8.2.1 목록 - GET /pblresource/file/list
    list: (params?: Record<string, any>) =>
      commonApi.list<PublicFile[]>({
        paths: PATHS_FILE as any,
        params,
      }),

    // 8.2.2 추가 - POST /pblresource/file/add
    add: (payload: Partial<PublicFile> | FormData) =>
      commonApi.add<Id>({
        paths: PATHS_FILE as any,
        params: payload as any,
      }),

    // 8.2.3 수정 - POST /pblresource/file/modify/{id}
    modify: (id: Id, payload: Partial<PublicFile>) =>
      commonApi.modify<boolean>({
        paths: PATHS_FILE as any,
        params: { ...payload, id },
      }),

    // 8.2.4 삭제 - POST /pblresource/file/delete
    remove: (ids: Id[]) =>
      commonApi.remove<boolean>({
        paths: PATHS_FILE as any,
        ids,
      }),

    // 8.2.5 파일 다운로드 - GET /pblresource/file/download/{id} (blob)
    download: async (id: Id) => {
      const res = await http.get(`${BASE_FILE}/download/${id}`, {
        responseType: 'blob',
      });
      const filename = parseFilename(res.headers?.['content-disposition'] as string | undefined);
      return { blob: res.data as Blob, filename };
    },

    // 8.2.6 사용여부 변경 - POST /pblresource/file/activation/{activationYn}
    setUseYn: ({ activationYn, ids }: { activationYn: Yn; ids: Id[] }) =>
      http.post<boolean>(`${BASE_FILE}/activation/${activationYn}`, { ids }).then((r) => r.data),
  },

  /** 8.3 공유 라이브러리 관리 */
  sharelib: {
    // 8.3.1 목록 - GET /pblresource/sharelib/list
    list: (params?: Record<string, any>) =>
      commonApi.list<ShareLib[]>({
        paths: PATHS_SHARELIB as any,
        params,
      }),

    // 8.3.2 추가 - POST /pblresource/sharelib/add
    add: (payload: Partial<ShareLib> | FormData) =>
      commonApi.add<Id>({
        paths: PATHS_SHARELIB as any,
        params: payload as any,
      }),

    // 8.3.3 수정 - POST /pblresource/sharelib/modify/{id}
    modify: (id: Id, payload: Partial<ShareLib>) =>
      commonApi.modify<boolean>({
        paths: PATHS_SHARELIB as any,
        params: { ...payload, id },
      }),

    // 8.3.4 삭제 - POST /pblresource/sharelib/delete
    remove: (ids: Id[]) =>
      commonApi.remove<boolean>({
        paths: PATHS_SHARELIB as any,
        ids,
      }),
  },
};

export default publicResourcesApi;
