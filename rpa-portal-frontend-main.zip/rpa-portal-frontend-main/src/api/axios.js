// src/services/axios.js
import { useAuthStore } from '@store/authStore';
import { useModalStore } from '@store/useModalStore';
import { axiosTransformer } from '@utils/axiosTransformer';
import axios from 'axios';

const baseURL = import.meta.env.VITE_SERVER_API !== undefined ? import.meta.env.VITE_SERVER_API : '/';

export const http = axios.create({
  baseURL,
  timeout: 15000,
  headers: { Accept: 'application/json' },
  withCredentials: true,
});

// 요청 interceptor (multipart/form-data)
http.interceptors.request.use(
  (config) => {
    if (config.data instanceof FormData) {
      if (!config.headers) config.headers = {};
      config.headers['Content-Type'] = 'multipart/form-data';
    }
    const token = useAuthStore.getState().token;
    if (token) config.headers.Authorization = `Bearer ${token}`;
    if (config.data) config.data = axiosTransformer(config.data, false);
    return config;
  },
  (error) => Promise.reject(error)
);

// 응답 interceptor 예시.
http.interceptors.response.use(
  (res) => {
    const contentType = res.headers['content-type'];
    // Blob 이나 파일류면 변환 건너뜀
    if (res.request?.responseType === 'blob' || contentType?.includes('octet-stream')) {
      return res.data;
    }
    return axiosTransformer(res.data);
  },
  async (err) => {
    const originalRequest = err.config;

    const { status, statusText, data } = err.response?.data || {};
    const { setAuth, refreshToken } = useAuthStore.getState();

    let message = '';

    switch (status) {
      case 401: // 인증 만료 → 갱신 / 로그아웃
        if (!originalRequest._retry && !originalRequest.url?.endsWith('/auth/refresh')) {
          originalRequest._retry = true;
          const newAccessToken = await refreshToken();
          originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
          return http(originalRequest);
        }
        setAuth();
        message = `${status}\n${data?.details ?? statusText}`;
        break;

      case 403: // 권한 없음
        message = '접근 권한이 없습니다.';
        break;

      case 500: // 서버 에러
        //console.error('서버 오류 발생', err.response?.data);
        message = '서버에서 오류가 발생했습니다. 잠시 후 다시 시도해주세요.';
        break;

      default:
        message = `${status}\n${data?.details ?? statusText}`;
        break;
    }

    if (message) {
      useModalStore.getState().open({ type: 'error', content: message });
    }
    return Promise.reject(err);
  }
);
