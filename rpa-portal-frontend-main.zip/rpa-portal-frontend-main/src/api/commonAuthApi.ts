// src/api/commonAuthApi.ts
import { http } from '@api/axios';

/** ---------------- Base ---------------- */
const BASE = '/auth';

/** ---------------- Types ---------------- */
export type Id = number | string;

export interface Me {
  id: Id;
  username?: string;
  name?: string;
  roles?: string[];
  permissions?: string[];
  [k: string]: any;
}

export interface LoginPayload {
  /** 아이디 필드가 시스템마다 달라질 수 있어 유연하게 정의 */
  username?: string;
  userId?: string;
  loginId?: string;
  password: string;
  otpCode?: string;
  rememberMe?: boolean;
  [k: string]: any;
}

export interface TokenPair {
  accessToken: string;
  refreshToken?: string;
  tokenType?: string; // e.g. "Bearer"
  expiresIn?: number; // seconds
  [k: string]: any;
}

export interface LoginResponse extends TokenPair {
  user?: Me; // 서버가 로그인 시 사용자 정보를 함께 내려줄 경우 대비
}

export interface VerifyPayload {
  token?: string; // or accessToken
  accessToken?: string;
  [k: string]: any;
}

export interface VerifyResult {
  valid: boolean;
  sub?: string | number;
  iat?: number;
  exp?: number;
  claims?: Record<string, any>;
  [k: string]: any;
}

export interface RefreshPayload {
  refresh_token?: string;
  [k: string]: any;
}

/** ---------------- API ---------------- */
/**
 * 0.1.0 내정보 — GET /me
 */
export const me = () => http.get<Me>(`${BASE}/me`).then((r) => r.data);

/**
 * 0.1.1 토큰검증 — POST /verify
 */
export const verify = (payload: VerifyPayload) =>
  http.post<VerifyResult>(`${BASE}/verify`, payload).then((r) => r.data);

/**
 * 0.1.2 로그인 — POST /login
 */
export const login = (payload: LoginPayload) => http.post<LoginResponse>(`${BASE}/login`, payload).then((r) => r.data);

/**
 * 0.1.3 Access 재발급 — POST /refresh
 */
export const refresh = (payload: RefreshPayload = {}) => http.post<TokenPair>(`${BASE}/refresh`).then((r) => r.data);

/**
 * 0.1.4 로그아웃 — POST /logout
 * 서버가 refreshToken 또는 세션 식별자를 요구할 수 있어 payload 허용
 */
export const logout = (payload: Record<string, any> = {}) =>
  http.post<boolean>(`${BASE}/logout`, payload).then((r) => r.data);

/** ---------------- Namespace export ---------------- */
const commonAuthApi = { me, verify, login, refresh, logout };
export default commonAuthApi;
