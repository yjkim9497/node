// src/api/adminApi.js

import { delay } from '@utils/api';

export async function getRobotInfo() {
  await delay(150);
  return { total: 12, normal: 8, standby: 3, fail: 1 };
}

export async function getRobotList() {
  await delay();
  return [
    { name: '로봇#01', ip: '10.0.0.1', task: '업무#02', cpu: 15, memory: 82 },
    { name: '로봇#02', ip: '10.0.0.2', task: '업무#03', cpu: 20, memory: 65 },
  ];
}

export async function getServerStatus() {
  await delay(150);
  return {
    cpu: 15,
    memory: 82,
    statusCounts: { normal: 4, warn: 1, critical: 0 },
  };
}

export async function getWorkKpi() {
  await delay(150);
  return [
    { name: '업무A', goal: 100, automated: 90, leadTime: 10, successRate: 90 },
    { name: '업무B', goal: 200, automated: 180, leadTime: 15, successRate: 92 },
    { name: '업무C', goal: 200, automated: 131, leadTime: 15, successRate: 97 },
  ];
}

export async function getExecutionTrends() {
  await delay();
  return [
    { time: '08', count: 3 },
    { time: '09', count: 4 },
    { time: '10', count: 5 },
    { time: '11', count: 2 },
    { time: '12', count: 3 },
    { time: '13', count: 6 },
    { time: '14', count: 7 },
    { time: '15', count: 10 },
  ];
}

// === 새로 추가: Running / Scheduled 목록 반환 (각 4개 항목)
export async function getSchedules() {
  await delay(150);

  const running = [
    { name: '업무-실행-1', start: '08:30', elapsed: '00:12:20', robotCount: 2 },
    { name: '업무-실행-2', start: '09:05', elapsed: '00:07:40', robotCount: 1 },
    { name: '업무-실행-3', start: '09:30', elapsed: '00:25:10', robotCount: 3 },
    { name: '업무-실행-4', start: '10:00', elapsed: '00:03:55', robotCount: 1 },
    { name: '업무-실행-5', start: '10:10', elapsed: '00:05:55', robotCount: 2 },
  ];

  const scheduled = [
    { name: '업무-예정-1', start: '11:00', elapsed: '-', robotCount: 0 },
    { name: '업무-예정-2', start: '12:30', elapsed: '-', robotCount: 0 },
    { name: '업무-예정-3', start: '14:00', elapsed: '-', robotCount: 0 },
    { name: '업무-예정-4', start: '15:30', elapsed: '-', robotCount: 0 },
    { name: '업무-예정-5', start: '13:33', elapsed: '-', robotCount: 1 },
  ];

  return { running, scheduled };
}
