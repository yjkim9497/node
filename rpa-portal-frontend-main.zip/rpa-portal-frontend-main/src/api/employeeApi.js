// src/api/employeeApi.js

import { delay } from '@utils/api';

function hhmmssToSeconds(hms) {
  if (!hms) return 0;
  const p = String(hms).split(':').map(Number);
  if (p.length === 3) return p[0] * 3600 + p[1] * 60 + p[2];
  if (p.length === 2) return p[0] * 60 + p[1];
  return Number(hms) || 0;
}
function secondsToHHMMSS(sec) {
  sec = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
}

export async function getEmployeeSummary() {
  await delay(200);
  return {
    user: { name: '김직원', id: '1020722', dept: '프로세스혁신부' },
    summary: {
      scheduled: 2,
      success: 2,
      fail: 1,
      runTime: '00:50:00',
      annualEffect: '35,025,172',
    },
  };
}

export async function getWorkResults() {
  await delay(200);

  // 원래 avgTime은 HH:MM:SS 문자열임. totalTime은 avgTime * total (누적)
  const rows = [
    {
      task: '영업일일전표발행',
      total: 8,
      success: 8,
      fail: 0,
      avgTime: '00:12:12',
    },
    {
      task: '은행업무결제심의요청_광고료_제출_2',
      total: 9,
      success: 8,
      fail: 1,
      avgTime: '00:08:45',
    },
    {
      task: '보고서생성자동화',
      total: 6,
      success: 5,
      fail: 0,
      avgTime: '00:07:11',
    },
  ];

  // totalTime 계산 (초 -> HH:MM:SS)
  const withTotal = rows.map((r) => {
    const avgSec = hhmmssToSeconds(r.avgTime);
    const totalSec = avgSec * (r.total || 0);
    return { ...r, totalTime: secondsToHHMMSS(totalSec) };
  });

  return withTotal;
}

export async function getCalendarEvents() {
  await delay(200);
  const now = new Date();
  return [
    {
      id: 1,
      title: '업무 A',
      start: new Date(now.getTime() - 1000 * 60 * 60 * 24 * 2),
      end: new Date(now.getTime() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 60),
      color: 'blue',
    },
    {
      id: 2,
      title: '업무 B',
      start: new Date(now.getTime() + 1000 * 60 * 60 * 24),
      end: new Date(now.getTime() + 1000 * 60 * 60 * 24 + 1000 * 60 * 60),
      color: 'green',
    },
  ];
}

export async function getNotices() {
  return [
    { id: 1, title: 'iAuto Portal 시스템 점검 공지', date: '2025.07.22' },
    { id: 2, title: '정상 작동 공지', date: '2025.07.22' },
    { id: 3, title: '보안 업데이트 안내', date: '2025.07.20' },
    { id: 4, title: '휴가 안내', date: '2025.07.15' },
    { id: 5, title: '정책 변경 안내', date: '2025.07.12' },
  ];
}

export async function getFaqs() {
  return [
    { id: 1, q: '자주 묻는 질문 1', date: '2025.07.22' },
    { id: 2, q: '자주 묻는 질문 2', date: '2025.07.22' },
    { id: 3, q: '자주 묻는 질문 3', date: '2025.07.22' },
    { id: 4, q: '자주 묻는 질문 4', date: '2025.07.22' },
    { id: 5, q: '자주 묻는 질문 5', date: '2025.07.22' },
  ];
}
