// src/api/logApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** ---- 공통 타입 ---- */
export interface Page<T> {
  content: T[];
  totalCount: number;
  totalPages?: number;
  pageRowCount?: number;
  number?: number;
}
export type LogRow = Record<string, any>;
export type LogQuery = Record<string, any>;

/** ---- 내부 유틸 ---- */
const BASE = (paths: readonly string[]) => paths.slice(0, 2).join('');

function parseFilename(disposition?: string | null) {
  if (!disposition) return;
  const utf8 = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(disposition);
  if (utf8) return decodeURIComponent(utf8[1]);
  const ascii = /filename\s*=\s*"([^"]+)"/i.exec(disposition) || /filename\s*=\s*([^;]+)/i.exec(disposition);
  return ascii?.[1]?.trim();
}

/** 공통 섹션: 목록(list), 엑셀(download) */
function makeLogSection(paths: readonly string[]) {
  const base = BASE(paths);
  return {
    /** 7.x.1 로그 목록 조회 — GET {base}/list (commonApi.list 래핑) */
    list: (params?: LogQuery) => commonApi.list<Page<LogRow>>({ paths: paths as any, params }),

    /** 7.x.2 로그 엑셀 다운로드 — GET {base}/download (blob) */
    downloadExcel: async (params?: LogQuery) => {
      const res = await http.get(`${base}/download`, {
        params,
        responseType: 'blob',
      });
      const filename = parseFilename(res.headers?.['content-disposition'] as string | undefined);
      return { blob: res.data as Blob, filename };
    },

    /** url 조립기(옵션) */
    url: (suffix = '') => (suffix ? `${base}/${suffix}` : base),
  };
}

/** ---- Paths ---- */
/** 7.1 패키지 로그 — Base Path: /log/package */
const PATHS_PACKAGE = ['/log', '/package'] as const;
/** 7.2 로봇 로그 — Base Path: /log/robot */
const PATHS_ROBOT = ['/log', '/robot'] as const;
/** 7.3 업무 로그 — Base Path: /log/task */
const PATHS_TASK = ['/log', '/task'] as const;
/** 7.4 데이터 큐 로그 — Base Path: /log/queue */
const PATHS_QUEUE = ['/log', '/queue'] as const;
/** 7.5 스튜디오 로그 — Base Path: /log/studio */
const PATHS_STUDIO = ['/log', '/studio'] as const;
/** 7.6 포탈 로그 — Base Path: /log/portal */
const PATHS_PORTAL = ['/log', '/portal'] as const;

const BASE_TASK = BASE(PATHS_TASK);

/** ---- Export API ---- */
export const logApi = {
  package: makeLogSection(PATHS_PACKAGE),
  robot: makeLogSection(PATHS_ROBOT),
  task: {
    ...makeLogSection(PATHS_TASK),

    /** 업무 상세 로그 조회 — GET /log/task/{taskId} */
    detail: (taskId: number | string, params?: LogQuery) =>
      http.get<LogRow>(`${BASE_TASK}/${taskId}`, { params }).then((r) => r.data),
  },
  queue: makeLogSection(PATHS_QUEUE),
  studio: makeLogSection(PATHS_STUDIO),
  portal: makeLogSection(PATHS_PORTAL),
};
