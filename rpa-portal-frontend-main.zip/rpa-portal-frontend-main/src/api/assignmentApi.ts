// src/api/assignmentApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** ---- Types ---- */
export type Id = number | string;

export interface AssignmentInfo { id: number; name: string; category?: string; status?: string; createdAt?: string; updatedAt?: string; }
export interface AssignmentApplication {
  id: number; assignmentId: number; title: string; applicant?: string;
  progressStatus?: string; approval?: 'APPROVED'|'REJECTED'|'PENDING'; createdAt?: string; updatedAt?: string; [k: string]: any;
}

const PATHS_INFO = ['/assignment', '/info'] as const;
const PATHS_APP  = ['/assignment', '/application'] as const;

export const assignmentApi = {
  /** 3.1 수행업무 정보 */
  info: {
    list:   (params?: any) => commonApi.list<AssignmentInfo[]>({ paths: PATHS_INFO as any, params }),
    detail: (id: Id) => commonApi.detail<AssignmentInfo>({ paths: PATHS_INFO as any, id }),

    status: () => http.get<string[] | Record<string,string>>(`/assignment/info/status`).then(r => r.data),
  },

  /** 3.2 업무신청 */
  application: {
    list:   (params?: any) => commonApi.list<AssignmentApplication[]>({ paths: PATHS_APP as any, params }),
    detail: (id: Id) => commonApi.detail<AssignmentApplication>({ paths: PATHS_APP as any, id }),
    add: (payload: Partial<AssignmentApplication>) => commonApi.add<number>({ paths: PATHS_APP as any, params: payload }),
    modify: (id: Id, payload: Partial<AssignmentApplication>) => commonApi.modify<boolean>({ paths: PATHS_APP as any, params: { ...payload, id } }),

    search:            (params?: any) => http.get(`/assignment/application/search`, { params }).then(r => r.data),
    fileTypes:         () => http.get<string[] | Record<string,string>>(`/assignment/application/file-types`).then(r => r.data),
    variableTypes:     () => http.get<string[] | Record<string,string>>(`/assignment/application/variable-types`).then(r => r.data),
    progress:          (id: Id, payload: {}) => http.get<string[] | Record<string,string>>(`/assignment/application/progress/${id}`).then(r => r.data),
    approval:          (id: Id, payload: { result: 'APPROVE'|'REJECT'; reason?: string }) =>
                         http.post<boolean>(`/assignment/application/approval/${id}`, payload).then(r => r.data),
    progressStatusList:() => http.get<string[] | Record<string,string>>(`/assignment/application/progress-status`).then(r => r.data),
    updateProgressStatus: (id: Id, payload: { status: string; note?: string }) =>
                         http.post<boolean>(`/assignment/application/progress-status/${id}`, payload).then(r => r.data),
  },
};
