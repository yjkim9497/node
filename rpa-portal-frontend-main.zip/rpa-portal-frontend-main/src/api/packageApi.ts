// src/api/packageApi.ts
import commonApi from '@api/commonApi';

export type Id = number | string;
export type Yn = 'Y' | 'N';

/**
 * 6.0 패키지 관리 기본 타입
 * - version / deployedYn 등은 실제 백엔드 스펙에 맞게 조정해서 사용
 */
export interface PackageItem {
  packageId: Id;
  packageName: string;
  version?: string;
  description?: string;
  useYn?: Yn;
  deployedYn?: Yn;
  [k: string]: any;
}

/** Base Path: /package (6.0 패키지 관리) */
const PATH_PACKAGE = ['/package'] as const;

/**
 * 공통 CRUD:
 *  - 6.0.1 패키지 목록 조회   — GET  /package/list
 *  - 6.0.2 패키지 단건 조회   — GET  /package/{packageId}
 *  - 6.0.3 패키지 등록       — POST /package/add
 *  - 6.0.4 패키지 수정       — POST /package/modify/{packageId}
 *  - 6.0.5 패키지 삭제       — POST /package/delete
 *
 */
export const packageApi = {
  /** 6.0.1 패키지 목록 조회 */
  list: (params?: Record<string, any>) =>
    commonApi.list<PackageItem[]>({
      paths: [...PATH_PACKAGE],
      params,
    }),

  /** 6.0.2 패키지 단건 조회 */
  detail: (packageId: Id) =>
    commonApi.detail<PackageItem>({
      paths: [...PATH_PACKAGE],
      id: packageId,
    }),

  /** 6.0.3 패키지 등록 */
  add: (payload: Partial<PackageItem> | FormData) =>
    commonApi.add<Id>({
      paths: [...PATH_PACKAGE],
      params: payload as any,
    }),

  /** 6.0.4 패키지 수정 */
  modify: (packageId: Id, payload: Partial<PackageItem>) =>
    commonApi.modify<boolean>({
      paths: [...PATH_PACKAGE],
      params: { ...payload, id: packageId },
    }),

  /** 6.0.5 패키지 삭제 */
  remove: (packageId: Id[]) =>
    commonApi.remove<boolean>({
      paths: [...PATH_PACKAGE],
      ids: packageId,
    }),
};

export default packageApi;
