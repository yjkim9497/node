// src/api/calendarApi.js
import { delay } from '@utils/api';

// Backend 연결용 예시 API (mock)
export async function getTasks() {
  await delay(); // 실제 API 호출 시 제거

  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // JS에서 월은 0부터 시작
  const date = today.getDate();

  const makeDate = (hour, minute = 0) => new Date(year, month, date, hour, minute);

  return [
    {
      id: 1,
      title: '업무 A',
      team: '팀1',
      assignedTo: '홍길동',
      group: '그룹1',
      color: '#3b82f6',
      details: '상세 내용 A',
      start: makeDate(9),
      end: makeDate(11),
    },
    {
      id: 2,
      title: '업무 B',
      team: '팀2',
      assignedTo: '김철수',
      group: '그룹2',
      color: '#ef4444',
      details: '상세 내용 B',
      start: makeDate(14),
      end: makeDate(16),
    },
    {
      id: 3,
      title: '업무 C',
      team: '팀1',
      assignedTo: '이영희',
      group: '그룹1',
      color: '#22c55e',
      details: '상세 내용 C',
      start: makeDate(10),
      end: makeDate(12),
    },
    {
      id: 4,
      title: '업무 D',
      team: '팀3',
      assignedTo: '박민수',
      group: '그룹2',
      color: '#eab308',
      details: '상세 내용 D',
      start: makeDate(13),
      end: makeDate(15),
    },
    {
      id: 5,
      title: '업무 E',
      team: '팀2',
      assignedTo: '최지은',
      group: '그룹1',
      color: '#a855f7',
      details: '상세 내용 E',
      start: makeDate(9),
      end: makeDate(10),
    },
    {
      id: 6,
      title: '업무 F',
      team: '팀1',
      assignedTo: '오상민',
      group: '그룹3',
      color: '#ec4899',
      details: '상세 내용 F',
      start: makeDate(15),
      end: makeDate(17),
    },
    {
      id: 7,
      title: '업무 G',
      team: '팀3',
      assignedTo: '강민지',
      group: '그룹2',
      color: '#6366f1',
      details: '상세 내용 G',
      start: makeDate(11),
      end: makeDate(13),
    },
  ];
}
