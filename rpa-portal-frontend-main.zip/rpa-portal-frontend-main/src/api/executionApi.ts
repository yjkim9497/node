// src/api/executionApi.ts
import { http } from '@api/axios';
import commonApi from '@api/commonApi';

/** ---------- 공통 타입 ---------- */
export type Id = number | string;

/** 4.x Execution 영역 공통 타입들 */
export interface ExecutionAssignment {
  id: number;
  title: string;
  status?: string;
  assignedTo?: string;
  startDate?: string;
  endDate?: string;
  [k: string]: any;
}

export interface CalendarEvent {
  id: number;
  title: string;
  startAt: string;
  endAt: string;
  assignmentId?: number;
  location?: string;
  memo?: string;
  [k: string]: any;
}

export interface QueueItem {
  id: number;
  assignmentId: number;
  priority?: number;
  status?: string;
  queuedAt?: string;
  [k: string]: any;
}

export interface ExecutionResult {
  id: number;
  assignmentId: number;
  robotId?: number;
  status?: string;
  startedAt?: string;
  endedAt?: string;
  [k: string]: any;
}

export interface RobotResultRow {
  id: number;
  robotId: number;
  robotName?: string;
  runCount?: number;
  successCount?: number;
  failCount?: number;
  [k: string]: any;
}

export interface WorkAccumRow {
  id: number;
  workId: number;
  workName?: string;
  runCount?: number;
  successCount?: number;
  failCount?: number;
  [k: string]: any;
}

export interface ExecutionFile {
  id: number;
  fileName: string;
  fileSize?: number;
  fileGroupSequence?: number | null;
  uploadedAt?: string;
  uploader?: string;
  [k: string]: any;
}

/** ---------- 4.6 실적 관리용 공통 타입 ---------- */

export type Filters = Record<string, any>[] | Record<string, any>;
export type DataRows<T = any> = T[] | { content: T[]; totalElements?: number; [k: string]: any };

export interface TimePoint {
  time: string;
  count: number;
}

export interface ExecutionData {
  today: TimePoint[];
  yesterday: TimePoint[];
}

export interface ResultData {
  success: TimePoint[];
  fail: TimePoint[];
}

export interface ErrorSummary {
  totalRuns: number;
  normalCount: number;
  errors: { label: string; count: number; color?: string }[];
}

export interface SummaryKpi {
  totalExec: number;
  normal: number;
  totalHours: number;
  saved: number;
}

/** ---------- 공통 유틸: 파일명 파싱 ---------- */
function parseFilename(disposition?: string | null) {
  if (!disposition) return;
  const utf8 = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(disposition);
  if (utf8) return decodeURIComponent(utf8[1]);
  const ascii = /filename\s*=\s*"([^"]+)"/i.exec(disposition) || /filename\s*=\s*([^;]+)/i.exec(disposition);
  return ascii?.[1]?.trim();
}

/** ---------- 4.x Execution: Path Segments ---------- */
type Segments = readonly [string, string];

const PATH = {
  /** 4.1 /execution/assignment - 업무 할당 */
  ASSIGN: ['/execution', '/assignment'] as const,

  /** 4.2 /execution/calendar - 업무 캘린더 */
  CALENDAR: ['/execution', '/calendar'] as const,

  /** 4.3 /execution/queue - 업무 대기열 */
  QUEUE: ['/execution', '/queue'] as const,

  /** 4.4.1 /execution/result/results - 실행 결과 내역 */
  RESULT_RESULTS: ['/execution', '/result/results'] as const,

  /** 4.4.2 /execution/result/robots - 로봇별 실행 */
  RESULT_ROBOTS: ['/execution', '/result/robots'] as const,

  /** 4.4.3 /execution/result/works - 업무별 누적 */
  RESULT_WORKS: ['/execution', '/result/works'] as const,

  /** 4.5 /execution/file - 수행 파일 업로드 */
  FILE: ['/execution', '/file'] as const,
};

const joinBase = (parts: Segments) => parts[0] + parts[1];

/** ---------- Tiny factories over commonApi ---------- */
const resource = <T>(paths: Segments) => ({
  list: (params?: Record<string, any>) => commonApi.list<T[]>({ paths: [...paths], params }),
  detail: (id: Id) => commonApi.detail<T>({ paths: [...paths], id }),
  add: (payload: Partial<T> | FormData) =>
    commonApi.add<number>({
      paths: [...paths],
      params: payload as any,
    }),
  modify: (id: Id, payload: Partial<T>) =>
    commonApi.modify<boolean>({
      paths: [...paths],
      params: { ...payload, id },
    }),
  remove: (ids: Id[]) => commonApi.remove<boolean>({ paths: [...paths], ids }),
});

/** 공통 다운로드 팩토리 (blob + filename) */
const makeDownloader = (baseUrl: string) => async (id: Id) => {
  const res = await http.get(`${baseUrl}/download/${id}`, {
    responseType: 'blob',
  });
  const filename = parseFilename((res as any).headers?.['content-disposition'] as string | undefined);
  return { blob: (res as any).data as Blob, filename };
};

/** ---------- 4.x Execution API Export ---------- */

/** 4.1 / 4.2 / 4.3 */
export const executionApi = {
  assignment: resource<ExecutionAssignment>(PATH.ASSIGN),
  calendar: resource<CalendarEvent>(PATH.CALENDAR),
  queue: resource<QueueItem>(PATH.QUEUE),
};

/** 4.4.x 실행 결과 */
export const executionResultApi = {
  /** 4.4.1 실행 결과 내역 */
  results: resource<ExecutionResult>(PATH.RESULT_RESULTS),

  /** 4.4.2 로봇별 결과 */
  robots: {
    list: (params?: Record<string, any>) =>
      commonApi.list<RobotResultRow[]>({
        paths: [...PATH.RESULT_ROBOTS],
        params,
      }),
    download: makeDownloader(joinBase(PATH.RESULT_ROBOTS)),
  },

  /** 4.4.3 업무별 누적 */
  works: {
    list: (params?: Record<string, any>) =>
      commonApi.list<WorkAccumRow[]>({
        paths: [...PATH.RESULT_WORKS],
        params,
      }),
    download: makeDownloader(joinBase(PATH.RESULT_WORKS)),
  },
};

/** 4.5 수행 파일 */
export const executionFileApi = {
  ...resource<ExecutionFile>(PATH.FILE),
};

/* ------------------------------------------------------------------ */
/*  4.6 실적 관리 (/execution/performance/*)                          */
/* ------------------------------------------------------------------ */

/** ['/execution/performance', '/my-work'] -> '/execution/performance/my-work' */
const PERF_BASE = (paths: readonly string[]) => paths.slice(0, 2).join('');

/**
 * /filters, /data, /download 공통 팩토리
 * - filters : GET {base}/filters
 * - data    : GET {base}/data
 * - download: GET {base}/download (blob)
 */
function makePerformanceSection<T = any>(paths: readonly string[]) {
  const base = PERF_BASE(paths);
  return {
    /** 섹션 base URL (필요 시 직접 사용) */
    url: (suffix = '') => (suffix ? `${base}/${suffix}` : base),

    /** 필터 목록 — GET {base}/filters */
    filters: <R = Filters>(params?: Record<string, any>) =>
      http.get<R>(`${base}/filters`, { params }).then((r) => r.data),

    /** 데이터 조회 — GET {base}/data */
    data: <R = DataRows<T>>(params?: Record<string, any>) =>
      http.get<R>(`${base}/data`, { params }).then((r) => r.data),

    /** 엑셀 다운로드 — GET {base}/download (blob) */
    download: async (params?: Record<string, any>) => {
      const res = await http.get(`${base}/download`, {
        params,
        responseType: 'blob',
      });
      const filename = parseFilename(res.headers?.['content-disposition'] as string | undefined);
      return { blob: res.data as Blob, filename };
    },
  };
}

/**
 * 4.6 실적 관리
 *  - 4.6.1 /execution/performance/my-work
 *  - 4.6.2 /execution/performance/department
 *  - 4.6.3 /execution/performance/unit-work
 *  - 4.6.4 /execution/performance/robot
 */
const PATH_PERF_MY = ['/execution/performance', '/my-work'] as const; // 4.6.1
const PATH_PERF_DEPT = ['/execution/performance', '/department'] as const; // 4.6.2
const PATH_PERF_UNIT = ['/execution/performance', '/unit-work'] as const; // 4.6.3
const PATH_PERF_ROBOT = ['/execution/performance', '/robot'] as const; // 4.6.4

export const performanceApi = {
  /** 4.6.1 내 업무 실적 — /execution/performance/my-work */
  myWork: makePerformanceSection(PATH_PERF_MY),

  /** 4.6.2 부서별 실적 — /execution/performance/department */
  department: makePerformanceSection(PATH_PERF_DEPT),

  /** 4.6.3 단위업무별 실적 — /execution/performance/unit-work */
  unitWork: makePerformanceSection(PATH_PERF_UNIT),

  /** 4.6.4 로봇별 실적 — /execution/performance/robot */
  robot: makePerformanceSection(PATH_PERF_ROBOT),
};

/*
사용 예시:

// 1) 실행 현황(시계열) 조회
const exec = await performanceApi.myWork.data<ExecutionData>({
  date: '2025-10-24',
  period: '당일',
});

// 2) 결과(성공/실패) 조회
const result = await performanceApi.department.data<ResultData>({ ...params });

// 3) 오류 요약
const err = await performanceApi.unitWork.data<ErrorSummary>({ ...params });

// 4) KPI 요약
const kpi = await performanceApi.robot.data<SummaryKpi>({ ...params });

// 5) 필터 목록
const filters = await performanceApi.myWork.filters();

// 6) 엑셀 다운로드
const { blob, filename } = await performanceApi.department.download({ ...params });
*/
